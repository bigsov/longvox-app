"use strict";

const groupWidth = 1280, groupHeight = 720;

function groupTiles(count, featured = -1) {
    if (count < 1 || count > 9) return [];
    const tile = (x, y, width) => ({x, y, width, height:width * 9/16});
    if (count > 1 && featured >= 0 && featured < count) {
        const small = groupWidth / Math.max(5, count - 1);
        const large = groupWidth - small;
        const tiles = [];
        let column = 0;
        for (let i = 0; i < count; i++) {
            tiles.push(i === featured ? tile((groupWidth - large)/2, 0, large)
                : tile((groupWidth - small * (count - 1))/2 + small * column++, large * 9/16, small));
        }
        return tiles;
    }
    const columns = count === 1 ? 1 : count <= 4 ? 2 : 3;
    const rows = Math.ceil(count / columns);
    const width = groupWidth / columns, height = width * 9/16;
    return Array.from({length: count}, (_, index) => {
        const row = Math.floor(index / columns);
        const inRow = Math.min(columns, count - row * columns);
        return tile((groupWidth - inRow * width)/2 + index % columns * width,
            (groupHeight - rows * height)/2 + row * height, width);
    });
}

function participantMedia({speaking, mic, camera}, tr = (_, fallback) => fallback) {
    const microphone = {
        live:tr("rosterMicOn", "Microphone on"),
        muted:tr("rosterMicMuted", "Muted"),
        lost:tr("micDisconnectedShort", "Microphone disconnected"),
        unknown:tr("rosterMicUnknown", "Microphone status unknown")
    };
    return [
        speaking && tr("rosterSpeaking", "Speaking"),
        microphone[mic],
        camera ? tr("rosterCameraOn", "Camera on") : tr("rosterCameraOff", "Camera off")
    ].filter(Boolean).join(" · ");
}

// Every guest receives the shared picture and a mix that excludes their microphone.
class GroupMeeting {
    constructor(api, post, status, finished, ux = null) {
        Object.assign(this, {api, post, status, finished, ux});
        this.picture = document.getElementById("groupPicture");
        this.windowHub = new GroupWindowHub();
        this.seats = [];
        this.sources = new Map();
        this.micMuted = false;
        this.speaker = null;
        this.lastLevel = this.lastSpeech = this.speakerHold = 0;
    }
    tr(key, fallback, vars = null) {
        return this.ux?.t ? this.ux.t(key, vars) : fallback;
    }
    syncControls() {
        const el = id => document.getElementById(id);
        const audio = this.local?.getAudioTracks()[0];
        const muted = this.micMuted || Boolean(audio && !audio.enabled);
        if (el("groupMute")) {
            el("groupMute").textContent = muted ? this.tr("unmute", "Unmute") : this.tr("mute", "Mute");
            el("groupMute").setAttribute("aria-pressed", String(muted));
            el("groupMute").classList.toggle("is-muted", muted);
        }
        if (el("groupSelfMutedBadge")) el("groupSelfMutedBadge").hidden = !muted || this.hostMic() === "lost";
        const camOn = Boolean(this.local?.getVideoTracks().length);
        if (el("groupCamera")) {
            el("groupCamera").textContent = camOn ? this.tr("cameraOff", "Camera off") : this.tr("cameraOn", "Camera on");
            el("groupCamera").setAttribute("aria-pressed", String(!camOn));
        }
    }
    setControlsDisabled(disabled) {
        for (const id of ["groupStart", "groupBack", "groupMute", "groupCamera", "groupEnd", "groupSound"]) {
            const button = document.getElementById(id);
            if (button) button.disabled = disabled;
        }
        if (disabled) {
            for (const button of document.querySelectorAll("#groupSeats button")) button.disabled = true;
        }
    }
    prepare(name, address, contacts, started, answers = {}, alreadyStarted = false, contactNames = []) {
        Object.assign(this, {name, address, contacts, answers, contactNames});
        const el = id => document.getElementById(id);
        el("groupSeats").replaceChildren();
        el("groupHost").textContent = this.name + " (you)";
        el("groupHostMedia").textContent = "";
        el("groupMicSettings").open = false;
        el("groupView").value = "gallery";
        el("groupPin").replaceChildren(new Option("Active speaker", ""));
        delete el("groupPin").dataset.options;
        el("groupCount").textContent = "";
        el("groupConsent").hidden = el("groupStart").hidden = el("groupBack").hidden = false;
        this.setControlsDisabled(false);
        el("groupControls").hidden = el("groupLayout").hidden = el("groupAudio").hidden = el("groupViewControls").hidden = this.picture.hidden = true;
        this.syncControls();
        this.timer = this.ux?.makeTimer?.(el("groupTimer"));
        this.timer?.stop();
        el("groupStart").onclick = async () => {
            if (this.ending || this.starting) return;
            el("groupStart").disabled = true;
            try {
                started();
                this.starting = this.start();
                await this.starting;
            } catch (error) { await this.end(error.message); }
        };
        el("groupBack").onclick = el("groupEnd").onclick = () => this.end();
        el("groupMute").onclick = () => {
            if (this.ending) return;
            this.micMuted = !this.micMuted;
            const track = this.local?.getAudioTracks()[0];
            if (track) track.enabled = !this.micMuted;
            this.showMicrophone();
        };
        el("groupCamera").onclick = async () => {
            if (this.ending || !this.local) return;
            el("groupCamera").disabled = true;
            try { await this.camera(!this.local.getVideoTracks().length); }
            catch { if (!this.ending) this.status(this.tr("groupCameraUnavailable", "Camera unavailable. Your audio is still connected.")); }
            finally { if (!this.ending) el("groupCamera").disabled = false; }
        };
        el("groupView").onchange = () => this.draw();
        el("groupPin").onchange = () => {
            if (el("groupPin").value) el("groupView").value = "speaker";
            this.draw();
        };
        if (alreadyStarted) void el("groupStart").onclick();
    }
    showMicrophone() {
        const el = id => document.getElementById(id);
        const live = this.hostMic() !== "lost";
        this.syncControls();
        el("groupMicState").textContent = !live ? "Microphone disconnected. Reconnect to speak."
            : this.micMuted ? "Your microphone is muted" : "";
        if (!live || this.micMuted) el("groupMicLevel").value = 0;
        el("groupMicReconnect").hidden = live;
        if (!live) {
            el("groupMicSettings").hidden = false;
            el("groupMicSettings").open = true;
        }
        this.refreshParticipants();
    }
    hostMic() {
        if (this.local?.getAudioTracks()[0]?.readyState !== "live") return "lost";
        return this.micMuted ? "muted" : "live";
    }
    async listMicrophones() {
        const devices = await navigator.mediaDevices.enumerateDevices().catch(() => []);
        const inputs = devices.filter(device => device.kind === "audioinput" && device.deviceId);
        if (this.ending) return;
        const select = document.getElementById("groupMicInput");
        const active = this.local.getAudioTracks()[0]?.getSettings().deviceId;
        const selected = select.value;
        select.replaceChildren(...(inputs.length ? inputs.map((device, i) => new Option(device.label || "Microphone " + (i+1), device.deviceId))
            : [new Option("System default", "")]));
        const wanted = active || selected;
        if (inputs.some(device => device.deviceId === wanted)) select.value = wanted;
        document.getElementById("groupMicSettings").hidden = this.hostMic() !== "lost"
            && (!inputs.length || (inputs.length === 1 && active === inputs[0].deviceId));
    }
    async switchMicrophone() {
        if (this.ending || this.switchingMicrophone) return;
        this.switchingMicrophone = true;
        const select = document.getElementById("groupMicInput");
        const reconnect = document.getElementById("groupMicReconnect");
        select.disabled = reconnect.disabled = true;
        try {
            const device = select.value ? {deviceId:{exact:select.value}} : {};
            const input = await navigator.mediaDevices.getUserMedia({audio:{...device,echoCancellation:true,noiseSuppression:true},video:false});
            const track = input.getAudioTracks()[0];
            if (this.ending || track?.readyState !== "live") {
                input.getTracks().forEach(t => t.stop());
                if (!this.ending) throw Error("Microphone unavailable");
                return;
            }
            const previous = this.local.getAudioTracks()[0];
            if (previous) {
                previous.onended = null;
                this.local.removeTrack(previous); previous.stop();
            }
            this.local.addTrack(track); this.watchMicrophone(track);
            this.status("");
        } catch {
            if (!this.ending) this.status("Microphone unavailable. Check it and try again.");
        } finally {
            if (!this.ending) await this.listMicrophones();
            this.switchingMicrophone = false;
            select.disabled = reconnect.disabled = false;
        }
    }
    watchMicrophone(track) {
        track.enabled = !this.micMuted;
        this.setSource("host", this.local);
        track.onended = () => {
            if (this.ending || this.local.getAudioTracks()[0] !== track) return;
            this.local.removeTrack(track);
            this.setSource("host", null);
            this.showMicrophone();
            void this.listMicrophones();
        };
        this.showMicrophone();
    }
    updateSpeaker(people) {
        const now = performance.now();
        if (now - this.lastLevel < 100) return;
        this.lastLevel = now;
        let loudest = null, peak = 0.02;
        for (const person of people) {
            const source = this.sources.get(person.id);
            let level = 0;
            if (source && (person.mic === "live" || person.mic === "unknown") && this.context.state === "running") {
                source.analyser.getFloatTimeDomainData(source.samples);
                let sum = 0;
                for (const sample of source.samples) sum += sample * sample;
                level = Math.sqrt(sum / source.samples.length);
            }
            if (person.host) document.getElementById("groupMicLevel").value = Math.min(1, 4 * level);
            if (person.id === this.speaker && level > 0.02) this.lastSpeech = now;
            if (level > peak) { peak = level; loudest = person.id; }
        }
        const next = loudest !== null && (this.speaker === null || now >= this.speakerHold) ? loudest
            : now - this.lastSpeech > 1000 ? null : this.speaker;
        if (next !== this.speaker) {
            this.speaker = next;
            this.lastSpeech = now;
            this.speakerHold = now + 1000;
            this.refreshParticipants();
        }
    }
    updateCount() {
        const connected = 1 + this.seats.filter(seat => !seat.done && seat.pc?.connectionState === "connected").length;
        const count = document.getElementById("groupCount");
        const description = connected === 1 ? "Only you in the call" : connected + " people in the call";
        if (count.textContent !== description) count.textContent = description;
        document.getElementById("groupLayout").dataset.alone = String(connected === 1);
    }
    seatStatus(seat, message) {
        seat.message = message;
        this.showSeat(seat);
    }
    showSeat(seat) {
        if (seat.label.textContent !== seat.name) seat.label.textContent = seat.name;
        const message = [
            seat.message,
            !seat.done && (seat.sendIssue || seat.pollIssue) && "Trying to reach this guest…",
            !seat.done && seat.noticeIssue && "Retrying recording notice…"
        ].filter(Boolean).join(" · ");
        if (seat.state.textContent !== message) seat.state.textContent = message;
    }
    people() {
        return [{id:"host", name:this.name, host:true, mic:this.hostMic(), camera:!!this.local?.getVideoTracks().length, video:this.localVideo},
            ...this.seats.filter(seat => seat.admitted && !seat.done).map(seat => ({
                id:String(seat.seat), name:seat.name, host:false, mic:seat.mic, camera:seat.cameraOn, video:seat.video
            }))];
    }
    refreshParticipants() {
        if (this.ending) return;
        const el = id => document.getElementById(id);
        const people = this.people();
        if (!people.some(person => person.id === this.speaker && (person.mic === "live" || person.mic === "unknown")))
            this.speaker = null;
        const roster = people.map(({video, ...person}) => ({...person, speaking:person.id === this.speaker}));
        for (const person of roster) {
            const seat = person.host ? null : this.seats.find(seat => String(seat.seat) === person.id);
            const row = seat ? seat.row : el("groupHost").parentElement;
            const state = seat ? seat.media : el("groupHostMedia");
            row.dataset.speaking = String(person.speaking);
            state.hidden = false;
            const text = participantMedia(person, (key, fallback) => this.tr(key, fallback));
            if (state.textContent !== text) state.textContent = text;
        }
        const pin = el("groupPin"), options = JSON.stringify(people.map(({id,name}) => [id,name]));
        if (pin.dataset.options !== options) {
            const selected = pin.value;
            pin.replaceChildren(new Option("Active speaker", ""), ...people.map(({id,name,host}) => new Option(host ? name + " (you)" : name, id)));
            pin.value = people.some(person => person.id === selected) ? selected : "";
            pin.dataset.options = options;
        }
        this.roster = JSON.stringify({kind:"roster", people:roster});
        for (const seat of this.seats) this.reportToSeat(seat);
    }
    controlSend(seat, message) {
        if (seat.control?.readyState !== "open") return false;
        try { seat.control.send(message); return true; }
        catch { return false; }
    }
    reportToSeat(seat) {
        if (seat.done || !seat.admitted) return;
        if (this.roster && seat.lastRoster !== this.roster && this.controlSend(seat, this.roster))
            seat.lastRoster = this.roster;
        const mic = this.hostMic();
        if (seat.lastHostMic !== mic && this.controlSend(seat, mic === "live" ? "mic-ready" : "mic-" + mic))
            seat.lastHostMic = mic;
    }
    async camera(on) {
        if (this.ending || !this.local) return;
        if (on) {
            const stream = await navigator.mediaDevices.getUserMedia({audio:false, video:{width:{ideal:1280},height:{ideal:720},frameRate:{ideal:30},facingMode:"user"}});
            const track = stream.getVideoTracks()[0];
            if (this.ending || !this.local) { stream.getTracks().forEach(t => t.stop()); return; }
            this.local.addTrack(track);
            track.onended = () => {
                if (!this.ending && this.local) {
                    this.local.removeTrack(track);
                    this.cameraState();
                }
            };
        } else {
            for (const track of this.local.getVideoTracks()) { track.onended = null; this.local.removeTrack(track); track.stop(); }
        }
        if (this.ending || !this.local) return;
        this.localVideo.srcObject = this.local;
        this.cameraState();
    }
    cameraState() {
        this.syncControls();
        this.refreshParticipants();
    }
    video(stream) {
        const video = document.createElement("video");
        video.muted = true; video.autoplay = true; video.playsInline = true; video.srcObject = stream;
        video.play().catch(() => {});
        return video;
    }
    async start() {
        const el = id => document.getElementById(id);
        if (this.ending) return;
        try {
            this.local = await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:true,noiseSuppression:true},video:false});
        } catch { throw Error("Microphone unavailable. Check it and try again."); }
        if (this.ending) { this.local?.getTracks().forEach(t => t.stop()); this.local = null; return; }
        this.context = new AudioContext();
        const soundButton = el("groupSound");
        const syncSound = () => { if (!this.ending && this.context) soundButton.hidden = this.context.state !== "suspended"; };
        this.context.onstatechange = syncSound;
        soundButton.onclick = () => { if (!this.ending) void this.context?.resume(); };
        syncSound();
        void this.context.resume().catch(() => {});
        this.localVideo = this.video(this.local);
        try { await this.camera(true); }
        catch { if (!this.ending) { this.cameraState(); this.status(this.tr("groupCameraAudioOn", "Camera unavailable. Audio stays on.")); } }
        if (this.ending) { this.local?.getTracks().forEach(t => t.stop()); this.local = null; return; }
        const result = await this.api("group_host", {name:this.name, address:this.address, contacts:this.contacts, answers:this.answers, agreed:true});
        this.hosting = true;
        if (this.ending) { this.local?.getTracks().forEach(t => t.stop()); this.local = null; return; }
        this.mix = this.context.createMediaStreamDestination();
        this.picture.hidden = false;
        this.draw();
        this.pictureStream = this.picture.captureStream(30);
        this.frames = setInterval(() => this.draw(), 1000/30);
        this.seats = result.seats.map(info => this.makeSeat(info));
        this.watchMicrophone(this.local.getAudioTracks()[0]);
        this.updateCount();
        this.deviceChanged = () => { void this.listMicrophones(); };
        navigator.mediaDevices.addEventListener("devicechange", this.deviceChanged);
        this.deviceChanged();
        el("groupMicInput").onchange = () => this.switchMicrophone();
        el("groupMicReconnect").onclick = () => this.switchMicrophone();
        for (const seat of this.seats) void this.poll(seat);
        el("groupStart").hidden = el("groupBack").hidden = el("groupConsent").hidden = true;
        el("groupControls").hidden = el("groupLayout").hidden = el("groupAudio").hidden = el("groupViewControls").hidden = false;
    }
    makeSeat(info) {
        const row = document.createElement("li"); row.className = "contact-row";
        const label = document.createElement("strong");
        const state = document.createElement("span"); state.className = "seat-state";
        const media = document.createElement("span"); media.className = "seat-state"; media.hidden = true;
        const controls = document.createElement("div"); controls.className = "buttons";
        row.append(label, state, media, controls); document.getElementById("groupSeats").append(row);
        const seat = {...info, row, label, state, media, controls,
            name:this.contactNames[info.seat] || this.tr("guestNum", "Guest " + (info.seat+1), {n:info.seat+1}),
            seq:0, cursor:0, attempt:0, mic:"unknown", cameraOn:false,
            sending:Promise.resolve(), generation:0, output:this.context.createMediaStreamDestination()};
        this.seatStatus(seat, info.contact ? this.tr("seatCallingSaved", "Calling") : this.tr("seatAwaitingInvite", "Ready to invite"));
        if (info.invite) this.button(controls, this.tr("copyInvitation", "Copy invitation"), async () => {
            try { await navigator.clipboard.writeText(info.invite); this.status(this.tr("seatInviteCopied", "Invitation copied for " + seat.name + ".", {name:seat.name})); }
            catch {
                const text = document.createElement("textarea"); text.value = info.invite; text.readOnly = true;
                controls.replaceChildren(text); text.select();
            }
        });
        return seat;
    }
    button(parent, text, fn) {
        const button = document.createElement("button"); button.textContent = text;
        button.onclick = async () => {
            if (this.ending) return;
            button.disabled = true;
            try { await fn(); } catch { /* The participant row has the latest status. */ }
            finally { if (!this.ending) button.disabled = false; }
        };
        parent.append(button);
    }
    setSource(key, stream) {
        const previous = this.sources.get(key);
        if (previous) { previous.node.disconnect(); this.sources.delete(key); }
        const track = stream?.getAudioTracks()[0];
        if (!track) return;
        const node = this.context.createMediaStreamSource(new MediaStream([track]));
        const analyser = this.context.createAnalyser();
        analyser.fftSize = 1024;
        this.sources.set(key, {node, analyser, samples:new Float32Array(analyser.fftSize)});
        node.connect(analyser);
        node.connect(this.mix);
        if (key !== "host") node.connect(this.context.destination);
        for (const seat of this.seats) if (String(seat.seat) !== key) node.connect(seat.output);
    }
    draw() {
        const people = this.people();
        this.updateSpeaker(people);
        const speakerView = document.getElementById("groupView").value === "speaker";
        const featured = document.getElementById("groupPin").value || this.speaker || "host";
        const tiles = groupTiles(people.length, speakerView ? people.findIndex(person => person.id === featured) : -1);
        const ctx = this.picture.getContext("2d", {alpha:false});
        ctx.fillStyle = "#161a20"; ctx.fillRect(0,0,groupWidth,groupHeight);
        tiles.forEach(({x, y, width:w, height:h}, i) => {
            const {id,name,video,camera} = people[i];
            ctx.fillStyle = "#1d232b"; ctx.fillRect(x+1,y+1,w-2,h-2);
            if (camera && video?.videoWidth && video.readyState >= 2) {
                const scale = Math.min(w/video.videoWidth, h/video.videoHeight);
                const dw = video.videoWidth*scale, dh = video.videoHeight*scale;
                ctx.drawImage(video, x+(w-dw)/2, y+(h-dh)/2, dw, dh);
            }
            const compact = w < 320;
            ctx.font = (compact ? "16px" : "20px") + " Segoe UI, sans-serif";
            ctx.fillStyle = "rgba(12,16,20,.8)";
            ctx.fillRect(x+7,y+h-(compact ? 30 : 37), Math.min(w-14,ctx.measureText(name).width+20),compact ? 23 : 30);
            ctx.fillStyle = "#ffffff"; ctx.fillText(name,x+16,y+h-(compact ? 13 : 15),w-30);
            if (id === this.speaker) {
                ctx.lineWidth = 6; ctx.strokeStyle = "#4fd1c7";
                ctx.strokeRect(x+3,y+3,w-6,h-6);
            }
        });
    }
    leg(seat, action, fields = {}) {
        return this.api("group_leg", {seat:seat.seat,action,...fields}, AbortSignal.timeout(8000));
    }
    send(seat, kind, fields = {}) {
        const message = {kind, ...fields};
        const terminal = kind === "leave" || kind === "fault";
        const pending = seat.sending.then(async () => {
            if (kind === "recording" && seat.recording) return;
            let error;
            for (let attempt=0; attempt<4 && !seat.done && (!this.ending || terminal); attempt++) {
                try {
                    let delivered = false;
                    const prior = seat.unconfirmed;
                    if (prior && prior.message !== message) {
                        // A lost reply may conceal a committed send. Ask the room where
                        // the next message belongs before sending a different message.
                        seat.seq = (await this.leg(seat,"send_position")).seq;
                        if (seat.seq > prior.seq) {
                            delivered = JSON.stringify(prior.message) === JSON.stringify(message);
                            if (prior.message.kind === "recording") this.noticeDelivered(seat);
                        }
                    }
                    if (seat.done || (this.ending && !terminal)) break;
                    if (!delivered) {
                        seat.unconfirmed = {seq:seat.seq, message};
                        await this.leg(seat,"send",seat.unconfirmed);
                        seat.seq++;
                    }
                    seat.unconfirmed = null;
                    if (kind !== "recording") seat.sendIssue = false;
                    this.showSeat(seat);
                    return;
                } catch (failure) {
                    error = failure;
                    if (kind === "recording") seat.noticeIssue = true;
                    else seat.sendIssue = true;
                    this.showSeat(seat);
                }
                if (this.ending) break;
                if (attempt < 3) await new Promise(ok => setTimeout(ok,400));
            }
            throw error || Error("This guest has left.");
        });
        seat.sending = pending.catch(() => {});
        return pending;
    }
    async poll(seat) {
        while (!this.ending && !seat.done) {
            try {
                const {events, delivery, push, windowRoute} = await this.leg(seat,"poll",{after:seat.cursor});
                if (this.ending || seat.done) return;
                if (windowRoute === false) {
                    seat.windowMember = null;
                    seat.windowRoute?.close();
                    seat.windowRoute = null;
                }
                if (seat.contact && !seat.admitted && delivery) {
                    const progress = delivery === "received" ? "Ringing"
                        : delivery === "sent" || push === "submitted" ? "Waiting for an answer"
                        : "Waiting for guest to open Longvox";
                    this.seatStatus(seat, progress);
                }
                for (const e of events) {
                    await this.event(seat,e);
                    seat.cursor++;
                    if (this.ending || seat.done) return;
                }
                seat.pollIssue = false;
            } catch {
                seat.pollIssue = true;
            }
            if (this.ending || seat.done) return;
            this.showSeat(seat);
            this.reportToSeat(seat);
            void this.decide(seat);
            void this.recordIfConnected(seat);
            await new Promise(ok => setTimeout(ok,500));
        }
    }
    async event(seat, e) {
        switch (e.kind) {
        case "request":
            seat.name = e.name; this.seatStatus(seat, this.tr("seatWantsToJoin", "Wants to join"));
            seat.controls.replaceChildren();
            const choose = kind => {
                seat.decision = kind;
                seat.controls.replaceChildren();
                this.seatStatus(seat, kind === "accept" ? "Admitting…" : "Declining…");
                void this.decide(seat);
            };
            if (seat.contact) { choose("accept"); break; }
            this.button(seat.controls, this.tr("admit", "Admit"), () => choose("accept"));
            this.button(seat.controls, this.tr("decline", "Decline"), () => choose("decline"));
            break;
        case "answer":
            if (seat.pc?.signalingState === "have-local-offer" && (e.generation === undefined || e.generation === seat.generation)) {
                try { await seat.pc.setRemoteDescription({type:"answer",sdp:e.sdp}); }
                catch { this.retry(seat); }
            }
            break;
        case "restart":
            if (e.generation === seat.generation) this.retry(seat, true);
            break;
        case "expired": {
            this.drop(seat, seat.contact ? "No answer. Ring again." : this.tr("seatExpired", "Invitation expired."));
            if (seat.contact) this.button(seat.controls, "Ring again", async () => {
                let result;
                try { result = await this.leg(seat, "ring_again", {attempt:seat.attempt+1}); }
                catch { this.seatStatus(seat, "Could not call. Ring again."); return; }
                if (this.ending) return;
                seat.attempt = result.attempt;
                seat.windowMember = result.windowMember ?? null;
                seat.cursor = seat.seq = 0;
                seat.done = false;
                seat.unconfirmed = null;
                seat.pollIssue = seat.sendIssue = false;
                seat.controls.replaceChildren();
                this.seatStatus(seat, "Calling again");
                void this.poll(seat);
            });
            break;
        }
        case "leave": case "decline": case "no_answer": case "fault":
            this.drop(seat, ({
                leave:this.tr("seatLeft", "Left"), decline:this.tr("seatDeclined", "Declined"),
                no_answer:this.tr("seatNoAnswer", "No answer"), fault:this.tr("seatDisconnected", "Disconnected")
            })[e.kind]);
        }
    }
    async decide(seat) {
        if (!seat.decision || seat.decisionPending || seat.done || this.ending) return;
        seat.decisionPending = true;
        const kind = seat.decision;
        try {
            await this.send(seat, kind);
            seat.decision = null;
            if (seat.done || this.ending) return;
            if (kind === "decline") { this.drop(seat, "Declined"); return; }
            seat.admitted = true;
            this.seatStatus(seat, "Connecting…");
            this.refreshParticipants();
            void this.connectSeat(seat);
        } catch { /* Retry the chosen action on the next poll. */ }
        finally { seat.decisionPending = false; }
    }
    async peer(seat) {
        const {servers} = await this.leg(seat,"ice");
        if (this.ending || seat.done) return;
        this.releasePeer(seat);
        const pc = seat.pc = new RTCPeerConnection({iceServers:servers,bundlePolicy:"max-bundle"});
        seat.windowRoute = this.windowHub.attach(pc, seat.windowMember);
        seat.windowShare = new CallWindowShare(pc, seat.row, seat.name,
            (op, fields) => this.api(op, {...fields, seat:seat.seat}));
        const outgoing = new MediaStream([...seat.output.stream.getAudioTracks(), ...this.pictureStream.getVideoTracks()]);
        outgoing.getTracks().forEach(track => pc.addTrack(track,outgoing));
        const remote = seat.remote = new MediaStream();
        seat.video = this.video(remote);
        const channel = seat.control = pc.createDataChannel("longvox-call");
        seat.lastRoster = seat.lastHostMic = null;
        channel.onopen = () => { this.controlSend(seat,"camera-on"); this.reportToSeat(seat); };
        channel.onmessage = ({data}) => {
            if (data === "leave" || data === "fault") this.drop(seat, data === "leave" ? this.tr("seatLeft", "Left") : this.tr("seatDisconnected", "Disconnected"));
            if (data === "camera-on" || data === "camera-off") {
                seat.cameraOn = data === "camera-on";
                this.refreshParticipants();
            }
            if (data === "mic-ready" || data === "mic-muted" || data === "mic-lost") {
                seat.mic = data === "mic-ready" ? "live" : data.slice(4);
                this.refreshParticipants();
            }
        };
        pc.ontrack = ({track}) => {
            remote.addTrack(track);
            if (track.kind === "audio") this.setSource(String(seat.seat), remote);
            void this.recordIfConnected(seat);
        };
        pc.onconnectionstatechange = () => {
            if (seat.pc !== pc || this.ending || seat.done) return;
            if (pc.connectionState === "connected") {
                clearTimeout(seat.retryTimer); seat.retryTimer = null; seat.failedAt = 0;
                this.timer?.start();
                this.seatStatus(seat, this.tr("seatInMeeting", "In meeting")); this.updateCount(); void this.recordIfConnected(seat);
            } else if (["failed","disconnected"].includes(pc.connectionState)) this.retry(seat);
        };
        await pc.setLocalDescription(await pc.createOffer());
        if (pc.iceGatheringState !== "complete") await new Promise(resolve => {
            const done = () => { clearTimeout(timer); pc.removeEventListener("icegatheringstatechange",change); resolve(); };
            const change = () => { if (pc.iceGatheringState === "complete") done(); };
            const timer = setTimeout(done,4500); pc.addEventListener("icegatheringstatechange",change); change();
        });
        if (seat.pc === pc && !this.ending && !seat.done)
            await this.send(seat,"offer",{sdp:pc.localDescription.sdp,renewal:seat.generation>0,generation:seat.generation});
    }
    async connectSeat(seat) {
        if (seat.connecting || seat.done || this.ending) return;
        seat.connecting = true;
        let offered = false;
        try { await this.peer(seat); offered = true; }
        catch { /* Retry this participant's connection. */ }
        finally { seat.connecting = false; }
        if (seat.pc?.connectionState !== "connected") this.retry(seat, false, offered);
    }
    retry(seat, replace = false, waitingForAnswer = false) {
        if (seat.retryTimer || seat.connecting || seat.done || this.ending) return;
        seat.failedAt ||= Date.now();
        if (Date.now()-seat.failedAt > 45000) { this.drop(seat, this.tr("seatConnectionLost", "Connection lost")); return; }
        if (!waitingForAnswer) this.seatStatus(seat, this.tr("seatReconnecting", "Reconnecting…"));
        this.updateCount();
        seat.retryTimer = setTimeout(() => {
            seat.retryTimer = null;
            if (this.ending || seat.done) return;
            if (!replace && seat.pc?.connectionState === "connected") return;
            this.seatStatus(seat, this.tr("seatReconnecting", "Reconnecting…"));
            seat.generation++;
            void this.connectSeat(seat);
        }, waitingForAnswer || seat.generation ? 8500 : 1200);
    }
    async recordIfConnected(seat) {
        if (seat.pc?.connectionState !== "connected" || !seat.remote.getAudioTracks().length
            || this.ending || seat.done || seat.recording || seat.noticePending) return;
        if (!this.recording) {
            this.capture = new MeetingCapture(this.context, this.post, error => { void this.end(this.tr("groupRecordingInterrupted", "Recording interrupted. " + error.message, {msg:error.message})); });
            this.recording = this.capture.start(this.mix.stream, new MediaStream(), true, mime => this.api("group_begin",{mime}),this.picture);
        }
        seat.noticePending = true;
        try {
            try { await this.recording; }
            catch (error) { void this.end(this.tr("groupRecordingInterrupted", "Could not start recording. Check storage and try again.", {msg:error.message})); return; }
            if (this.ending || seat.done) return;
            document.getElementById("record").hidden = false;
            try {
                await this.send(seat,"recording");
                this.noticeDelivered(seat);
            } catch { /* The next poll retries this guest's notice. */ }
        } finally { seat.noticePending = false; }
    }
    noticeDelivered(seat) {
        seat.recording = true;
        seat.noticeIssue = false;
        this.showSeat(seat);
    }
    releasePeer(seat) {
        seat.windowRoute?.close(); seat.windowRoute = null;
        seat.windowShare?.close(); seat.windowShare = null;
        if (seat.pc) {
            seat.pc.onconnectionstatechange = seat.pc.ontrack = null;
            if (seat.control) { seat.control.onmessage = seat.control.onopen = null; seat.control.close(); }
            seat.pc.close(); seat.pc = null;
            seat.control = null;
            this.setSource(String(seat.seat), null);
        }
        if (seat.video) { seat.video.srcObject = null; seat.video = null; }
    }
    drop(seat, reason) {
        if (seat.done) return;
        seat.done = true; clearTimeout(seat.retryTimer); seat.retryTimer = null;
        this.releasePeer(seat); seat.controls.replaceChildren();
        seat.media.hidden = true;
        delete seat.row.dataset.speaking;
        this.seatStatus(seat, reason); this.updateCount(); this.refreshParticipants();
    }
    async end(failure = "") {
        if (this.ending) return;
        this.ending = true;
        this.setControlsDisabled(true);
        this.timer?.stop();
        if (document.getElementById("groupSelfMutedBadge")) document.getElementById("groupSelfMutedBadge").hidden = true;
        let saved = false;
        try {
            if (this.starting) await this.starting.catch(() => {});
            await Promise.all(this.seats.filter(s => s.admitted && !s.done).map(async seat => {
                this.controlSend(seat, failure ? "fault" : "leave");
                await this.send(seat, failure ? "fault" : "leave").catch(() => {});
            }));
            if (this.recording) {
                await this.recording.catch(() => {});
                await this.capture.stop();
                if (this.capture.begun) { await this.api("finish",{complete:!failure && !this.capture.failure}); saved = true; }
            }
        } catch { failure = "Could not save the recording. Check storage."; }
        finally {
            clearInterval(this.frames);
            if (this.deviceChanged) navigator.mediaDevices.removeEventListener("devicechange", this.deviceChanged);
            for (const seat of this.seats) {
                this.drop(seat, this.tr("seatMeetingEnded", "Meeting ended"));
                seat.output.stream.getTracks().forEach(t => t.stop());
            }
            for (const stream of [this.local, this.mix?.stream, this.pictureStream]) stream?.getTracks().forEach(t => t.stop());
            this.local = this.mix = this.pictureStream = null;
            if (this.localVideo) this.localVideo.srcObject = null;
            if (this.context) {
                this.context.onstatechange = null;
                if (this.context.state !== "closed") await this.context.close().catch(() => {});
            }
            if (this.hosting) await this.api("reset").catch(() => {});
            this.finished(failure || (saved ? this.tr("groupSaved", "Group recording saved in Meetings.") : this.tr("groupClosed", "Group call closed.")));
        }
    }
}
