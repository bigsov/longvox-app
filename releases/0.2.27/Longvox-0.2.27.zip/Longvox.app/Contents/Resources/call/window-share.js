// Control uses its own ordered stream when both WebRTC peers support a frame stream.
class CallWindowShare {
    constructor(pc, parent, name, native, meetingConnection = pc) {
        this.pc = pc;
        this.meetingConnection = meetingConnection;
        this.groupRoute = pc !== meetingConnection;
        this.links = new Set([pc,meetingConnection]);
        this.name = name;
        this.native = native;
        this.inputChain = Promise.resolve();
        this.pendingInputs = 0;
        this.dragEndBypass = false;
        this.lastInvitation = 0;
        this.generation = 0;
        this.approvalSeq = 0;
        this.nativeVersion = 1;
        this.nativeCanControl = true;
        this.nativeCaps = new Set();
        this.peerVersion = 1;
        this.peerCaps = new Set();
        this.peerSas = false;
        this.peerSas2 = false;
        this.codeBound = false;
        this.sas2Bound = false;
        this.viewOnlyReason = "";
        this.localFingerprint = "";
        this.remoteFingerprint = "";
        this.inputSeq = 0;
        this.lastFrameSeq = 0;
        this.pendingFrameSeq = 0;
        this.inFlightFrameSeq = 0;
        this.lastAckedFrameSeq = 0;
        this.lastFrameSentAt = 0;
        this.frameSentTimes = new Map();
        this.lastRttMs = null;
        this.pendingFrameRttMs = null;
        this.pendingFrameQuality = null;
        this.lastFrameAt = 0;
        this.lastFrameBytes = 0;
        this.lastFrameQuality = null;
        this.frameTimes = [];
        this.metricsTimer = null;
        this.lastPointer = null;
        this.pumping = false;
        this.heartbeatTimer = null;
        this.lastForwardedHeartbeat = -Infinity;
        this.windowState = "active";
        this.windowReason = "";
        this.windowMessage = "";
        this.dropReason = "";
        this.dropMessage = "";
        this.dropTimer = null;
        this.zoom = 1;
        this.panX = 0;
        this.panY = 0;
        this.dragMode = false;
        this.stickyMods = new Set();
        this.composing = false;
        this.lastEmptyBackspaceAt = 0;
        this.legacyKeyQueue = [];
        this.legacyKeyTimer = null;
        this.textSend = null;
        this.textAckTimeoutMs = 10000;
        this.lastTouchAt = 0;
        this.gesture = null;
        this.viewerDom = null;
        this.expanded = false;
        this.langOverride = "";
        this.box = document.createElement("section");
        this.box.className = "window-share";
        this.box.hidden = true;
        parent.append(this.box);
        this.peer = pc.createDataChannel("longvox-shared-window-v1", {negotiated:true, id:24, ordered:true});
        this.peer.binaryType = "arraybuffer";
        this.frames = pc.createDataChannel("longvox-shared-window-frames", {negotiated:true, id:25, ordered:true});
        this.frames.binaryType = "arraybuffer";
        this.frames.onmessage = event => this.receive(event.data, true);
        this.frames.onclose = () => {
            if (this.peerFrameChannel && this.id) this.endWithReason(this.id, "ended", "The window frame channel closed.");
        };
        this.nativeStopped = event => {
            const {id, reason, message} = event.detail;
            if (this.role === "owner" && this.id === id) this.endWithReason(id, reason, message);
        };
        window.addEventListener("longvox-window-stopped", this.nativeStopped);
        this.nativeControlEnded = event => {
            const {id, reason, message, retry} = event.detail;
            this.handleControlRevoked(id, reason, message, retry === true);
        };
        window.addEventListener("longvox-window-control-ended", this.nativeControlEnded);
        this.peer.onopen = async () => {
            try {
                const capInfo = await native("window_capabilities", {});
                this.canShare = capInfo?.share === true;
                this.nativeCanControl = capInfo?.control !== false;
                this.verifyNativeConnection = capInfo?.verifyConnection === true;
                this.controlV2 = capInfo?.controlV2 === true;
                this.nativeVersion = Number.isInteger(capInfo?.nativeVersion) ? capInfo.nativeVersion : 1;
                this.nativeCaps = new Set(Array.isArray(capInfo?.caps)
                    ? capInfo.caps.filter(c => typeof c === "string" && c.length <= 32) : []);
            } catch {
                this.canShare = false;
                this.nativeCaps = new Set();
            }
            const hello = {op:"hello", share:this.canShare, v:2, sas:true, connectionBinding:true, frameChannel:true};
            if (this.canShare && !this.nativeCanControl) hello.control = false;
            const caps = this.canShare ? new Set(this.nativeCaps) : new Set();
            caps.add("sas2");
            if (this.canShare) caps.add("inputAck");
            hello.caps = [...caps];
            this.send(hello);
            this.render();
        };
        this.peer.onmessage = event => this.receive(event.data);
        this.peer.onclose = () => this.close();
        this.linkChanged = () => {
            if (this.interrupted()) this.reset(true);
            else this.render();
        };
        for (const link of this.links) {
            link.addEventListener("connectionstatechange", this.linkChanged);
            link.addEventListener("iceconnectionstatechange", this.linkChanged);
        }
        this.viewportResized = () => {
            this.syncVisualViewport();
            this.clampTransform();
        };
        window.addEventListener("resize", this.viewportResized);
        window.addEventListener("orientationchange", this.viewportResized);
        window.visualViewport?.addEventListener("resize", this.viewportResized);
        window.visualViewport?.addEventListener("scroll", this.viewportResized);
        this.leaving = () => this.close();
        window.addEventListener("pagehide", this.leaving);
    }

    interrupted() {
        const lost = state => ["disconnected","failed","closed"].includes(state);
        return [...this.links].some(link => lost(link.connectionState) || lost(link.iceConnectionState));
    }
    send(msg, channel = this.peer) {
        if (channel.readyState !== "open") return false;
        const payload = CallWindowShare.wireJSON(msg, this.pc, 4096);
        if (!payload) return false;
        try {
            channel.send(payload);
            return true;
        } catch {
            this.close();
            return false;
        }
    }
    static wireJSON(message, pc, limit) {
        const text = JSON.stringify(message);
        const negotiated = pc.sctp?.maxMessageSize;
        const max = negotiated > 0 ? Math.min(limit, negotiated) : limit;
        return new TextEncoder().encode(text).byteLength <= max ? text : null;
    }
    get frameTransport() {
        return this.peerFrameChannel ? this.frames : this.peer;
    }
    async sendFrame(id, header, bytes) {
        const channel = this.frameTransport;
        const deadline = performance.now() + 2000;
        const chunkSize = Math.min(8192, this.pc.sctp?.maxMessageSize || 8192);
        const current = () => this.role === "owner" && this.id === id && this.viewing &&
            this.windowState !== "paused" && channel.readyState === "open" &&
            (!(this.codeBound || this.verifyNativeConnection) || this.connectionMatches(this));
        if (!current() || channel.bufferedAmount !== 0 || !this.send(header, channel)) return false;
        for (let i = 0; i < bytes.length; i += chunkSize) {
            // Yield even on a fast path so Stop can discard the unsent tail of a frame.
            do {
                await new Promise(resolve => setTimeout(resolve, channel.bufferedAmount ? 20 : 0));
                if (!current() || performance.now() >= deadline) return false;
            } while (channel.bufferedAmount !== 0);
            channel.send(bytes.subarray(i, i + chunkSize));
        }
        return true;
    }

    button(text, action) {
        const button = document.createElement("button");
        button.textContent = text;
        button.onclick = event => {
            if (!event.isTrusted) return;
            Promise.resolve(action()).catch(error => { this.note = error.message; this.render(); });
        };
        this.box.append(button);
        return button;
    }
    static allowsGroupWindowRoute(version, sas, binding, fingerprints) {
        return version === 2 && sas === true && binding === true && !!fingerprints &&
            fingerprints.localFingerprint !== fingerprints.remoteFingerprint;
    }
    groupRouteEligible() {
        return !this.groupRoute || CallWindowShare.allowsGroupWindowRoute(
            this.peerVersion, this.peerSas, this.peerConnectionBinding, this.connectionFingerprints());
    }
    async offer() {
        if (this.role || this.choosing || !this.groupRouteEligible() ||
            (this.groupRoute && !this.nativeCaps.has("sas"))) return;
        this.choosing = true;
        const generation = this.generation;
        try {
            const chooseArgs = {peerVersion:this.peerVersion};
            if (this.groupRoute) chooseArgs.groupWindowBinding = true;
            if (this.verifyNativeConnection || this.groupRoute) {
                const fingerprints = this.connectionFingerprints();
                if (!fingerprints) throw Error("The connected device could not be verified.");
                Object.assign(chooseArgs, fingerprints);
            }
            const result = await this.native("window_choose", chooseArgs);
            if (!result.id) return;
            if (this.closed || this.role || generation !== this.generation || this.pc.connectionState !== "connected" || this.interrupted()) {
                await this.native("window_stop", {id:result.id});
                return;
            }
            this.inboundAsk = this.asked = false;
            this.role = "owner";
            this.id = result.id;
            this.title = result.title;
            this.nativeVersion = Number.isInteger(result.nativeVersion) ? result.nativeVersion : 1;
            const wantsSas2 = this.peerVersion >= 2 && this.nativeCaps.has("sas2") && this.peerSas2;
            const sas2Info = wantsSas2 ? this.computeConnectionCodeV2(this.id) : null;
            if (sas2Info) {
                this.code = sas2Info.code;
                this.codeBound = true;
                this.sas2Bound = true;
                this.localFingerprint = sas2Info.localFingerprint;
                this.remoteFingerprint = sas2Info.remoteFingerprint;
            } else {
                const fps = (this.peerVersion >= 2 && this.nativeCaps.has("sas") && this.peerSas)
                    ? this.connectionFingerprints() : null;
                this.code = "";
                this.codeBound = Boolean(fps);
                this.sas2Bound = false;
                this.localFingerprint = fps?.localFingerprint ?? chooseArgs.localFingerprint ?? "";
                this.remoteFingerprint = fps?.remoteFingerprint ?? chooseArgs.remoteFingerprint ?? "";
            }
            this.note = "";
            const offerMsg = {op:"offer", id:this.id, title:this.title};
            const nativeBlocksControl = !this.nativeCanControl || result.control === false;
            this.viewOnly = nativeBlocksControl || !this.sas2Bound;
            this.viewOnlyReason = nativeBlocksControl ? "control_unavailable" : (!this.sas2Bound ? "update_required" : "");
            if (this.viewOnly) offerMsg.control = false;
            if (this.sas2Bound) {
                offerMsg.sas = true;
                offerMsg.sas2 = true;
            } else if (this.codeBound) {
                offerMsg.sas = true;
            }
            if (this.codeBound && this.peerConnectionBinding && this.localFingerprint && this.remoteFingerprint) {
                this.connectionBinding = CallWindowShare.deriveConnectionBinding(
                    this.id, this.localFingerprint, this.remoteFingerprint);
                offerMsg.binding = this.connectionBinding;
            }
            if ((this.groupRoute && !this.connectionBinding) ||
                (this.verifyNativeConnection && !this.connectionMatches(chooseArgs))) {
                this.reset(false);
                return;
            }
            if (!this.send(offerMsg)) { this.reset(false); return; }
            this.render();
            this.pump(this.id);
        } finally { this.choosing = false; }
    }
    shouldCaptureFrame(now = performance.now()) {
        if (!this.viewing || this.windowState === "paused" || this.peer.readyState !== "open") return false;
        if (this.frameTransport.readyState !== "open" || this.frameTransport.bufferedAmount !== 0) return false;
        if (this.peerVersion >= 2 && this.inFlightFrameSeq > this.lastAckedFrameSeq) {
            return now - this.lastFrameSentAt >= 2000;
        }
        return now - this.lastFrameSentAt >= 200;
    }
    schedulePump(id, delay = null) {
        if (this.role !== "owner" || this.id !== id) return;
        clearTimeout(this.timer);
        let waitMs = delay;
        if (waitMs === null) {
            if (!this.viewing || this.windowState === "paused") {
                waitMs = 650;
            } else {
                const elapsed = performance.now() - this.lastFrameSentAt;
                if (this.peerVersion >= 2 && this.inFlightFrameSeq > this.lastAckedFrameSeq) {
                    waitMs = Math.max(50, Math.min(500, 2000 - elapsed));
                } else {
                    waitMs = Math.max(50, 200 - elapsed);
                }
            }
        }
        this.timer = setTimeout(() => this.pump(id), waitMs);
    }
    async pump(id) {
        if (this.role !== "owner" || this.id !== id || this.pumping) return;
        clearTimeout(this.timer);
        this.timer = null;
        this.pumping = id;
        try {
            if ((this.codeBound || this.verifyNativeConnection) && !this.connectionMatches(this)) {
                this.endWithReason(id, "connection_changed", "The connected device changed.");
                return;
            }
            const capture = this.shouldCaptureFrame();
            const result = await this.native("window_frame", {
                id,
                capture,
                peerVersion:this.peerVersion,
            });
            if (this.role !== "owner" || this.id !== id) return;
            if (result?.controlRevoked) {
                this.handleControlRevoked(id, result.reason, result.message, result.retry === true);
            }
            this.applyWindowState(id, result);
            if (result.jpeg && this.viewing && this.windowState !== "paused" &&
                this.frameTransport.readyState === "open" && this.frameTransport.bufferedAmount === 0) {
                const raw = Uint8Array.from(atob(result.jpeg), c => c.charCodeAt(0));
                if (raw.length > 0 && raw.length <= 196608) {
                    const hasSeq = Number.isInteger(result.frameSeq) && result.frameSeq > 0;
                    const seq = hasSeq ? result.frameSeq : (this.inFlightFrameSeq + 1);
                    const header = {op:"frame", id, size:raw.length};
                    if (hasSeq || this.peerVersion >= 2) header.frameSeq = seq;
                    if (Number.isInteger(this.lastRttMs) && this.lastRttMs > 0) header.rttMs = this.lastRttMs;
                    if (Number.isInteger(result.quality) && result.quality > 0 && result.quality <= 100) {
                        header.q = result.quality;
                    }
                    if (await this.sendFrame(id, header, raw) && this.id === id) {
                        this.inFlightFrameSeq = seq;
                        this.lastFrameSentAt = performance.now();
                        this.frameSentTimes.set(seq, this.lastFrameSentAt);
                    }
                    if (this.frameSentTimes.size > 16) {
                        const oldest = this.frameSentTimes.keys().next().value;
                        this.frameSentTimes.delete(oldest);
                    }
                }
            }
        } catch (error) {
            if (this.id === id) {
                const message = error?.message || "Window sharing ended.";
                this.endWithReason(id, "ended", message);
            }
            return;
        } finally {
            if (this.pumping === id) this.pumping = false;
        }
        if (this.id === id) this.schedulePump(id);
    }
    applyWindowState(id, result) {
        if (this.role !== "owner" || this.id !== id || !result) return;
        const dropped = result.dropped === true;
        const state = typeof result.state === "string" ? result.state : this.windowState;
        const focused = result.focused === true;
        const typed = Number.isInteger(result.typed) && result.typed >= 0 ? result.typed : undefined;
        if (dropped) {
            if (typeof result.state === "string" && result.state !== this.windowState) {
                this.windowState = state;
                this.windowReason = typeof result.reason === "string" ? result.reason : "";
                this.windowMessage = typeof result.message === "string" ? result.message : "";
                this.render();
            }
            const reason = typeof result.dropReason === "string" ? result.dropReason : "refused";
            const message = typeof result.dropMessage === "string" && result.dropMessage
                ? result.dropMessage : "Input was refused on this computer.";
            this.send({
                op: "state",
                id,
                state,
                focused,
                reason,
                message,
                dropped: true,
                ...(typed !== undefined ? {typed} : {}),
            });
            return;
        }
        if (typeof result.state !== "string") return;
        const reason = typeof result.reason === "string" ? result.reason : "";
        const message = typeof result.message === "string" ? result.message : "";
        if (state === this.windowState && reason === this.windowReason && message === this.windowMessage && typed === undefined) return;
        this.windowState = state;
        this.windowReason = reason;
        this.windowMessage = message;
        this.send({
            op: "state",
            id,
            state,
            focused,
            ...(reason ? {reason} : {}),
            ...(message ? {message} : {}),
            ...(typed !== undefined ? {typed} : {}),
        });
        this.render();
    }
    handleControlRevoked(id, reason, message, retry = false, typed = undefined) {
        if (this.role !== "owner" || this.id !== id) return;
        const text = typeof message === "string" && message ? message : "Control ended on this computer.";
        this.control = false;
        this.dragEndBypass = false;
        this.requested = false;
        this.denied = !retry;
        this.approvalSeq++;
        this.note = text;
        if (this.peerVersion < 2) {
            this.endWithReason(id, reason, text);
            return;
        }
        const typedField = Number.isInteger(typed) && typed >= 0 ? {typed} : {};
        this.send({
            op: "revoked",
            id,
            reason: typeof reason === "string" ? reason : "revoked",
            message: text,
            ...(retry ? {retry: true} : {}),
            ...typedField,
        });
        this.render();
    }
    startHeartbeat(id) {
        clearInterval(this.heartbeatTimer);
        this.heartbeatTimer = null;
        if (this.peerVersion < 2) return;
        const beat = () => {
            if (this.role === "viewer" && this.id === id) this.send({op:"heartbeat", id});
        };
        beat();
        this.heartbeatTimer = setInterval(beat, 4000);
    }
    sendInput(fields) {
        if (!this.control || !this.id || (this.codeBound && !this.connectionMatches(this))) return false;
        if (fields.kind === "key" && this.textSend) return false;
        if (this.windowState === "paused" && fields.kind !== "dragEnd") {
            this.showDropAlert(this.windowReason || "paused", this.windowMessage || "Control is paused on " + this.name + ".");
            return false;
        }
        const payload = {op:"input", id:this.id, ...fields};
        if (this.peerVersion >= 2) {
            payload.seq = ++this.inputSeq;
            if (["click", "double", "rightClick", "scroll", "dragStart", "dragMove"].includes(fields.kind) && this.lastFrameSeq > 0) {
                payload.frameSeq = this.lastFrameSeq;
            }
        }
        const sent = this.send(payload);
        if (sent && typeof fields.x === "number" && typeof fields.y === "number" &&
            ["click", "double", "rightClick", "dragStart", "dragMove", "dragEnd"].includes(fields.kind)) {
            this.showPointerMarker(fields.kind, fields.x, fields.y);
        }
        return sent;
    }
    acceptsInput(kind, key, mods) {
        switch (kind) {
        case "click": case "double": case "scroll":
            return true;
        case "key":
            return this.nativeCaps.has("keyMods") ||
                (!mods?.length && typeof key === "string" &&
                    ([...key].length === 1 || ["Backspace", "Enter", "ArrowLeft", "ArrowRight", "ArrowUp", "ArrowDown"].includes(key)));
        case "rightClick":
            return this.nativeCaps.has("rightClick");
        case "dragStart": case "dragMove": case "dragEnd":
            return this.nativeCaps.has("drag");
        case "text":
            return this.nativeCaps.has("text");
        default:
            return false;
        }
    }
    endWithReason(id, reason, message) {
        if (this.id !== id) return;
        const text = typeof message === "string" ? message : "";
        this.send({op:"stop", id, reason:typeof reason === "string" ? reason : "ended", ...(text ? {message:text} : {})});
        this.reset(false);
        if (text) { this.note = text; this.render(); }
    }
    async requestOwnerApproval() {
        if (this.viewOnly || !this.sas2Bound) return;
        if (this.controlV2) {
            if (this.preparingApproval) return;
            const pending = this.preparingApproval = {id:this.id, generation:this.generation};
            try {
                const result = await this.native("window_request_approve", {id:pending.id, sas2:true});
                if (this.generation !== pending.generation) return;
                if (result?.pending !== true) {
                    this.send({op:"denied", id:pending.id, reason:result?.code || "denied", detail:result?.reason});
                    return;
                }
            } catch {
                if (this.generation === pending.generation) {
                    this.send({op:"denied", id:pending.id, reason:"unavailable"});
                }
                return;
            } finally {
                if (this.preparingApproval === pending) this.preparingApproval = null;
            }
        }
        this.requested = true;
        this.render();
    }
    async acceptView(msg) {
        const id = this.id;
        if (this.connectionBinding && msg.binding !== this.connectionBinding) {
            this.endWithReason(id, "connection_changed", "The connected device could not be verified.");
            return;
        }
        if (this.groupRoute && this.verifyNativeConnection) {
            if (this.confirmingView) return;
            this.confirmingView = id;
            try {
                await this.native("window_confirm_connection", {id, binding:msg.binding});
            } catch {
                this.endWithReason(id, "connection_changed", "The connected device could not be verified.");
                return;
            } finally {
                if (this.confirmingView === id) this.confirmingView = null;
            }
        }
        if (this.id !== id) return;
        this.viewing = true;
        this.render();
        if (!this.pumping) this.schedulePump(id, 0);
        if (this.requestAfterView) {
            this.requestAfterView = false;
            void this.requestOwnerApproval();
        }
    }
    async grant() {
        const id = this.id;
        if (this.granting || this.viewOnly || !this.sas2Bound || !this.requested || this.denied) return;
        if (!this.connectionMatches(this)) {
            this.endWithReason(id, "connection_changed", "The connected device changed.");
            return;
        }
        const seq = this.approvalSeq;
        this.granting = true;
        this.render();
        try {
            const approveArgs = {
                id,
                code: this.code,
                localFingerprint: this.localFingerprint,
                remoteFingerprint: this.remoteFingerprint,
            };
            const granted = await this.native("window_approve", approveArgs);
            if (this.id !== id || this.denied || !this.requested || this.approvalSeq !== seq) {
                if (granted?.allowed === true && this.nativeVersion >= 2) {
                    this.native("window_cancel_approve", {id, decline:true}).catch(() => {});
                }
                return;
            }
            this.control = granted?.allowed === true;
            this.requested = false;
            if (this.control) {
                this.note = "";
                this.send({op:"granted", id});
            } else {
                const retry = granted?.retry === true;
                this.denied = !retry;
                const code = typeof granted?.code === "string" ? granted.code : "denied";
                const detail = typeof granted?.reason === "string" ? granted.reason : "";
                if (detail) this.note = detail;
                this.send({op:"denied", id, reason:code, ...(detail ? {detail} : {}), ...(retry ? {retry:true} : {})});
            }
        } catch (error) {
            if (this.id !== id || this.denied || !this.requested || this.approvalSeq !== seq) return;
            this.control = false;
            this.requested = false;
            this.denied = true;
            const detail = error?.message || "Control is unavailable on this computer.";
            this.note = detail;
            this.send({op:"denied", id, reason:"unavailable", detail});
        } finally { this.granting = false; this.render(); }
    }
    declineControl() {
        if (!this.id || this.role !== "owner") return;
        const id = this.id;
        this.denied = true;
        this.requested = false;
        this.control = false;
        this.dragEndBypass = false;
        this.approvalSeq++;
        this.send({op:"denied", id});
        if (this.nativeVersion >= 2) {
            this.native("window_cancel_approve", {id, decline:true}).catch(() => {});
        }
        this.render();
    }
    receive(data, frameChannel = false) {
        if (this.closed || (frameChannel && !this.peerFrameChannel)) return;
        if (data instanceof ArrayBuffer) {
            if ((this.codeBound && !this.connectionMatches(this)) ||
                frameChannel !== Boolean(this.peerFrameChannel) || this.role !== "viewer" || !this.viewing || !this.frame || data.byteLength > 12288 ||
                !data.byteLength || this.offset + data.byteLength > this.frame.length) return;
            this.frame.set(new Uint8Array(data), this.offset);
            this.offset += data.byteLength;
            if (this.offset === this.frame.length) {
                const frame = this.frame;
                this.frame = null;
                // Only baseline JPEGs of bounded dimensions from the two native encoders.
                if (!CallWindowShare.validJPEG(frame)) return;
                const ackSeq = this.pendingFrameSeq;
                if (ackSeq > 0) this.lastFrameSeq = ackSeq;
                const now = Date.now();
                this.lastFrameAt = now;
                this.lastFrameBytes = frame.length;
                if (this.pendingFrameRttMs != null) this.lastRttMs = this.pendingFrameRttMs;
                if (this.pendingFrameQuality != null) this.lastFrameQuality = this.pendingFrameQuality;
                this.frameTimes.push(now);
                while (this.frameTimes.length > 0 && now - this.frameTimes[0] > 3000) this.frameTimes.shift();
                const next = URL.createObjectURL(new Blob([frame], {type:"image/jpeg"}));
                this.image.src = next;
                if (this.url) URL.revokeObjectURL(this.url);
                this.url = next;
                if (this.peerVersion >= 2 && ackSeq > 0) {
                    this.send({op:"ack", id:this.id, frameSeq:ackSeq});
                }
                this.updateMetricsBadge();
            }
            return;
        }
        if (typeof data !== "string" || data.length > 1024 || new TextEncoder().encode(data).byteLength > 4096) return;
        let msg;
        try { msg = JSON.parse(data); } catch { return; }
        if (!msg || typeof msg !== "object") return;
        if (frameChannel && msg.op !== "frame") return;
        if (msg.op === "hello") {
            if (!this.ready) {
                this.ready = true;
                this.peerCanShare = msg.share === true;
                this.peerViewOnly = msg.control === false;
                this.peerVersion = msg.v === 2 ? 2 : 1;
                this.peerFrameChannel = this.peerVersion === 2 && msg.frameChannel === true;
                this.peerCaps = new Set(Array.isArray(msg.caps)
                    ? msg.caps.filter(c => typeof c === "string" && c.length <= 32).slice(0, 16) : []);
                this.peerSas = msg.sas === true || this.peerCaps.has("sas");
                this.peerSas2 = this.peerVersion === 2 && this.peerCaps.has("sas2");
                this.peerConnectionBinding = this.peerVersion === 2 && msg.connectionBinding === true;
                this.render();
            }
            return;
        }
        if (!this.ready || this.interrupted()) return;
        if (!this.groupRouteEligible()) {
            if (msg.op === "offer" && typeof msg.id === "string" && /^[a-f0-9-]{36}$/.test(msg.id)) {
                this.send({op: "stop", id: msg.id, reason: "connection_changed"});
            }
            return;
        }
        if (this.id && this.codeBound && !this.connectionMatches(this)) {
            this.endWithReason(this.id, "connection_changed", "The connected device changed.");
            return;
        }
        if (msg.op === "ask" && this.canShare && !this.role) {
            if (this.inboundAsk || Date.now()-this.lastInvitation < 60000) {
                this.send({op:"unavailable"}); return;
            }
            this.lastInvitation = Date.now(); this.inboundAsk = true; this.render(); return;
        }
        if (msg.op === "cancelAsk") { this.inboundAsk = false; this.render(); return; }
        if (msg.op === "unavailable" && this.asked && !this.role) {
            this.asked = false;
            this.note = this.t("peerUnavailable", {name: this.name});
            this.render();
            return;
        }
        if (msg.op === "offer" && !this.role && !this.choosing && typeof msg.id === "string" &&
            /^[a-f0-9-]{36}$/.test(msg.id) && typeof msg.title === "string" && msg.title.length <= 180) {
            this.inboundAsk = this.asked = false;
            if (this.groupRoute && (msg.sas !== true || !this.peerCaps.has("sas"))) {
                this.send({op:"stop", id:msg.id, reason:"connection_changed"});
                return;
            }
            if (msg.sas2 === true) {
                if (!this.peerSas2) {
                    this.send({op:"stop", id:msg.id, reason:"connection_changed"});
                    return;
                }
                const sas2Info = this.computeConnectionCodeV2(msg.id);
                if (!sas2Info) {
                    this.note = this.t("refusedGeneric", {name: this.name});
                    this.send({op: "stop", id: msg.id, reason: "connection_changed"});
                    this.render();
                    return;
                }
                if (this.peerConnectionBinding) {
                    const expected = CallWindowShare.deriveConnectionBinding(
                        msg.id, sas2Info.remoteFingerprint, sas2Info.localFingerprint);
                    if (msg.binding !== expected) {
                        this.send({op:"stop", id:msg.id, reason:"connection_changed"});
                        return;
                    }
                    this.connectionBinding = expected;
                }
                this.code = sas2Info.code;
                this.codeBound = true;
                this.sas2Bound = true;
                this.localFingerprint = sas2Info.localFingerprint;
                this.remoteFingerprint = sas2Info.remoteFingerprint;
                const peerBlocksControl = msg.control === false || this.peerViewOnly;
                this.viewOnly = peerBlocksControl;
                this.viewOnlyReason = peerBlocksControl ? "control_unavailable" : "";
            } else {
                if (msg.sas === true) {
                    const fps = this.connectionFingerprints();
                    if (!fps) {
                        this.note = this.t("refusedGeneric", {name: this.name});
                        this.send({op: "stop", id: msg.id, reason: "connection_changed"});
                        this.render();
                        return;
                    }
                    if (this.peerConnectionBinding) {
                        const expected = CallWindowShare.deriveConnectionBinding(
                            msg.id, fps.remoteFingerprint, fps.localFingerprint);
                        if (msg.binding !== expected) {
                            this.send({op:"stop", id:msg.id, reason:"connection_changed"});
                            return;
                        }
                        this.connectionBinding = expected;
                    }
                    this.codeBound = true;
                    this.localFingerprint = fps.localFingerprint;
                    this.remoteFingerprint = fps.remoteFingerprint;
                } else {
                    if (msg.binding !== undefined || (this.peerConnectionBinding && this.peerCaps.has("sas") && this.peerSas)) {
                        this.send({op:"stop", id:msg.id, reason:"connection_changed"});
                        return;
                    }
                    this.codeBound = false;
                    this.localFingerprint = "";
                    this.remoteFingerprint = "";
                }
                this.code = "";
                this.sas2Bound = false;
                this.viewOnly = true;
                this.viewOnlyReason = (msg.control === false || this.peerViewOnly) && this.peerSas2
                    ? "control_unavailable" : "update_required";
            }
            this.role = "viewer"; this.id = msg.id; this.title = msg.title; this.note = "";
            this.startHeartbeat(msg.id);
            this.render(); return;
        }
        if (!this.id || msg.id !== this.id) return;
        if (msg.op === "stop") {
            const note = typeof msg.message === "string" && msg.message.length <= 240 ? msg.message : "";
            this.reset(false);
            if (note) { this.note = note; this.render(); }
            return;
        }
        if (this.role === "owner") {
            if (msg.op === "heartbeat") {
                const now = performance.now();
                if (this.nativeVersion >= 2 && this.peerVersion === 2 &&
                    now - this.lastForwardedHeartbeat >= 1000) {
                    this.lastForwardedHeartbeat = now;
                    const id = this.id;
                    this.native("window_heartbeat", {id, peerVersion:this.peerVersion}).catch(error => {
                        if (this.id === id) this.endWithReason(id, "ended", error?.message || "Window sharing ended.");
                    });
                }
                return;
            }
            if (msg.op === "ack") {
                if (this.peerVersion === 2 && this.frameSentTimes.has(msg.frameSeq) &&
                    msg.frameSeq > this.lastAckedFrameSeq) {
                    const sentAt = this.frameSentTimes.get(msg.frameSeq);
                    const sample = Math.max(1, Math.min(30000, performance.now() - sentAt));
                    this.lastRttMs = this.lastRttMs == null ? sample : Math.round(this.lastRttMs * 0.4 + sample * 0.6);
                    for (const key of this.frameSentTimes.keys()) {
                        if (key <= msg.frameSeq) this.frameSentTimes.delete(key);
                    }
                    this.lastAckedFrameSeq = msg.frameSeq;
                    if (!this.pumping) {
                        const waitMs = Math.max(0, 200 - (performance.now() - this.lastFrameSentAt));
                        this.schedulePump(this.id, waitMs);
                    }
                }
                return;
            }
            if (msg.op === "view" && !this.viewing) {
                void this.acceptView(msg);
            }
            if (msg.op === "request" && (this.viewOnly || !this.sas2Bound)) {
                if (!this.denied) {
                    this.denied = true;
                    const needsUpdate = this.viewOnlyReason === "update_required" || !this.sas2Bound;
                    this.send({
                        op: "denied",
                        id: this.id,
                        reason: needsUpdate ? "update_required" : "control_unavailable",
                        detail: needsUpdate
                            ? "Update Longvox on the other device to allow control."
                            : "Mac window sharing is view only.",
                    });
                }
                return;
            }
            if (msg.op === "request" && !this.control && !this.requested && !this.denied) {
                if (this.viewing) void this.requestOwnerApproval();
                else if (this.confirmingView === this.id) this.requestAfterView = true;
            }
            if (msg.op === "input" && this.control && this.viewing) {
                const {kind,x,y,key,text,mods,delta,seq,frameSeq} = msg;
                const acceptedKind = this.acceptsInput(kind, key, mods);
                const canBypassQueueCap = kind === "dragEnd" && this.dragEndBypass && acceptedKind;
                if (this.pendingInputs >= 24 && !canBypassQueueCap) {
                    const queueMsg = "Input queue is full on this computer. Try again.";
                    this.send({
                        op: "state",
                        id: this.id,
                        state: this.windowState,
                        focused: this.windowState === "active",
                        reason: "queue_full",
                        message: queueMsg,
                        dropped: true,
                        ...(kind === "text" ? {typed: 0} : {}),
                    });
                    if (Number.isInteger(seq)) {
                        this.send({
                            op: "inputAck", id: this.id, seq, ok: false, reason: "queue_full", message: queueMsg,
                            ...(kind === "text" ? {typed: 0} : {}),
                        });
                    }
                    return;
                }
                if (!acceptedKind) {
                    if (Number.isInteger(seq)) {
                        this.send({
                            op: "inputAck", id: this.id, seq, ok: false, reason: "refused",
                            message: "Input was refused on this computer.",
                            ...(kind === "text" ? {typed: 0} : {}),
                        });
                    }
                    return;
                }
                if (kind === "dragStart") this.dragEndBypass = true;
                else if (kind === "dragEnd") this.dragEndBypass = false;
                const id = this.id;
                const payload = {id,kind,x,y,key,delta,peerVersion:this.peerVersion};
                if (typeof text === "string" && text.length > 0 && text.length <= 256) payload.text = text;
                if (Array.isArray(mods) && mods.length > 0 && mods.length <= 4 &&
                    mods.every(m => typeof m === "string" && ["cmd","opt","ctrl","shift"].includes(m))) {
                    payload.mods = [...new Set(mods)];
                }
                if (Number.isInteger(seq)) payload.seq = seq;
                if (Number.isInteger(frameSeq)) payload.frameSeq = frameSeq;
                this.pendingInputs++;
                this.inputChain = this.inputChain.then(async () => {
                    if (this.control && this.id === id) {
                        const result = await this.native("window_input", payload);
                        const typed = kind === "text" && Number.isInteger(result?.typed) && result.typed >= 0
                            ? result.typed : undefined;
                        if (result?.controlRevoked) {
                            const reason = typeof result.reason === "string" ? result.reason : "revoked";
                            const message = typeof result.message === "string" && result.message
                                ? result.message : "Control ended on this computer.";
                            if (this.id === id && Number.isInteger(seq)) {
                                this.send({
                                    op: "inputAck", id, seq, ok: false, reason, message,
                                    ...(typed !== undefined ? {typed} : {}),
                                });
                            }
                            this.handleControlRevoked(id, reason, message, result.retry === true, typed);
                        } else {
                            this.applyWindowState(id, result);
                            if (this.id === id && Number.isInteger(seq)) {
                                if (result?.dropped === true) {
                                    const reason = typeof result.dropReason === "string" ? result.dropReason : "refused";
                                    const message = typeof result.dropMessage === "string" && result.dropMessage
                                        ? result.dropMessage : "Input was refused on this computer.";
                                    this.send({
                                        op: "inputAck", id, seq, ok: false, reason, message,
                                        ...(typed !== undefined ? {typed} : {}),
                                    });
                                } else if (result?.state === "paused") {
                                    const reason = typeof result.reason === "string" && result.reason ? result.reason : "paused";
                                    const message = typeof result.message === "string" ? result.message : "";
                                    this.send({
                                        op: "inputAck", id, seq, ok: false, reason, message,
                                        ...(typed !== undefined ? {typed} : {}),
                                    });
                                } else {
                                    const okTyped = kind === "text"
                                        ? (typed !== undefined ? typed : (payload.text?.length ?? 0))
                                        : undefined;
                                    this.send({
                                        op: "inputAck", id, seq, ok: true,
                                        ...(okTyped !== undefined ? {typed: okTyped} : {}),
                                    });
                                }
                            }
                        }
                    } else if (this.id === id && Number.isInteger(seq)) {
                        this.send({
                            op: "inputAck", id, seq, ok: false, reason: "denied", message: "Control is not active.",
                            ...(kind === "text" ? {typed: 0} : {}),
                        });
                    }
                }).catch(error => {
                    if (this.id === id) this.endWithReason(id, "ended", error?.message || "Window sharing ended.");
                }).finally(() => { this.pendingInputs--; });
            }
        } else if (this.role === "viewer") {
            if (msg.op === "inputAck") {
                const pending = this.textSend;
                if (!pending || pending.inFlightSeq !== msg.seq) return;
                clearTimeout(pending.timer);
                pending.timer = null;
                pending.inFlightSeq = null;
                const hasTyped = Number.isInteger(msg.typed) && msg.typed >= 0;
                if (msg.ok === true) {
                    if (hasTyped) this.dropTypedUnits(pending.chunks, msg.typed);
                    else pending.chunks.shift();
                    if (pending.stopOnAck) {
                        this.restorePendingText(pending.stopOnAck.reason, pending.stopOnAck.message);
                    } else {
                        this.pumpTextQueue();
                    }
                } else {
                    const ackReason = typeof msg.reason === "string" && msg.reason.length <= 64 ? msg.reason : "refused";
                    const ackMessage = typeof msg.message === "string" && msg.message.length <= 240 ? msg.message : "";
                    const reason = pending.stopOnAck && ackReason === "denied" ? pending.stopOnAck.reason : ackReason;
                    const message = pending.stopOnAck && ackReason === "denied" ? pending.stopOnAck.message : ackMessage;
                    if (hasTyped) {
                        this.restorePendingText(reason, message, {typed: msg.typed});
                    } else {
                        this.restorePendingText(reason, message, {uncertainInFlight: true});
                    }
                }
                return;
            }
            if (msg.op === "state" && ["active", "paused", "closed"].includes(msg.state)) {
                const reason = typeof msg.reason === "string" && msg.reason.length <= 64 ? msg.reason : "";
                const message = typeof msg.message === "string" && msg.message.length <= 240 ? msg.message : "";
                const hasTyped = Number.isInteger(msg.typed) && msg.typed >= 0;
                if (msg.dropped === true) {
                    if (this.textSend && !this.peerCaps.has("inputAck")) {
                        this.restorePendingText(reason, message, hasTyped ? {typed: msg.typed} : {uncertainInFlight: true});
                        return;
                    }
                    this.showDropAlert(reason, message);
                    return;
                }
                this.windowState = msg.state;
                this.windowReason = reason;
                this.windowMessage = message;
                if (msg.state === "paused") {
                    this.clearStickyMods();
                    if (this.textSend) {
                        if (this.textSend.inFlightSeq != null) {
                            if (hasTyped) {
                                this.restorePendingText(reason || "paused", message, {typed: msg.typed});
                            } else {
                                this.textSend.stopOnAck = {reason: reason || "paused", message};
                                this.render();
                            }
                            return;
                        }
                        this.restorePendingText(reason || "paused", message);
                        return;
                    }
                }
                this.render();
                return;
            }
            if (!this.viewing) return;
            if (msg.op === "frame" && frameChannel === Boolean(this.peerFrameChannel) && Number.isInteger(msg.size) && msg.size > 0 && msg.size <= 196608) {
                this.frame = new Uint8Array(msg.size);
                this.offset = 0;
                this.pendingFrameSeq = Number.isInteger(msg.frameSeq) && msg.frameSeq > 0 ? msg.frameSeq : 0;
                this.pendingFrameRttMs = Number.isInteger(msg.rttMs) && msg.rttMs > 0 && msg.rttMs <= 30000 ? msg.rttMs : null;
                this.pendingFrameQuality = Number.isInteger(msg.q) && msg.q > 0 && msg.q <= 100 ? msg.q : null;
            } else if (!this.viewOnly && this.sas2Bound && this.requested && !this.denied && (msg.op === "granted" || msg.op === "denied")) {
                this.control = msg.op === "granted";
                this.denied = !this.control && msg.retry !== true;
                this.requested = false;
                if (!this.control) {
                    const detail = typeof msg.detail === "string" && msg.detail.length <= 240 ? msg.detail : "";
                    const reason = typeof msg.reason === "string" ? msg.reason : "";
                    this.deniedCode = reason || "denied";
                    this.deniedDetail = detail;
                    this.deniedReason = CallWindowShare.reasonMessage(this.lang(), this.deniedCode, detail, this.name);
                    this.showDropAlert(this.deniedCode, this.deniedReason);
                    return;
                }
                this.render();
            } else if (msg.op === "revoked") {
                const detail = typeof msg.message === "string" && msg.message.length <= 240 ? msg.message : "";
                const reason = typeof msg.reason === "string" ? msg.reason : "revoked";
                const message = CallWindowShare.reasonMessage(this.lang(), reason, detail, this.name);
                this.control = false;
                this.requested = false;
                this.denied = msg.retry !== true;
                this.deniedCode = reason;
                this.deniedDetail = detail;
                this.deniedReason = message;
                if (this.textSend) {
                    const hasTyped = Number.isInteger(msg.typed) && msg.typed >= 0;
                    if (hasTyped) {
                        this.restorePendingText("", "", {typed: msg.typed});
                    } else if (this.textSend.inFlightSeq != null && this.peerCaps.has("inputAck")) {
                        const pending = this.textSend;
                        pending.stopOnAck = {reason, message};
                        clearTimeout(pending.timer);
                        const waitMs = Math.min(this.textAckTimeoutMs, 2000);
                        pending.timer = setTimeout(() => {
                            if (this.textSend === pending) {
                                this.restorePendingText("text_uncertain", "", {uncertainInFlight: true});
                            }
                        }, waitMs);
                    } else {
                        this.restorePendingText();
                    }
                }
                this.showDropAlert(reason, message);
            }
        }
    }
    // Synchronous FIPS 180-4 SHA-256 (works identically on file:// WKWebView, loopback HTTP, and HTTPS).
    static sha256(bytes) {
        const K = [
            0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
            0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
            0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
            0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
            0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
            0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
            0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
            0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2,
        ];
        const H = new Uint32Array([
            0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19,
        ]);
        const bitLen = bytes.length * 8;
        const paddedLen = Math.ceil((bytes.length + 9) / 64) * 64;
        const buf = new Uint8Array(paddedLen);
        buf.set(bytes);
        buf[bytes.length] = 0x80;
        const view = new DataView(buf.buffer);
        view.setUint32(paddedLen - 8, Math.floor(bitLen / 0x100000000), false);
        view.setUint32(paddedLen - 4, bitLen >>> 0, false);
        const w = new Uint32Array(64);
        const rotr = (x, n) => (x >>> n) | (x << (32 - n));
        for (let off = 0; off < paddedLen; off += 64) {
            for (let i = 0; i < 16; i++) w[i] = view.getUint32(off + i * 4, false);
            for (let i = 16; i < 64; i++) {
                const s0 = rotr(w[i-15], 7) ^ rotr(w[i-15], 18) ^ (w[i-15] >>> 3);
                const s1 = rotr(w[i-2], 17) ^ rotr(w[i-2], 19) ^ (w[i-2] >>> 10);
                w[i] = (w[i-16] + s0 + w[i-7] + s1) >>> 0;
            }
            let [a, b, c, d, e, f, g, h] = H;
            for (let i = 0; i < 64; i++) {
                const S1 = rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25);
                const ch = (e & f) ^ (~e & g);
                const t1 = (h + S1 + ch + K[i] + w[i]) >>> 0;
                const S0 = rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22);
                const maj = (a & b) ^ (a & c) ^ (b & c);
                const t2 = (S0 + maj) >>> 0;
                h = g; g = f; f = e; e = (d + t1) >>> 0;
                d = c; c = b; b = a; a = (t1 + t2) >>> 0;
            }
            H[0] = (H[0] + a) >>> 0; H[1] = (H[1] + b) >>> 0;
            H[2] = (H[2] + c) >>> 0; H[3] = (H[3] + d) >>> 0;
            H[4] = (H[4] + e) >>> 0; H[5] = (H[5] + f) >>> 0;
            H[6] = (H[6] + g) >>> 0; H[7] = (H[7] + h) >>> 0;
        }
        const out = new Uint8Array(32);
        const outView = new DataView(out.buffer);
        for (let i = 0; i < 8; i++) outView.setUint32(i * 4, H[i], false);
        return out;
    }
    static normalizeFingerprint(raw) {
        if (typeof raw !== "string") return null;
        const m = raw.trim().match(/^sha-256\s+([0-9a-f]{2}(?::[0-9a-f]{2}){31})$/i);
        if (!m) return null;
        return "sha-256 " + m[1].toUpperCase();
    }
    static extractFingerprintFromSDP(sdp) {
        if (typeof sdp !== "string" || !sdp) return null;
        const fps = new Set();
        for (const rawLine of sdp.split(/\r?\n/)) {
            const line = rawLine.trim();
            if (!line) continue;
            if (/^a=fingerprint:/i.test(line)) {
                const norm = CallWindowShare.normalizeFingerprint(line.slice(14));
                if (!norm) return null;
                fps.add(norm);
            }
        }
        return fps.size === 1 ? fps.values().next().value : null;
    }
    static fingerprintFromCertificate(cert) {
        if (!(cert instanceof ArrayBuffer) && !ArrayBuffer.isView(cert)) return null;
        const bytes = cert instanceof ArrayBuffer
            ? new Uint8Array(cert)
            : new Uint8Array(cert.buffer, cert.byteOffset, cert.byteLength);
        if (!bytes.byteLength) return null;
        const digest = CallWindowShare.sha256(bytes);
        return "sha-256 " + Array.from(digest, b => b.toString(16).padStart(2, "0")).join(":").toUpperCase();
    }
    dtlsRemoteFingerprint() {
        const transport = this.pc?.sctp?.transport;
        if (typeof transport?.getRemoteCertificates !== "function") return undefined;
        let certs;
        try { certs = transport.getRemoteCertificates(); } catch { return null; }
        if (!Array.isArray(certs) || certs.length === 0) {
            return transport.state === "connected" ? null : undefined;
        }
        return CallWindowShare.fingerprintFromCertificate(certs[0]);
    }
    static deriveApprovalCodeV2(sessionId, localFingerprint, remoteFingerprint) {
        if (typeof sessionId !== "string" || !/^[a-f0-9-]{36}$/i.test(sessionId)) return null;
        const a = CallWindowShare.normalizeFingerprint(localFingerprint);
        const b = CallWindowShare.normalizeFingerprint(remoteFingerprint);
        if (!a || !b) return null;
        const first = a <= b ? a : b;
        const second = a <= b ? b : a;
        const payload = `longvox-window-sas-v2|${sessionId.toLowerCase()}|${first}|${second}`;
        let digest = CallWindowShare.sha256(new TextEncoder().encode(payload));
        for (let round = 1; round < 4096; round++) {
            digest = CallWindowShare.sha256(digest);
        }
        const alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
        const b0 = digest[0], b1 = digest[1], b2 = digest[2], b3 = digest[3];
        const b4 = digest[4], b5 = digest[5], b6 = digest[6];
        const raw = alphabet[(b0 >> 3) & 31]
            + alphabet[((b0 & 7) << 2) | ((b1 >> 6) & 3)]
            + alphabet[(b1 >> 1) & 31]
            + alphabet[((b1 & 1) << 4) | ((b2 >> 4) & 15)]
            + alphabet[((b2 & 15) << 1) | ((b3 >> 7) & 1)]
            + alphabet[(b3 >> 2) & 31]
            + alphabet[((b3 & 3) << 3) | ((b4 >> 5) & 7)]
            + alphabet[b4 & 31]
            + alphabet[(b5 >> 3) & 31]
            + alphabet[((b5 & 7) << 2) | ((b6 >> 6) & 3)];
        return raw.slice(0, 5) + " " + raw.slice(5);
    }
    static deriveConnectionBinding(sessionId, ownerFingerprint, viewerFingerprint) {
        const payload = `longvox-window-binding-v1|${sessionId}|${ownerFingerprint}|${viewerFingerprint}`;
        const digest = CallWindowShare.sha256(new TextEncoder().encode(payload));
        return Array.from(digest, byte => byte.toString(16).padStart(2, "0")).join("");
    }
    connectionFingerprints() {
        const localFingerprint = CallWindowShare.extractFingerprintFromSDP(this.pc?.localDescription?.sdp);
        const remoteFingerprint = CallWindowShare.extractFingerprintFromSDP(this.pc?.remoteDescription?.sdp);
        if (!localFingerprint || !remoteFingerprint) return null;
        const dtlsRemote = this.dtlsRemoteFingerprint();
        if (dtlsRemote !== undefined && dtlsRemote !== remoteFingerprint) return null;
        return {localFingerprint, remoteFingerprint};
    }
    connectionMatches({localFingerprint, remoteFingerprint}) {
        const current = this.connectionFingerprints();
        return current?.localFingerprint === localFingerprint && current?.remoteFingerprint === remoteFingerprint;
    }
    computeConnectionCodeV2(sessionId) {
        const fingerprints = this.connectionFingerprints();
        if (!fingerprints || fingerprints.localFingerprint === fingerprints.remoteFingerprint) return null;
        const {localFingerprint, remoteFingerprint} = fingerprints;
        const code = CallWindowShare.deriveApprovalCodeV2(sessionId, localFingerprint, remoteFingerprint);
        if (!code) return null;
        return {code, localFingerprint, remoteFingerprint};
    }
    static validJPEG(bytes) {
        if (bytes[0] !== 255 || bytes[1] !== 216) return false;
        for (let p=2; p+8<bytes.length && bytes[p] === 255;) {
            const marker = bytes[p+1], n = bytes[p+2]*256+bytes[p+3];
            if (n < 2 || p+2+n > bytes.length) return false;
            if (marker === 192 || marker === 194) {
                const h=bytes[p+5]*256+bytes[p+6], w=bytes[p+7]*256+bytes[p+8];
                return h>0 && w>0 && h<=1280 && w<=1280;
            }
            p += 2+n;
        }
        return false;
    }
    static resolveLang(override = "") {
        const explicit = typeof override === "string" && override
            ? override
            : (typeof document !== "undefined" ? (document.documentElement?.dataset?.lang || "") : "");
        const raw = globalThis.longvoxMacInterfaceLanguage || explicit || (typeof navigator !== "undefined"
            ? ((Array.isArray(navigator.languages) && navigator.languages[0]) || navigator.language || "")
            : "");
        return /^ru\b/i.test(raw) ? "ru" : "en";
    }
    static isCoarsePointer() {
        return typeof window !== "undefined" && typeof window.matchMedia === "function"
            && window.matchMedia("(pointer: coarse)").matches;
    }
    static STRINGS = {
        en: {
            askBtn: ({name}) => `Ask ${name} to share a window`,
            inboundAsk: ({name}) => `${name} asked to view a window (view only). Control requires a separate approval.`,
            chooseWindow: () => "Choose a window",
            declineRequest: () => "Decline request",
            shareWith: ({name}) => `Share window with ${name}`,
            updateGroupHost: () => "Update Longvox on the PC to share a window with this participant.",
            updateOtherForControl: () => "Update Longvox on the other device to allow control.",
            waitingToChoose: ({name}) => `Waiting for ${name} to choose a window (view only)…`,
            cancelRequest: () => "Cancel request",
            peerUnavailable: ({name}) => `${name} is unavailable for window sharing.`,
            ownerViewing: ({title, name}) => `Sharing ${title} with ${name} · View only`,
            ownerControlling: ({title, name}) => `${name} can control ${title}`,
            ownerControlRequest: ({name, code}) => `${name} requests control. Compare code ${code} with them on the call. Compare all 10 characters.`,
            reviewControl: () => "Review control request",
            macControlDisclosure: () => "While control is on, the viewer can click and type in this window. Copy and paste are allowed, including anything on your Mac clipboard. Remote clicks move your pointer. On a single full-screen display, Stop overlaps a corner.",
            decline: () => "Decline",
            stopSharing: () => "Stop sharing",
            viewerOffer: ({name, title}) => `${name} is sharing ${title} (view only)`,
            viewerTitle: ({name, title}) => `${name} · ${title}`,
            viewSharedWindow: () => "View shared window",
            modeViewOnly: () => "View only",
            modeControlling: () => "Controlling",
            requestControl: () => "Request control",
            connectionCode: ({code}) => "Compare code " + code + " on both devices. Compare all 10 characters.",
            waitingApproval: ({code}) => `Waiting for control approval · Code ${code} — compare all 10 characters`,
            viewOnlyDeclined: ({reason}) => reason ? `View only · ${reason}` : "View only · control declined.",
            controlHintTouchRight: () => "You have control. Tap to click, double-tap, hold to right-click, two fingers to scroll, pinch to zoom.",
            controlHintTouchBasic: () => "You have control. Tap to click, double-tap, two fingers to scroll, pinch to zoom.",
            controlHintDesktop: () => "You have control. Click or type in the shared window.",
            viewOnlyHintTouch: () => "View only · Pinch to zoom. Request control to interact.",
            viewOnlyHintDesktop: () => "View only · Request control to interact.",
            expand: () => "Full screen",
            minimize: () => "Call view",
            drag: () => "Drag",
            resetZoom: ({z}) => `${z}× · Reset`,
            closeWindow: () => "Close shared window",
            closeShort: () => "Close",
            typePlaceholder: () => "Type or dictate text…",
            send: () => "Send",
            remoteKeys: () => "Remote keys",
            keyReturn: () => "Return",
            keyBackspace: () => "Backspace",
            keyTab: () => "Tab",
            keyEscape: () => "Escape",
            keyLeft: () => "Left arrow",
            keyUp: () => "Up arrow",
            keyDown: () => "Down arrow",
            keyRight: () => "Right arrow",
            keyCmd: () => "Command",
            keyOpt: () => "Option",
            keyCtrl: () => "Control",
            keyShift: () => "Shift",
            waitingVideo: () => "Waiting for video…",
            pausedShort: () => "Paused",
            stale: ({s}) => `Stale · ${s} s`,
            live: () => "Live",
            msUnit: () => "ms",
            fpsUnit: () => "fps",
            kbUnit: () => "KB",
            imageAlt: ({name}) => `Shared window from ${name}`,
            pausedGeneric: ({name}) => `Control is paused on ${name}.`,
            refusedGeneric: ({name}) => `Input was refused on ${name}.`,
            textUncertain: ({name}) => `No confirmation from ${name}. The last part of your text may already be typed — check the window before sending again.`,
        },
        ru: {
            askBtn: ({name}) => `Попросить ${name} показать окно`,
            inboundAsk: ({name}) => `${name} просит показать окно (только просмотр). Для управления нужно отдельное разрешение.`,
            chooseWindow: () => "Выбрать окно",
            declineRequest: () => "Отклонить запрос",
            shareWith: ({name}) => `Показать окно для ${name}`,
            updateGroupHost: () => "Обновите Longvox на ПК, чтобы поделиться окном с этим участником.",
            updateOtherForControl: () => "Обновите Longvox на другом устройстве, чтобы разрешить управление.",
            waitingToChoose: ({name}) => `Ожидание, пока ${name} выберет окно (только просмотр)…`,
            cancelRequest: () => "Отменить запрос",
            peerUnavailable: ({name}) => `${name} сейчас не может показать окно.`,
            ownerViewing: ({title, name}) => `Показ окна «${title}» для ${name} · Только просмотр`,
            ownerControlling: ({title, name}) => `${name} управляет окном «${title}»`,
            ownerControlRequest: ({name, code}) => `${name} запрашивает управление. Сверьте все 10 символов кода ${code} во время звонка.`,
            reviewControl: () => "Проверить запрос управления",
            macControlDisclosure: () => "Пока управление включено, собеседник может нажимать и печатать в этом окне. Копирование и вставка разрешены, в том числе вставка из буфера обмена Mac. Удалённые клики перемещают указатель. Если экран один и окно развёрнуто на весь экран, кнопка остановки перекрывает угол окна.",
            decline: () => "Отклонить",
            stopSharing: () => "Остановить показ",
            viewerOffer: ({name, title}) => `${name} показывает окно «${title}» (только просмотр)`,
            viewerTitle: ({name, title}) => `${name} · ${title}`,
            viewSharedWindow: () => "Открыть окно",
            modeViewOnly: () => "Только просмотр",
            modeControlling: () => "Управление",
            requestControl: () => "Запросить управление",
            connectionCode: ({code}) => "Сверьте все 10 символов кода " + code + " на обоих устройствах.",
            waitingApproval: ({code}) => `Ожидание разрешения на управление · Код ${code} — сверьте все 10 символов`,
            viewOnlyDeclined: ({reason}) => reason ? `Только просмотр · ${reason}` : "Только просмотр · в управлении отказано.",
            controlHintTouchRight: () => "У вас есть управление. Касание — клик, двойное, удержание — правый клик, 2 пальца — прокрутка, щипок — масштаб.",
            controlHintTouchBasic: () => "У вас есть управление. Касание — клик, двойное касание, 2 пальца — прокрутка, щипок — масштаб.",
            controlHintDesktop: () => "У вас есть управление. Нажимайте и печатайте в общем окне.",
            viewOnlyHintTouch: () => "Только просмотр · Щипок для масштаба. Запросите управление, чтобы нажимать.",
            viewOnlyHintDesktop: () => "Только просмотр · Запросите управление, чтобы взаимодействовать.",
            expand: () => "На весь экран",
            minimize: () => "К звонку",
            drag: () => "Тянуть",
            resetZoom: ({z}) => `${z}× · Сброс`,
            closeWindow: () => "Закрыть окно",
            closeShort: () => "Закрыть",
            typePlaceholder: () => "Текст или диктовка…",
            send: () => "Отправить",
            remoteKeys: () => "Клавиши управления",
            keyReturn: () => "Ввод",
            keyBackspace: () => "Удалить",
            keyTab: () => "Tab",
            keyEscape: () => "Esc",
            keyLeft: () => "Стрелка влево",
            keyUp: () => "Стрелка вверх",
            keyDown: () => "Стрелка вниз",
            keyRight: () => "Стрелка вправо",
            keyCmd: () => "Command",
            keyOpt: () => "Option",
            keyCtrl: () => "Control",
            keyShift: () => "Shift",
            waitingVideo: () => "Ожидание видео…",
            pausedShort: () => "Пауза",
            stale: ({s}) => `Задержка · ${s} с`,
            live: () => "Эфир",
            msUnit: () => "мс",
            fpsUnit: () => "к/с",
            kbUnit: () => "КБ",
            imageAlt: ({name}) => `Общее окно от ${name}`,
            pausedGeneric: ({name}) => `Управление на паузе на ${name}.`,
            refusedGeneric: ({name}) => `Ввод отклонён на ${name}.`,
            textUncertain: ({name}) => `Нет подтверждения от ${name}. Последняя часть текста могла уже напечататься — проверьте окно перед повторной отправкой.`,
        },
    };
    static RU_REASONS = {
        minimized: "Пауза: общее окно свёрнуто или на другом рабочем столе Mac.",
        hidden: "Пауза: приложение скрыто на Mac.",
        unfocused: "Управление на паузе: выведите общее окно на передний план на Mac.",
        locked: "Пауза: экран Mac заблокирован или включена заставка.",
        secure_input: "Ввод в поля паролей и защищённые поля на Mac заблокирован.",
        occluded: "Ввод заблокирован: поверх окна открыто другое окно или диалог.",
        rate_limited: "Ввод отброшен: слишком много событий в секунду.",
        queue_full: "Очередь ввода на компьютере переполнена. Попробуйте ещё раз.",
        local_activity: "Управление приостановлено, пока кто-то работает за этим Mac.",
        stale_frame_seq: "Нажатие пропущено, пока обновлялось изображение. Попробуйте ещё раз.",
        stale_frame_age: "Нажатие пропущено, пока обновлялось изображение. Попробуйте ещё раз.",
        missing_frame_seq: "Нажатие пропущено, пока обновлялось изображение. Попробуйте ещё раз.",
        stale_seq: "Устаревшее событие ввода пропущено.",
        missing_seq: "Событие ввода пропущено.",
        shortcut_quit: "Выход из программы (⌘Q) запрещён во время управления окном.",
        shortcut_lock_screen: "Блокировка экрана (⌃⌘Q) запрещена во время управления окном.",
        shortcut_app_switcher: "Переключение приложений (⌘Tab) запрещено: управление ограничено одним окном.",
        shortcut_window_switcher: "Переключение окон (⌘`) запрещено: управление ограничено одним окном.",
        shortcut_force_quit: "Принудительное завершение (⌥⌘Esc) запрещено во время управления окном.",
        shortcut_spotlight: "Spotlight и системный поиск запрещены во время управления окном.",
        shortcut_screenshot: "Снимки экрана (⌘⇧3/4/5) запрещены во время управления окном.",
        shortcut_mission_control: "Mission Control и переключение столов запрещены: управление ограничено одним окном.",
        shortcut_hide: "Скрытие приложений (⌘H) запрещено: управление ограничено одним окном.",
        shortcut_minimize: "Сворачивание окна (⌘M) запрещено во время управления окном.",
        shortcut_not_allowed: "Эта комбинация клавиш запрещена в режиме управления одним окном.",
        no_accessibility: "Разрешите Longvox в разделе «Универсальный доступ» на Mac и снова запросите управление.",
        no_input_monitoring: "Разрешите Longvox в разделе «Мониторинг ввода» на Mac и снова запросите управление.",
        no_screen_recording: "На Mac отключено разрешение Записи экрана.",
        unavailable: "Управление недоступно на этом компьютере.",
        update_required: "Обновите Longvox на другом устройстве, чтобы разрешить управление.",
        cancelled: "Запрос управления отменён.",
        denied: "В управлении отказано.",
        revoked: "Управление завершено на компьютере.",
        text_uncertain: "Нет подтверждения от компьютера. Последняя часть текста могла уже напечататься — проверьте окно перед повторной отправкой.",
    };
    static EN_REASONS = {
        unavailable: name => `Control is unavailable on ${name}.`,
        update_required: () => "Update Longvox on the other device to allow control.",
        queue_full: name => `Input queue is full on ${name}. Try again.`,
        local_activity: name => `Control paused while someone is using ${name}.`,
        no_accessibility: name => `Control is unavailable on ${name} (Accessibility off).`,
        no_screen_recording: name => `Sharing is unavailable on ${name} (Screen Recording off).`,
        cancelled: () => "Control request was cancelled.",
        denied: () => "control declined.",
        revoked: name => `Control ended on ${name}.`,
        text_uncertain: name => `No confirmation from ${name}. The last part of your text may already be typed — check the window before sending again.`,
    };
    static reasonMessage(lang, code, fallback, name = "Mac") {
        const macCopy = CallWindowShare.displayMessage(fallback);
        if (macCopy !== fallback) return macCopy;
        if (lang === "ru" && typeof code === "string" && Object.hasOwn(CallWindowShare.RU_REASONS, code)) {
            return CallWindowShare.RU_REASONS[code];
        }
        if (fallback) return fallback;
        if (lang === "en" && typeof code === "string" && Object.hasOwn(CallWindowShare.EN_REASONS, code)) {
            return CallWindowShare.EN_REASONS[code](name);
        }
        return lang === "ru" ? `Ввод отклонён на ${name}.` : `Input was refused on ${name}.`;
    }
    static displayMessage(text) {
        const messages = globalThis.longvoxMacWindowText;
        return messages && Object.hasOwn(messages, text) ? messages[text] : text;
    }
    lang() {
        return CallWindowShare.resolveLang(this.langOverride);
    }
    t(key, vars = {}) {
        const table = CallWindowShare.STRINGS[this.lang()] || CallWindowShare.STRINGS.en;
        const fn = table[key] || CallWindowShare.STRINGS.en[key];
        return fn ? fn(vars) : "";
    }
    setExpanded(on) {
        this.expanded = Boolean(on);
        this.box.classList.toggle("sw-expanded", this.expanded);
        document.body?.classList.toggle("sw-viewer-expanded", this.expanded);
        this.syncVisualViewport();
        if (this.viewerDom) {
            this.viewerDom.expandBtn.textContent = this.expanded ? this.t("minimize") : this.t("expand");
            this.viewerDom.expandBtn.setAttribute("aria-pressed", String(this.expanded));
            this.clampTransform();
        }
    }
    syncVisualViewport() {
        if (!this.expanded) {
            this.box.style.removeProperty("--sw-vv-height");
            this.box.style.removeProperty("--sw-vv-top");
            return;
        }
        const vv = window.visualViewport;
        const h = vv ? Math.max(160, Math.round(vv.height)) : window.innerHeight;
        const top = vv ? Math.max(0, Math.round(vv.offsetTop)) : 0;
        this.box.style.setProperty("--sw-vv-height", h + "px");
        this.box.style.setProperty("--sw-vv-top", top + "px");
    }
    static formatMetrics({hasFrames, paused, rttMs, fps, bytes, quality, ageMs, lang = "en"}) {
        const table = CallWindowShare.STRINGS[lang] || CallWindowShare.STRINGS.en;
        if (!hasFrames) return {tier: "waiting", text: table.waitingVideo()};
        if (paused) return {tier: "paused", text: table.pausedShort()};
        if (ageMs >= 2500) return {tier: "stale", text: table.stale({s: Math.max(2, Math.round(ageMs / 1000))})};
        let tier = "good";
        if ((rttMs != null && rttMs >= 450) || (quality != null && quality <= 25) || (fps > 0 && fps < 1.5)) {
            tier = "low";
        } else if ((rttMs != null && rttMs >= 200) || (quality != null && quality <= 35)) {
            tier = "fair";
        }
        const parts = [];
        if (rttMs != null) parts.push(`${rttMs} ${table.msUnit()}`);
        if (fps > 0) parts.push(`${fps >= 3 ? Math.round(fps) : fps.toFixed(1)} ${table.fpsUnit()}`);
        if (bytes > 0) parts.push(`${Math.max(1, Math.round(bytes / 1024))} ${table.kbUnit()}`);
        return {tier, text: parts.join(" · ") || table.live()};
    }
    static contentRect(rect, naturalWidth, naturalHeight) {
        if (!rect || !rect.width || !rect.height) return null;
        let left = rect.left, top = rect.top, width = rect.width, height = rect.height;
        if (naturalWidth > 0 && naturalHeight > 0) {
            const elemAspect = width / height;
            const imgAspect = naturalWidth / naturalHeight;
            if (Math.abs(elemAspect - imgAspect) > 0.005) {
                if (imgAspect > elemAspect) {
                    const contentH = width / imgAspect;
                    top += (height - contentH) / 2;
                    height = contentH;
                } else {
                    const contentW = height * imgAspect;
                    left += (width - contentW) / 2;
                    width = contentW;
                }
            }
        }
        return width > 0 && height > 0 ? {left, top, width, height} : null;
    }
    positionPointerMarker() {
        const dom = this.viewerDom;
        const p = this.lastPointer;
        if (!dom?.marker || !p) return;
        let fx = p.x, fy = p.y;
        if (this.image && dom.frame) {
            const frameRect = dom.frame.getBoundingClientRect();
            const content = CallWindowShare.contentRect(
                this.image.getBoundingClientRect(),
                this.image.naturalWidth,
                this.image.naturalHeight
            );
            if (frameRect.width > 0 && frameRect.height > 0 && content) {
                fx = (content.left - frameRect.left + p.x * content.width) / frameRect.width;
                fy = (content.top - frameRect.top + p.y * content.height) / frameRect.height;
            }
        }
        dom.marker.style.left = (fx * 100).toFixed(2) + "%";
        dom.marker.style.top = (fy * 100).toFixed(2) + "%";
    }
    showPointerMarker(kind, x, y) {
        this.lastPointer = {kind, x, y, at: Date.now()};
        const marker = this.viewerDom?.marker;
        if (!marker) return;
        this.positionPointerMarker();
        marker.dataset.kind = kind;
        marker.dataset.x = x.toFixed(4);
        marker.dataset.y = y.toFixed(4);
        marker.hidden = false;
        marker.classList.remove("sw-marker-pulse");
        void marker.offsetWidth;
        marker.classList.add("sw-marker-pulse");
    }
    updateMetricsBadge() {
        const badge = this.viewerDom?.metrics;
        if (!badge) return;
        const now = Date.now();
        while (this.frameTimes.length > 0 && now - this.frameTimes[0] > 3000) this.frameTimes.shift();
        let fps = 0;
        if (this.frameTimes.length >= 2) {
            const spanS = Math.max(0.2, (this.frameTimes[this.frameTimes.length - 1] - this.frameTimes[0]) / 1000);
            fps = (this.frameTimes.length - 1) / spanS;
        }
        const ageMs = this.lastFrameAt ? Math.max(0, now - this.lastFrameAt) : 0;
        const info = CallWindowShare.formatMetrics({
            hasFrames: this.lastFrameAt > 0,
            paused: this.windowState === "paused",
            rttMs: this.lastRttMs,
            fps,
            bytes: this.lastFrameBytes,
            quality: this.lastFrameQuality,
            ageMs,
            lang: this.lang(),
        });
        badge.dataset.tier = info.tier;
        badge.textContent = info.text;
    }
    startMetricsTimer() {
        if (this.metricsTimer) return;
        this.metricsTimer = setInterval(() => {
            if (this.role === "viewer" && this.viewing) this.updateMetricsBadge();
        }, 1000);
    }
    static chunkText(text, maxUnits = 120, maxControlKeys = 16) {
        if (typeof text !== "string" || !text.length) return [];
        const clean = text.replace(/\r\n?/g, "\n");
        const chunks = [];
        let current = "";
        let controlKeys = 0;
        for (const cp of Array.from(clean)) {
            const isControlKey = cp === "\n" || cp === "\t";
            if (current.length > 0 && (
                current.length + cp.length > maxUnits ||
                (isControlKey && controlKeys >= maxControlKeys)
            )) {
                chunks.push(current);
                current = "";
                controlKeys = 0;
            }
            current += cp;
            if (isControlKey) controlKeys++;
        }
        if (current.length > 0) chunks.push(current);
        return chunks;
    }
    showDropAlert(reason, message) {
        clearTimeout(this.dropTimer);
        this.dropReason = reason || "refused";
        this.dropMessage = CallWindowShare.reasonMessage(this.lang(), this.dropReason, message, this.name);
        const duration = this.dropReason === "text_uncertain" ? 8000 : 4500;
        this.dropTimer = setTimeout(() => {
            this.dropReason = "";
            this.dropMessage = "";
            this.dropTimer = null;
            this.render();
        }, duration);
        this.render();
    }
    clearStickyMods() {
        if (this.stickyMods.size) {
            this.stickyMods.clear();
            this.syncModifierButtons();
        }
    }
    consumeStickyMods() {
        const mods = [...this.stickyMods];
        if (mods.length) {
            this.stickyMods.clear();
            this.syncModifierButtons();
        }
        return mods;
    }
    syncModifierButtons() {
        const dom = this.viewerDom;
        if (!dom?.modButtons) return;
        for (const [mod, btn] of Object.entries(dom.modButtons)) {
            const on = this.stickyMods.has(mod);
            btn.setAttribute("aria-pressed", String(on));
            btn.classList.toggle("sw-active", on);
        }
    }
    sendKeyAction(key) {
        if (!this.control || this.textSend) return false;
        const mods = this.peerCaps.has("keyMods") ? this.consumeStickyMods() : [];
        if (mods.length) return this.sendInput({kind: "key", key, mods});
        return this.sendInput({kind: "key", key});
    }
    dropTypedUnits(chunks, typed) {
        if (!chunks.length || !Number.isInteger(typed) || typed <= 0) return;
        const head = chunks[0];
        if (typed >= head.length) chunks.shift();
        else chunks[0] = head.slice(typed);
    }
    restorePendingText(reason = "", message = "", {typed = undefined, uncertainInFlight = false} = {}) {
        const pending = this.textSend;
        if (!pending) return;
        clearTimeout(pending.timer);
        this.textSend = null;
        const chunks = pending.chunks;
        if (uncertainInFlight) {
            chunks.shift();
        } else if (Number.isInteger(typed) && typed >= 0) {
            this.dropTypedUnits(chunks, typed);
        }
        const remainder = chunks.join("");
        const input = this.viewerDom?.keyboard;
        if (input && remainder) {
            input.value = remainder + input.value;
        }
        if (uncertainInFlight) {
            this.showDropAlert("text_uncertain", this.t("textUncertain", {name: this.name}));
        } else if (reason || message) {
            this.showDropAlert(reason || "refused", message || "");
        }
    }
    pumpTextQueue() {
        const pending = this.textSend;
        if (!pending || pending.inFlightSeq != null) return;
        if (!pending.chunks.length) {
            clearTimeout(pending.timer);
            this.textSend = null;
            return;
        }
        if (!this.control || !this.id || this.windowState === "paused") {
            this.restorePendingText(
                this.windowReason || "paused",
                this.windowMessage || this.t("pausedGeneric", {name: this.name})
            );
            return;
        }
        const chunk = pending.chunks[0];
        if (!this.sendInput({kind: "text", text: chunk})) {
            this.restorePendingText("refused", this.t("refusedGeneric", {name: this.name}));
            return;
        }
        if (this.peerVersion >= 2 && this.peerCaps.has("inputAck")) {
            pending.inFlightSeq = this.inputSeq;
            clearTimeout(pending.timer);
            pending.timer = setTimeout(() => {
                if (this.textSend === pending) {
                    this.restorePendingText("text_uncertain", "", {uncertainInFlight: true});
                }
            }, this.textAckTimeoutMs);
        } else {
            pending.chunks.shift();
            if (pending.chunks.length) {
                pending.timer = setTimeout(() => this.pumpTextQueue(), 50);
            } else {
                this.textSend = null;
            }
        }
    }
    enqueueLegacyKeys(chars) {
        if (!chars.length) return;
        this.legacyKeyQueue.push(...chars);
        const pumpLegacy = () => {
            if (!this.control || !this.id) {
                this.legacyKeyQueue = [];
                clearTimeout(this.legacyKeyTimer);
                this.legacyKeyTimer = null;
                return;
            }
            let sent = 0;
            while (this.legacyKeyQueue.length && sent < 16) {
                const ch = this.legacyKeyQueue.shift();
                if (ch === "\n" || ch === "\r") this.sendInput({kind: "key", key: "Enter"});
                else if (ch === "\t" && this.peerCaps.has("keyMods")) this.sendInput({kind: "key", key: "Tab"});
                else if (ch !== "\t") this.sendInput({kind: "key", key: ch});
                sent++;
            }
            if (this.legacyKeyQueue.length) {
                this.legacyKeyTimer = setTimeout(pumpLegacy, 600);
            } else {
                this.legacyKeyTimer = null;
            }
        };
        if (!this.legacyKeyTimer) pumpLegacy();
    }
    sendText(raw) {
        if (!this.control || typeof raw !== "string" || !raw.length) return false;
        if (this.textSend?.stopOnAck) return false;
        this.clearStickyMods();
        const normalized = raw.replace(/\r\n?/g, "\n").normalize("NFC");
        if (!normalized.length) return false;
        if (this.peerCaps.has("text")) {
            const chunks = CallWindowShare.chunkText(normalized, 120, 16);
            if (!chunks.length) return false;
            if (this.textSend) {
                this.textSend.chunks.push(...chunks);
            } else {
                this.textSend = {chunks, inFlightSeq: null, timer: null, stopOnAck: null};
            }
            this.pumpTextQueue();
            return true;
        }
        this.enqueueLegacyKeys(Array.from(normalized));
        return true;
    }
    sendComposedText() {
        const input = this.viewerDom?.keyboard;
        if (!input || !this.control) return false;
        if (this.windowState === "paused" || this.textSend?.stopOnAck) {
            this.showDropAlert(this.windowReason || "paused", this.windowMessage || this.t("pausedGeneric", {name: this.name}));
            return false;
        }
        const raw = input.value;
        if (!raw.length) return false;
        input.value = "";
        this.composing = false;
        return this.sendText(raw);
    }
    static mapClientPoint(rect, naturalWidth, naturalHeight, clientX, clientY, clamp = false) {
        const content = CallWindowShare.contentRect(rect, naturalWidth, naturalHeight);
        if (!content) return null;
        let x = (clientX - content.left) / content.width;
        let y = (clientY - content.top) / content.height;
        if (clamp) {
            x = Math.min(0.9999, Math.max(0, x));
            y = Math.min(0.9999, Math.max(0, y));
            return {x, y};
        }
        if (x < 0 || x >= 1 || y < 0 || y >= 1) return null;
        return {x, y};
    }
    clientToImage(clientX, clientY, clamp = false) {
        if (!this.image || !this.url) return null;
        return CallWindowShare.mapClientPoint(
            this.image.getBoundingClientRect(),
            this.image.naturalWidth,
            this.image.naturalHeight,
            clientX,
            clientY,
            clamp
        );
    }
    setTransform(zoom, panX, panY) {
        this.zoom = Math.min(4, Math.max(1, Number.isFinite(zoom) ? zoom : 1));
        this.panX = Number.isFinite(panX) ? panX : 0;
        this.panY = Number.isFinite(panY) ? panY : 0;
        this.clampTransform();
    }
    panBy(dx, dy) {
        if (this.zoom <= 1.001) return;
        this.setTransform(this.zoom, this.panX + dx, this.panY + dy);
    }
    clampTransform() {
        const dom = this.viewerDom;
        if (!dom?.viewport || !dom?.stage) return;
        const vw = dom.viewport.clientWidth || 0;
        const vh = dom.viewport.clientHeight || 0;
        if (this.zoom <= 1.001 || vw <= 0 || vh <= 0) {
            this.zoom = 1;
            this.panX = 0;
            this.panY = 0;
        } else {
            const minX = vw * (1 - this.zoom);
            const minY = vh * (1 - this.zoom);
            this.panX = Math.min(0, Math.max(minX, this.panX));
            this.panY = Math.min(0, Math.max(minY, this.panY));
        }
        dom.stage.style.transform = `translate3d(${this.panX.toFixed(2)}px, ${this.panY.toFixed(2)}px, 0) scale(${this.zoom.toFixed(4)})`;
        dom.stage.style.setProperty("--sw-zoom", this.zoom.toFixed(4));
        dom.viewport.dataset.zoom = this.zoom.toFixed(2);
        if (dom.zoomReset) {
            dom.zoomReset.hidden = this.zoom <= 1.02;
            dom.zoomReset.textContent = this.t("resetZoom", {z: this.zoom.toFixed(1)});
        }
        this.positionPointerMarker();
    }
    clearGestureTimers() {
        if (!this.gesture) return;
        clearTimeout(this.gesture.longPressTimer);
        this.gesture.longPressTimer = null;
        if (this.gesture.pendingTap) {
            clearTimeout(this.gesture.pendingTap.timer);
            this.gesture.pendingTap = null;
        }
    }
    attachTouchGestures(viewport) {
        const g = this.gesture = {
            mode: "idle",
            startTime: 0, startX: 0, startY: 0, lastX: 0, lastY: 0,
            longPressTimer: null,
            pendingTap: null,
            dragMoveLastAt: 0,
            twoStartDist: 0, twoStartMidX: 0, twoStartMidY: 0,
            twoStartZoom: 1, twoStartPanX: 0, twoStartPanY: 0,
            twoPrevMidX: 0, twoPrevMidY: 0,
            twoStartP1X: 0, twoStartP1Y: 0, twoStartP2X: 0, twoStartP2Y: 0,
            scrollAccumY: 0, scrollLastAt: 0,
        };
        const cancelPendingTap = () => {
            if (g.pendingTap) { clearTimeout(g.pendingTap.timer); g.pendingTap = null; }
        };
        const finishActiveDrag = () => {
            if (g.mode !== "drag") return;
            const pt = this.clientToImage(g.lastX, g.lastY, true);
            if (pt && this.control) this.sendInput({kind: "dragEnd", x: pt.x, y: pt.y});
            delete viewport.dataset.dragging;
            g.mode = "idle";
        };
        viewport.addEventListener("touchstart", e => {
            if (!e.isTrusted) return;
            e.preventDefault();
            this.lastTouchAt = Date.now();
            const touches = e.touches;
            if (touches.length === 1 && g.mode === "idle") {
                const t = touches[0];
                g.mode = "one";
                g.startTime = Date.now();
                g.startX = g.lastX = t.clientX;
                g.startY = g.lastY = t.clientY;
                clearTimeout(g.longPressTimer);
                g.longPressTimer = setTimeout(() => {
                    g.longPressTimer = null;
                    if (g.mode !== "one") return;
                    cancelPendingTap();
                    g.mode = "longpress";
                    if (!this.control || !this.peerCaps.has("rightClick")) return;
                    const pt = this.clientToImage(g.startX, g.startY);
                    if (!pt) return;
                    this.sendInput({kind: "rightClick", x: pt.x, y: pt.y});
                }, 500);
            } else if (touches.length >= 2) {
                clearTimeout(g.longPressTimer);
                g.longPressTimer = null;
                cancelPendingTap();
                if (g.mode === "drag") finishActiveDrag();
                const p1 = touches[0], p2 = touches[1];
                g.mode = "two-pending";
                g.twoStartDist = Math.hypot(p2.clientX - p1.clientX, p2.clientY - p1.clientY);
                g.twoStartMidX = g.twoPrevMidX = (p1.clientX + p2.clientX) / 2;
                g.twoStartMidY = g.twoPrevMidY = (p1.clientY + p2.clientY) / 2;
                g.twoStartP1X = p1.clientX; g.twoStartP1Y = p1.clientY;
                g.twoStartP2X = p2.clientX; g.twoStartP2Y = p2.clientY;
                g.twoStartZoom = this.zoom;
                g.twoStartPanX = this.panX;
                g.twoStartPanY = this.panY;
                g.scrollAccumY = 0;
            }
        }, {passive: false});
        viewport.addEventListener("touchmove", e => {
            if (!e.isTrusted) return;
            e.preventDefault();
            this.lastTouchAt = Date.now();
            const touches = e.touches;
            if (touches.length === 1) {
                const t = touches[0];
                if (g.mode === "one") {
                    const dist = Math.hypot(t.clientX - g.startX, t.clientY - g.startY);
                    if (dist >= 10) {
                        clearTimeout(g.longPressTimer);
                        g.longPressTimer = null;
                        cancelPendingTap();
                        const heldMs = Date.now() - g.startTime;
                        const deliberate = this.control && this.peerCaps.has("drag") && (this.dragMode || heldMs >= 160);
                        if (deliberate) {
                            const startPt = this.clientToImage(g.startX, g.startY);
                            if (startPt) {
                                g.mode = "drag";
                                viewport.dataset.dragging = "true";
                                this.sendInput({kind: "dragStart", x: startPt.x, y: startPt.y});
                                const curPt = this.clientToImage(t.clientX, t.clientY, true);
                                if (curPt) {
                                    this.sendInput({kind: "dragMove", x: curPt.x, y: curPt.y});
                                    g.dragMoveLastAt = Date.now();
                                }
                                g.lastX = t.clientX; g.lastY = t.clientY;
                                return;
                            }
                        }
                        g.mode = "pan";
                        if (this.zoom > 1.001) this.panBy(t.clientX - g.lastX, t.clientY - g.lastY);
                    }
                    g.lastX = t.clientX; g.lastY = t.clientY;
                } else if (g.mode === "pan") {
                    if (this.zoom > 1.001) this.panBy(t.clientX - g.lastX, t.clientY - g.lastY);
                    g.lastX = t.clientX; g.lastY = t.clientY;
                } else if (g.mode === "drag") {
                    g.lastX = t.clientX; g.lastY = t.clientY;
                    const now = Date.now();
                    if (now - g.dragMoveLastAt >= 45 && this.control) {
                        const pt = this.clientToImage(t.clientX, t.clientY, true);
                        if (pt) {
                            this.sendInput({kind: "dragMove", x: pt.x, y: pt.y});
                            g.dragMoveLastAt = now;
                        }
                    }
                }
            } else if (touches.length >= 2) {
                const p1 = touches[0], p2 = touches[1];
                const d = Math.hypot(p2.clientX - p1.clientX, p2.clientY - p1.clientY);
                const midX = (p1.clientX + p2.clientX) / 2;
                const midY = (p1.clientY + p2.clientY) / 2;
                if (g.mode === "two-pending") {
                    const distDelta = Math.abs(d - g.twoStartDist);
                    const scaleChange = g.twoStartDist > 16 ? Math.abs(d / g.twoStartDist - 1) : 0;
                    const midMove = Math.hypot(midX - g.twoStartMidX, midY - g.twoStartMidY);
                    const v1x = p1.clientX - g.twoStartP1X, v1y = p1.clientY - g.twoStartP1Y;
                    const v2x = p2.clientX - g.twoStartP2X, v2y = p2.clientY - g.twoStartP2Y;
                    const sameDir = (v1x * v2x + v1y * v2y) > 0;
                    if (distDelta >= 18 || scaleChange >= 0.14) {
                        g.mode = "pinch";
                    } else if (midMove >= 12 && sameDir) {
                        g.mode = this.control ? "scroll" : (this.zoom > 1.001 ? "pinch" : "two-pending");
                    }
                }
                if (g.mode === "pinch") {
                    const factor = g.twoStartDist > 10 ? (d / g.twoStartDist) : 1;
                    const nextZoom = Math.min(4, Math.max(1, g.twoStartZoom * factor));
                    const vpRect = viewport.getBoundingClientRect();
                    const anchorX = (g.twoStartMidX - vpRect.left - g.twoStartPanX) / g.twoStartZoom;
                    const anchorY = (g.twoStartMidY - vpRect.top - g.twoStartPanY) / g.twoStartZoom;
                    this.setTransform(
                        nextZoom,
                        (midX - vpRect.left) - anchorX * nextZoom,
                        (midY - vpRect.top) - anchorY * nextZoom
                    );
                } else if (g.mode === "scroll") {
                    // Natural scroll direction: moving two fingers up scrolls content down (+1).
                    g.scrollAccumY += (g.twoPrevMidY - midY);
                    const step = 28;
                    const now = Date.now();
                    if (Math.abs(g.scrollAccumY) >= step && now - g.scrollLastAt >= 65) {
                        const delta = g.scrollAccumY > 0 ? 1 : -1;
                        g.scrollAccumY -= delta * step;
                        g.scrollAccumY = Math.max(-step * 2, Math.min(step * 2, g.scrollAccumY));
                        const pt = this.clientToImage(midX, midY, true);
                        if (pt && this.control) {
                            this.sendInput({kind: "scroll", x: pt.x, y: pt.y, delta});
                            g.scrollLastAt = now;
                        }
                    }
                }
                g.twoPrevMidX = midX; g.twoPrevMidY = midY;
            }
        }, {passive: false});
        const onTouchEnd = e => {
            if (!e.isTrusted) return;
            this.lastTouchAt = Date.now();
            clearTimeout(g.longPressTimer);
            g.longPressTimer = null;
            if (g.mode === "drag") {
                if (e.touches.length === 0) finishActiveDrag();
                return;
            }
            if (g.mode === "one" && e.touches.length === 0 && e.type === "touchend" && (Date.now() - g.startTime) < 480) {
                const pt = this.clientToImage(g.startX, g.startY);
                if (pt && this.control) {
                    const now = Date.now();
                    if (g.pendingTap && now - g.pendingTap.at <= 280 &&
                        Math.hypot(g.startX - g.pendingTap.clientX, g.startY - g.pendingTap.clientY) <= 32) {
                        clearTimeout(g.pendingTap.timer);
                        g.pendingTap = null;
                        this.sendInput({kind: "double", x: pt.x, y: pt.y});
                    } else {
                        if (g.pendingTap) {
                            clearTimeout(g.pendingTap.timer);
                            const prev = g.pendingTap;
                            g.pendingTap = null;
                            if (this.control) this.sendInput({kind: "click", x: prev.x, y: prev.y});
                        }
                        const tap = {
                            x: pt.x, y: pt.y, clientX: g.startX, clientY: g.startY, at: now,
                            timer: setTimeout(() => {
                                if (g.pendingTap === tap) g.pendingTap = null;
                                if (this.control) this.sendInput({kind: "click", x: tap.x, y: tap.y});
                            }, 260),
                        };
                        g.pendingTap = tap;
                    }
                }
                g.mode = "idle";
                return;
            }
            if (g.mode === "pinch" && e.touches.length < 2) {
                if (this.zoom <= 1.03) this.setTransform(1, 0, 0);
            }
            if (e.touches.length === 0) {
                g.mode = "idle";
            } else if (e.touches.length === 1) {
                // Keep remaining finger in pan mode so releasing two fingers slightly apart never triggers a click.
                g.mode = "pan";
                g.lastX = e.touches[0].clientX;
                g.lastY = e.touches[0].clientY;
            }
        };
        viewport.addEventListener("touchend", onTouchEnd, {passive: false});
        viewport.addEventListener("touchcancel", onTouchEnd, {passive: false});
    }
    makeImage() {
        const image = document.createElement("img");
        image.alt = "Shared window from " + this.name;
        image.className = "shared-window-image"; image.tabIndex = 0; image.draggable = false;
        const pointer = (event, kind) => {
            if (!event.isTrusted || !this.control || !this.url) return;
            if (Date.now() - this.lastTouchAt < 700) return;
            const pt = this.clientToImage(event.clientX, event.clientY);
            if (!pt) return;
            event.preventDefault(); image.focus({preventScroll:true});
            const delta = kind === "scroll" ? Math.sign(event.deltaY || 0) : 0;
            if (kind === "scroll" && !delta) return;
            if (kind === "click" && event.detail === 1) {
                clearTimeout(this.desktopClickTimer);
                this.desktopClickPoint = pt;
                this.desktopClickTimer = setTimeout(() => {
                    this.desktopClickTimer = null;
                    this.desktopClickPoint = null;
                    this.sendInput({kind, x:pt.x, y:pt.y});
                }, 500);
                return;
            }
            this.sendInput({kind, x: pt.x, y: pt.y, delta});
        };
        image.onclick = e => {
            if (!e.isTrusted) return;
            if (e.detail === 2 && this.desktopClickTimer != null) {
                clearTimeout(this.desktopClickTimer);
                this.desktopClickTimer = null;
                const first = this.desktopClickPoint;
                this.desktopClickPoint = null;
                // W6b owners with rightClick build both click pairs. The legacy Windows
                // backend turns "double" into WM_LBUTTONDBLCLK and one button-up.
                if (!this.peerCaps.has("rightClick")) this.sendInput({kind:"click", x:first.x, y:first.y});
                pointer(e, "double");
            } else {
                pointer(e, "click");
            }
        };
        image.oncontextmenu = e => {
            if (!this.peerCaps.has("rightClick")) return;
            pointer(e, "rightClick");
        };
        image.onwheel = e => pointer(e, "scroll");
        image.onkeydown = e => {
            if (!e.isTrusted || !this.control || e.isComposing) return;
            const mods = [];
            if (e.metaKey) mods.push("cmd");
            if (e.altKey) mods.push("opt");
            if (e.ctrlKey) mods.push("ctrl");
            if (e.shiftKey) mods.push("shift");
            const special = ["Backspace","Enter","ArrowLeft","ArrowRight","ArrowUp","ArrowDown"];
            const extSpecial = ["Tab","Escape","Delete","Home","End","PageUp","PageDown"];
            if (mods.length) {
                if (!this.peerCaps.has("keyMods")) return;
                if (["Meta","Alt","Control","Shift"].includes(e.key)) return;
                if (Array.from(e.key).length === 1 || special.includes(e.key) || extSpecial.includes(e.key)) {
                    e.preventDefault();
                    this.sendInput({kind: "key", key: e.key, mods});
                }
                return;
            }
            if (Array.from(e.key).length === 1 || special.includes(e.key) ||
                (this.peerCaps.has("keyMods") && extSpecial.includes(e.key))) {
                e.preventDefault();
                this.sendKeyAction(e.key);
            }
        };
        return image;
    }
    ensureViewerDom() {
        if (this.viewerDom) return this.viewerDom;
        const root = document.createElement("div");
        root.className = "sw-viewer";
        const topRow = document.createElement("div");
        topRow.className = "sw-top-row";
        const modeBadge = document.createElement("span");
        modeBadge.className = "sw-mode-badge";
        modeBadge.dataset.mode = "view";
        const heading = document.createElement("p");
        heading.className = "sw-heading";
        const metrics = document.createElement("span");
        metrics.className = "sw-metrics";
        metrics.dataset.tier = "waiting";
        const topActions = document.createElement("div");
        topActions.className = "sw-top-actions";
        const expandBtn = document.createElement("button");
        expandBtn.type = "button";
        expandBtn.className = "sw-mini-btn";
        expandBtn.setAttribute("aria-pressed", "false");
        expandBtn.onclick = e => {
            if (!e.isTrusted) return;
            this.setExpanded(!this.expanded);
        };
        const closeBtn = document.createElement("button");
        closeBtn.type = "button";
        closeBtn.className = "sw-mini-btn sw-close-btn";
        closeBtn.onclick = e => {
            if (!e.isTrusted) return;
            this.reset(true);
        };
        topActions.append(expandBtn, closeBtn);
        topRow.append(modeBadge, heading, metrics, topActions);

        const pauseBanner = document.createElement("p");
        pauseBanner.className = "sw-pause-banner";
        pauseBanner.setAttribute("role", "status");
        pauseBanner.hidden = true;
        const dropBanner = document.createElement("p");
        dropBanner.className = "sw-drop-banner";
        dropBanner.setAttribute("role", "alert");
        dropBanner.hidden = true;
        const viewport = document.createElement("div");
        viewport.className = "sw-viewport";
        const stage = document.createElement("div");
        stage.className = "sw-stage";
        const frame = document.createElement("div");
        frame.className = "sw-frame";
        const marker = document.createElement("span");
        marker.className = "sw-marker";
        marker.setAttribute("aria-hidden", "true");
        marker.hidden = true;
        frame.append(marker);
        stage.append(frame);
        viewport.append(stage);

        const controlsDock = document.createElement("div");
        controlsDock.className = "sw-controls-dock";
        const toolbar = document.createElement("div");
        toolbar.className = "sw-toolbar";
        const dragBtn = document.createElement("button");
        dragBtn.type = "button";
        dragBtn.className = "sw-tool-btn";
        dragBtn.setAttribute("aria-pressed", "false");
        dragBtn.onclick = e => {
            if (!e.isTrusted) return;
            this.dragMode = !this.dragMode;
            dragBtn.setAttribute("aria-pressed", String(this.dragMode));
            dragBtn.classList.toggle("sw-active", this.dragMode);
        };
        const zoomReset = document.createElement("button");
        zoomReset.type = "button";
        zoomReset.className = "sw-tool-btn";
        zoomReset.hidden = true;
        zoomReset.onclick = e => {
            if (!e.isTrusted) return;
            this.setTransform(1, 0, 0);
        };
        const requestBtn = document.createElement("button");
        requestBtn.type = "button";
        requestBtn.className = "sw-primary-btn";
        requestBtn.onclick = e => {
            if (!e.isTrusted || this.viewOnly || !this.sas2Bound) return;
            this.requested = true;
            this.send({op: "request", id: this.id});
            this.render();
        };
        toolbar.append(requestBtn, dragBtn, zoomReset);
        const statusLine = document.createElement("p");
        statusLine.className = "sw-status-line";

        // Key bar: basic keys always when controlling; Tab, Esc and sticky modifiers when owner supports keyMods.
        const typingDeck = document.createElement("div");
        typingDeck.className = "sw-typing-deck";
        const keybar = document.createElement("div");
        keybar.className = "sw-keybar";
        keybar.setAttribute("role", "toolbar");
        const keybarButtons = [];
        const modButtons = {};
        const makeKeyBtn = (label, labelKey, action, requiresKeyMods = false) => {
            const btn = document.createElement("button");
            btn.type = "button";
            btn.className = "sw-key-btn";
            btn.textContent = label;
            btn.dataset.labelKey = labelKey;
            btn.dataset.requiresKeyMods = requiresKeyMods ? "true" : "false";
            btn.addEventListener("mousedown", e => e.preventDefault());
            btn.onclick = e => {
                if (!e.isTrusted || !this.control) return;
                action(btn);
            };
            keybar.append(btn);
            keybarButtons.push(btn);
            return btn;
        };
        makeKeyBtn("↵", "keyReturn", () => this.sendKeyAction("Enter"));
        makeKeyBtn("⌫", "keyBackspace", () => this.sendKeyAction("Backspace"));
        makeKeyBtn("Tab", "keyTab", () => this.sendKeyAction("Tab"), true);
        makeKeyBtn("Esc", "keyEscape", () => this.sendKeyAction("Escape"), true);
        makeKeyBtn("←", "keyLeft", () => this.sendKeyAction("ArrowLeft"));
        makeKeyBtn("↑", "keyUp", () => this.sendKeyAction("ArrowUp"));
        makeKeyBtn("↓", "keyDown", () => this.sendKeyAction("ArrowDown"));
        makeKeyBtn("→", "keyRight", () => this.sendKeyAction("ArrowRight"));
        for (const [mod, symbol, labelKey] of [
            ["cmd", "⌘", "keyCmd"],
            ["opt", "⌥", "keyOpt"],
            ["ctrl", "⌃", "keyCtrl"],
            ["shift", "⇧", "keyShift"],
        ]) {
            const btn = makeKeyBtn(symbol, labelKey, () => {
                if (this.stickyMods.has(mod)) this.stickyMods.delete(mod);
                else this.stickyMods.add(mod);
                this.syncModifierButtons();
            }, true);
            btn.setAttribute("aria-pressed", "false");
            btn.dataset.mod = mod;
            modButtons[mod] = btn;
        }

        const inputRow = document.createElement("div");
        inputRow.className = "sw-input-row";
        const keyboard = document.createElement("textarea");
        keyboard.rows = 1;
        keyboard.style.resize = "none";
        keyboard.className = "sw-keyboard-input";
        keyboard.autocomplete = "off";
        keyboard.setAttribute("enterkeyhint", "send");
        keyboard.addEventListener("compositionstart", () => { this.composing = true; });
        keyboard.addEventListener("compositionend", () => { this.composing = false; });
        keyboard.addEventListener("beforeinput", e => {
            if (!e.isTrusted || !this.control || this.composing) return;
            if (e.inputType === "deleteContentBackward" && keyboard.value === "") {
                this.lastEmptyBackspaceAt = Date.now();
                this.sendKeyAction("Backspace");
            }
        });
        keyboard.addEventListener("input", e => {
            if (!e.isTrusted || !this.control || this.composing || e.isComposing) return;
            if (this.stickyMods.size > 0 && this.peerCaps.has("keyMods")) {
                const chars = Array.from(keyboard.value);
                if (chars.length === 1) {
                    keyboard.value = "";
                    this.sendKeyAction(chars[0]);
                }
            }
        });
        keyboard.addEventListener("keydown", e => {
            if (!e.isTrusted || !this.control) return;
            if (e.isComposing || this.composing) return;
            if (e.key === "Enter") {
                e.preventDefault();
                if (keyboard.value.length > 0) this.sendComposedText();
                else this.sendKeyAction("Enter");
                return;
            }
            if (e.key === "Backspace" && keyboard.value === "") {
                e.preventDefault();
                if (Date.now() - this.lastEmptyBackspaceAt > 50) {
                    this.lastEmptyBackspaceAt = Date.now();
                    this.sendKeyAction("Backspace");
                }
                return;
            }
            const hardwareMods = [];
            if (e.metaKey) hardwareMods.push("cmd");
            if (e.altKey) hardwareMods.push("opt");
            if (e.ctrlKey) hardwareMods.push("ctrl");
            if (e.shiftKey) hardwareMods.push("shift");
            const special = ["ArrowLeft", "ArrowRight", "ArrowUp", "ArrowDown"];
            const extSpecial = ["Tab", "Escape", "Delete"];
            if (hardwareMods.length && this.peerCaps.has("keyMods") && !["Meta","Alt","Control","Shift"].includes(e.key)) {
                if (keyboard.value === "" && (Array.from(e.key).length === 1 || special.includes(e.key) || extSpecial.includes(e.key))) {
                    e.preventDefault();
                    this.sendInput({kind: "key", key: e.key, mods: hardwareMods});
                }
                return;
            }
            if (keyboard.value === "" && (special.includes(e.key) || (this.peerCaps.has("keyMods") && extSpecial.includes(e.key)))) {
                e.preventDefault();
                this.sendKeyAction(e.key);
            }
        });
        const sendBtn = document.createElement("button");
        sendBtn.type = "button";
        sendBtn.className = "sw-send-btn";
        sendBtn.addEventListener("mousedown", e => e.preventDefault());
        sendBtn.onclick = e => {
            if (!e.isTrusted || !this.control) return;
            this.sendComposedText();
        };
        inputRow.append(keyboard, sendBtn);
        typingDeck.append(keybar, inputRow);
        controlsDock.append(toolbar, statusLine, typingDeck);

        root.append(topRow, pauseBanner, dropBanner, viewport, controlsDock);
        this.attachTouchGestures(viewport);
        this.viewerDom = {
            root, topRow, modeBadge, heading, metrics, expandBtn, closeBtn,
            pauseBanner, dropBanner, viewport, stage, frame, marker,
            controlsDock, toolbar, dragBtn, zoomReset, requestBtn, statusLine,
            typingDeck, keybar, keybarButtons, modButtons, inputRow, keyboard, sendBtn,
        };
        return this.viewerDom;
    }
    render() {
        this.box.hidden = this.closed || !this.ready || (!this.canShare && !this.peerCanShare && !this.role && !this.note);
        if (this.box.hidden || this.interrupted() || !this.groupRouteEligible()) {
            this.box.hidden = true;
            this.setExpanded(false);
            this.box.replaceChildren();
            return;
        }
        if (this.role === "viewer" && this.viewing) {
            const dom = this.ensureViewerDom();
            if (!this.image) this.image = this.makeImage();
            this.image.alt = this.t("imageAlt", {name: this.name});
            if (this.image.parentElement !== dom.frame) dom.frame.replaceChildren(this.image, dom.marker);
            if (dom.root.parentElement !== this.box) this.box.replaceChildren(dom.root);
            this.startMetricsTimer();
            this.updateMetricsBadge();
            dom.modeBadge.dataset.mode = this.control ? "control" : "view";
            dom.modeBadge.textContent = this.control ? this.t("modeControlling") : this.t("modeViewOnly");
            dom.heading.textContent = this.t("viewerTitle", {name: this.name, title: this.title});
            dom.expandBtn.textContent = this.expanded ? this.t("minimize") : this.t("expand");
            dom.expandBtn.setAttribute("aria-pressed", String(this.expanded));
            dom.closeBtn.textContent = this.t("closeShort");
            dom.closeBtn.setAttribute("aria-label", this.t("closeWindow"));
            dom.dragBtn.textContent = this.t("drag");
            dom.requestBtn.textContent = this.t("requestControl");
            dom.sendBtn.textContent = this.t("send");
            dom.keyboard.placeholder = this.t("typePlaceholder");
            dom.keyboard.setAttribute("aria-label", dom.keyboard.placeholder);
            dom.keybar.setAttribute("aria-label", this.t("remoteKeys"));
            for (const btn of dom.keybarButtons) {
                btn.setAttribute("aria-label", this.t(btn.dataset.labelKey));
            }
            const paused = this.windowState === "paused" && Boolean(this.windowMessage || this.windowReason);
            dom.pauseBanner.hidden = !paused;
            dom.pauseBanner.textContent = paused
                ? CallWindowShare.reasonMessage(this.lang(), this.windowReason, this.windowMessage, this.name)
                : "";
            const hasDrop = Boolean(this.dropMessage || this.dropReason);
            dom.dropBanner.hidden = !hasDrop;
            dom.dropBanner.textContent = hasDrop
                ? CallWindowShare.reasonMessage(this.lang(), this.dropReason, this.dropMessage, this.name)
                : "";
            const canDrag = this.control && this.peerCaps.has("drag");
            dom.dragBtn.hidden = !canDrag;
            if (!canDrag && this.dragMode) {
                this.dragMode = false;
                dom.dragBtn.setAttribute("aria-pressed", "false");
                dom.dragBtn.classList.remove("sw-active");
            }
            dom.requestBtn.hidden = this.viewOnly || this.control || this.denied || this.requested;
            const toolbarVisible = !dom.requestBtn.hidden || !dom.dragBtn.hidden || !dom.zoomReset.hidden;
            dom.toolbar.hidden = !toolbarVisible;
            const coarse = CallWindowShare.isCoarsePointer();
            if (this.control) {
                dom.statusLine.textContent = coarse
                    ? (this.peerCaps.has("rightClick") ? this.t("controlHintTouchRight") : this.t("controlHintTouchBasic"))
                    : this.t("controlHintDesktop");
            } else if (this.denied) {
                const reason = this.deniedCode === "denied" && !this.deniedDetail
                    ? ""
                    : CallWindowShare.reasonMessage(this.lang(), this.deniedCode || "", this.deniedDetail || this.deniedReason, this.name);
                dom.statusLine.textContent = this.t("viewOnlyDeclined", {reason});
            } else if (this.requested) {
                dom.statusLine.textContent = this.t("waitingApproval", {code: this.code});
            } else if (this.viewOnly && this.viewOnlyReason === "update_required") {
                dom.statusLine.textContent = this.t("updateOtherForControl");
            } else {
                dom.statusLine.textContent = this.groupRoute && this.sas2Bound
                    ? this.t("connectionCode", {code:this.code})
                    : coarse ? this.t("viewOnlyHintTouch") : this.t("viewOnlyHintDesktop");
            }
            dom.statusLine.hidden = !dom.statusLine.textContent;
            dom.typingDeck.hidden = !this.control;
            dom.keybar.hidden = !this.control;
            const hasKeyMods = this.peerCaps.has("keyMods");
            for (const btn of dom.keybarButtons) {
                btn.hidden = btn.dataset.requiresKeyMods === "true" && !hasKeyMods;
            }
            if (!this.control || !hasKeyMods || this.windowState === "paused") {
                this.clearStickyMods();
            }
            dom.inputRow.hidden = !this.control;
            this.syncVisualViewport();
            this.clampTransform();
            return;
        }
        this.setExpanded(false);
        this.box.replaceChildren();
        const label = text => { const p=document.createElement("p"); p.textContent=text; this.box.append(p); };
        if (this.note) label(CallWindowShare.displayMessage(this.note));
        if (!this.role) {
            if (this.inboundAsk) {
                label(this.t("inboundAsk", {name: this.name}));
                this.button(this.t("chooseWindow"), () => this.offer());
                this.button(this.t("declineRequest"), () => { this.inboundAsk=false; this.send({op:"unavailable"}); this.render(); });
            } else if (this.canShare) {
                this.button(this.t("shareWith", {name: this.name}), () => this.offer());
            }
            if (this.asked) {
                label(this.t("waitingToChoose", {name: this.name}));
                this.button(this.t("cancelRequest"), () => { this.asked=false; this.send({op:"cancelAsk"}); this.render(); });
            } else if (this.peerCanShare && !this.inboundAsk) {
                this.button(this.t("askBtn", {name: this.name}), () => {
                    this.asked=true; this.note=""; this.send({op:"ask"}); this.render();
                });
            }
            return;
        }
        if (this.role === "owner") {
            label(this.control
                ? this.t("ownerControlling", {title: this.title, name: this.name})
                : this.t("ownerViewing", {title: this.title, name: this.name}));
            if (this.windowState === "paused" && (this.windowMessage || this.windowReason)) {
                label(CallWindowShare.reasonMessage(this.lang(), this.windowReason, this.windowMessage, this.name));
            }
            if (this.groupRoute && this.sas2Bound) label(this.t("connectionCode", {code:this.code}));
            if (this.requested) {
                label(this.t("ownerControlRequest", {name: this.name, code: this.code}));
                if (this.controlV2) label(this.t("macControlDisclosure"));
                const review = this.button(this.t("reviewControl"), () => this.grant());
                if (this.granting) review.disabled = true;
                this.button(this.t("decline"), () => this.declineControl());
            }
            this.button(this.t("stopSharing"), () => this.reset(true));
        } else {
            label(this.t("viewerOffer", {name: this.name, title: this.title}));
            if (this.groupRoute && this.sas2Bound) label(this.t("connectionCode", {code:this.code}));
            if (this.windowState === "paused" && (this.windowMessage || this.windowReason)) {
                label(CallWindowShare.reasonMessage(this.lang(), this.windowReason, this.windowMessage, this.name));
            }
            this.button(this.t("viewSharedWindow"), () => {
                this.viewing = true;
                this.image = this.makeImage();
                if (window.innerWidth <= 900 || window.innerHeight <= 520) this.expanded = true;
                const view = {op:"view", id:this.id};
                if (this.connectionBinding) view.binding = this.connectionBinding;
                this.send(view);
                this.render();
                if (this.expanded) this.setExpanded(true);
            });
            this.button(this.t("closeWindow"), () => this.reset(true));
        }
    }
    reset(notify) {
        this.generation++;
        this.approvalSeq++;
        this.preparingApproval = null;
        this.confirmingView = null;
        this.requestAfterView = false;
        this.clearGestureTimers();
        clearTimeout(this.desktopClickTimer);
        this.desktopClickTimer = null;
        this.desktopClickPoint = null;
        clearTimeout(this.dropTimer);
        this.dropTimer = null;
        this.dropReason = "";
        this.dropMessage = "";
        clearTimeout(this.legacyKeyTimer);
        this.legacyKeyTimer = null;
        this.legacyKeyQueue = [];
        if (this.textSend) {
            clearTimeout(this.textSend.timer);
            this.textSend = null;
        }
        this.stickyMods.clear();
        this.composing = false;
        this.zoom = 1;
        this.panX = 0;
        this.panY = 0;
        this.dragMode = false;
        this.dragEndBypass = false;
        this.setExpanded(false);
        this.viewerDom = null;
        this.gesture = null;
        this.deniedCode = "";
        this.deniedDetail = "";
        const id = this.id;
        if (this.role === "owner") this.native("window_stop",{id}).catch(() => {});
        clearTimeout(this.timer);
        clearInterval(this.heartbeatTimer);
        this.heartbeatTimer = null;
        this.lastForwardedHeartbeat = -Infinity;
        this.inputSeq = 0;
        this.lastFrameSeq = 0;
        this.pendingFrameSeq = 0;
        this.inFlightFrameSeq = 0;
        this.lastAckedFrameSeq = 0;
        this.lastFrameSentAt = 0;
        this.frameSentTimes = new Map();
        this.lastRttMs = null;
        this.pendingFrameRttMs = null;
        this.pendingFrameQuality = null;
        this.lastFrameAt = 0;
        this.lastFrameBytes = 0;
        this.lastFrameQuality = null;
        this.frameTimes = [];
        clearInterval(this.metricsTimer);
        this.metricsTimer = null;
        this.lastPointer = null;
        this.pumping = false;
        if (this.url) URL.revokeObjectURL(this.url);
        this.id=this.role=this.url=this.image=this.frame=null;
        this.connectionBinding = null;
        this.viewOnly = false;
        this.viewOnlyReason = "";
        this.code = "";
        this.codeBound = false;
        this.sas2Bound = false;
        this.localFingerprint = "";
        this.remoteFingerprint = "";
        this.deniedReason="";
        this.windowState="active";
        this.windowReason="";
        this.windowMessage="";
        this.control=this.viewing=this.requested=this.denied=this.inboundAsk=this.asked=false;
        if (id && notify) this.send({op:"stop",id});
        this.render();
    }
    close() {
        if (this.closed) return;
        this.closed=true; this.reset(false);
        window.removeEventListener("pagehide",this.leaving);
        window.removeEventListener("resize",this.viewportResized);
        window.removeEventListener("orientationchange",this.viewportResized);
        window.visualViewport?.removeEventListener("resize",this.viewportResized);
        window.visualViewport?.removeEventListener("scroll",this.viewportResized);
        for (const link of this.links) {
            link.removeEventListener("connectionstatechange",this.linkChanged);
            link.removeEventListener("iceconnectionstatechange",this.linkChanged);
        }
        window.removeEventListener("longvox-window-stopped", this.nativeStopped);
        window.removeEventListener("longvox-window-control-ended", this.nativeControlEnded);
        this.frames.close();
        this.peer.close(); this.box.remove();
    }
}

// In a Windows-hosted group, the host introduces enrolled devices already in the meeting.
// It routes data-only SDP offers/answers. Window pixels and input use the resulting direct peer connection.
class GroupWindowHub {
    constructor() { this.members = new Map(); }
    attach(pc, member) {
        if (!member || !/^[a-f0-9]{32}$/.test(member.id)) return null;
        const channel = pc.createDataChannel("longvox-window-introductions", {negotiated:true,id:26});
        const token=Array.from(crypto.getRandomValues(new Uint8Array(12)), n=>n.toString(16).padStart(2,"0")).join("");
        const entry = {id:member.id,name:member.name,token,pc,channel,ready:false,sent:new Map()};
        this.members.set(member.id,entry);
        channel.onmessage = ({data}) => {
            if (this.members.get(member.id)!==entry || typeof data!=="string" || new TextEncoder().encode(data).byteLength>32768) return;
            let msg;
            try { msg=JSON.parse(data); } catch { return; }
            if (!msg || typeof msg!=="object") return;
            if (msg.op==="ready" && !entry.ready) {
                entry.windowBinding = msg.windowBinding === true;
                entry.ready=true; this.roster(); return;
            }
            if (!entry.ready || !["offer","answer"].includes(msg.op) || typeof msg.sdp!=="string") return;
            const recipient=this.members.get(msg.to);
            if (!recipient?.ready || recipient===entry || recipient.windowBinding!==entry.windowBinding ||
                recipient.token!==msg.token || recipient.channel.readyState!=="open") return;
            const expected=entry.id<recipient.id ? "offer" : "answer";
            if (msg.op!==expected || entry.sent.has(recipient.token) ||
                (expected==="answer" && !recipient.sent.has(entry.token))) return;
            const sdp=GroupWindowGuest.privateDataSDP(msg.sdp);
            if (!sdp) return;
            const fingerprint = entry.windowBinding ? CallWindowShare.extractFingerprintFromSDP(sdp) : null;
            if (entry.windowBinding && (!/^sha-256 (?:[0-9A-F]{2}:){31}[0-9A-F]{2}$/.test(fingerprint) ||
                fingerprint === recipient.sent.get(entry.token))) return;
            const envelope = CallWindowShare.wireJSON(
                {op:msg.op,from:entry.id,token:entry.token,sdp}, recipient.pc, 32768);
            if (!envelope) return;
            try {
                recipient.channel.send(envelope);
                entry.sent.set(recipient.token, fingerprint);
            } catch { /* The seat may close while an introduction is in flight. */ }
        };
        const close=()=>{
            if (this.members.get(member.id)===entry) {
                this.members.delete(member.id);
                for (const member of this.members.values()) member.sent.delete(entry.token);
                this.roster();
            }
            channel.onclose=null; channel.close();
        };
        channel.onclose=close;
        return {close};
    }
    roster() {
        const entries=[...this.members.values()].filter(m=>m.ready && m.channel.readyState==="open");
        for (const item of entries) {
            const others=entries.filter(m=>m!==item && m.windowBinding===item.windowBinding)
                .map(({id,name,token})=>({id,name,token}));
            const roster = {op:"members",self:item.id,others};
            if (item.windowBinding) roster.windowBinding = true;
            const envelope = CallWindowShare.wireJSON(roster, item.pc, 32768);
            if (envelope) {
                try { item.channel.send(envelope); } catch { /* The seat may have closed. */ }
            }
        }
    }
}

class GroupWindowGuest {
    constructor(pc, parent, native) {
        this.hostConnection=pc; this.parent=parent; this.native=native; this.members=new Map();
        this.channel=pc.createDataChannel("longvox-window-introductions",{negotiated:true,id:26});
        this.channel.onopen=()=>this.channel.send('{"op":"ready","windowBinding":true}');
        this.channel.onclose=()=>this.close();
        this.channel.onmessage=({data})=>{
            if (typeof data!=="string" || new TextEncoder().encode(data).byteLength>32768) return;
            let msg;
            try { msg=JSON.parse(data); } catch { return; }
            this.receive(msg).catch(()=>{});
        };
    }
    async receive(msg) {
        if (!msg || typeof msg!=="object" || this.closed) return;
        if (msg.op==="members") {
            if (msg.windowBinding !== true) {
                this.removeMembers();
                if (!this.updateNotice) {
                    this.updateNotice = document.createElement("p");
                    this.updateNotice.setAttribute("role", "status");
                    this.parent.append(this.updateNotice);
                }
                this.updateNotice.textContent = CallWindowShare.STRINGS[CallWindowShare.resolveLang()].updateGroupHost();
                return;
            }
            if (!Array.isArray(msg.others) || msg.others.length>2 || !/^[a-f0-9]{32}$/.test(msg.self)) return;
            const current=new Map();
            for (const m of msg.others) {
                if (!m || !/^[a-f0-9]{32}$/.test(m.id) || m.id===msg.self || !/^[a-f0-9]{24}$/.test(m.token) ||
                    typeof m.name!=="string" || !m.name || m.name.length>80 || current.has(m.id)) return;
                current.set(m.id,m);
            }
            this.updateNotice?.remove();
            this.updateNotice = null;
            for (const [id,entry] of this.members) {
                if (current.get(id)?.token!==entry.token) { this.members.delete(id); entry.share.close(); entry.pc.close(); }
            }
            for (const [id,member] of current) {
                if (this.members.has(id)) continue;
                const pc=new RTCPeerConnection({iceServers:[]});
                const share=new CallWindowShare(pc,this.parent,member.name,(op,data)=>this.native(op,{...data,member:id}),this.hostConnection);
                const entry={pc,share,token:member.token,initiator:msg.self<id};
                this.members.set(id,entry);
                if (entry.initiator) this.describe(id,entry,"offer").catch(()=>{});
            }
        } else if (msg.op==="offer" || msg.op==="answer") {
            const entry=this.members.get(msg.from);
            if (!entry || entry.token!==msg.token || entry.initiator!==(msg.op==="answer")) return;
            if (entry.pc.signalingState!==(entry.initiator ? "have-local-offer" : "stable") || entry.pc.remoteDescription) return;
            const sdp=GroupWindowGuest.privateDataSDP(msg.sdp);
            if (!sdp) return;
            await entry.pc.setRemoteDescription({type:msg.op,sdp});
            if (msg.op==="offer") await this.describe(msg.from,entry,"answer");
        }
    }
    static privateDataSDP(sdp) {
        if (typeof sdp!=="string" || sdp.length>30000) return null;
        const lines=sdp.split(/\r?\n/);
        const media=lines.filter(l=>l.startsWith("m="));
        if (media.length!==1 || !/^m=application \d+ UDP\/DTLS\/SCTP webrtc-datachannel$/.test(media[0])) return null;
        const eligible=line=>{
            if (!line.startsWith("a=candidate:")) return !line.startsWith("a=remote-candidates:");
            const f=line.split(/\s+/), ip=f[4];
            if (!ip || f[2]?.toLowerCase()!=="udp" || f[6]!=="typ" || f[7]!=="host") return false;
            if (/^[a-z0-9-]+\.local\.?$/i.test(ip)) return true;
            if (/^(?:f[cd][\da-f]{2}|fe[89ab][\da-f]):[\da-f:]+$/i.test(ip)) return true;
            const v=ip.split(".").map(Number);
            return v.length===4 && v.every((n,i)=>Number.isInteger(n)&&n>=0&&n<=255&&String(n)===ip.split(".")[i]) &&
                (v[0]===10 || v[0]===192&&v[1]===168 || v[0]===172&&v[1]>=16&&v[1]<=31 || v[0]===100&&v[1]>=64&&v[1]<=127);
        };
        let candidates = 0;
        return lines.filter(line => {
            if (!eligible(line)) return false;
            if (line.startsWith("a=candidate:")) {
                if (candidates >= 16) return false;
                candidates++;
            }
            return true;
        }).join("\r\n");
    }
    async describe(id,entry,type) {
        const pc=entry.pc;
        await pc.setLocalDescription(type==="offer" ? await pc.createOffer() : await pc.createAnswer());
        if (pc.iceGatheringState!=="complete") await new Promise(resolve=>{
            const finish=()=>{ clearTimeout(timer); pc.removeEventListener("icegatheringstatechange",change); resolve(); };
            const change=()=>{ if (pc.iceGatheringState==="complete") finish(); };
            const timer=setTimeout(finish,4000); pc.addEventListener("icegatheringstatechange",change); change();
        });
        if (this.closed || this.members.get(id)!==entry || this.channel.readyState!=="open") return;
        const sdp=GroupWindowGuest.privateDataSDP(pc.localDescription.sdp);
        if (!sdp) return;
        const envelope = CallWindowShare.wireJSON({op:type,to:id,token:entry.token,sdp}, this.hostConnection, 32768);
        if (envelope) this.channel.send(envelope);
    }
    removeMembers() {
        for (const {pc,share} of this.members.values()) { share.close(); pc.close(); }
        this.members.clear();
    }
    close() {
        if (this.closed) return;
        this.closed=true;
        this.removeMembers();
        this.updateNotice?.remove();
        this.channel.onclose=null; this.channel.close();
    }
}
