"use strict";
function paintContainedVideo(context, video, width, height) {
    const ratio = Math.min(width / video.videoWidth, height / video.videoHeight);
    const w = video.videoWidth * ratio, h = video.videoHeight * ratio;
    context.fillStyle = "#10151b";
    context.fillRect(0, 0, width, height);
    context.drawImage(video, (width - w) / 2, (height - h) / 2, w, h);
}

function paintAgentActivity(context, text) {
    context.save();
    context.font = "650 30px sans-serif";
    context.fillStyle = "#112c35";
    context.fillRect(20, 20, Math.min(1240, context.measureText(text).width + 48), 54);
    context.fillStyle = "#b3fff1";
    context.fillRect(20, 20, 6, 54);
    context.fillText(text, 44, 57, 1192);
    context.restore();
}

class MeetingCapture {
    constructor(context, post, failed) {
        this.context = context;
        this.post = post;
        this.failed = failed;
        this.writes = Promise.resolve();
        this.seq = {pcm: 0, video: 0};
        this.pending = 0;
        this.agentSpeechCount = 0;
    }
    queue(stream, data) {
        const size = data.size ?? data.byteLength;
        if (!size || this.failure) return;
        if (size > 4 * 1024 * 1024 && data instanceof Blob) {
            for (let pos = 0; pos < size; pos += 4 * 1024 * 1024) this.queue(stream, data.slice(pos, pos + 4 * 1024 * 1024));
            return;
        }
        this.pending += size;
        const seq = this.seq[stream]++;
        this.writes = this.writes.then(async () => {
            if (this.failure) return;
            if (this.pending > 32 * 1024 * 1024) throw Error("Storage cannot keep up with this recording.");
            const path = "/block?stream=" + stream + "&seq=" + seq;
            try { await this.post(path, data); }
            catch { await this.post(path, data); }
        }).catch(e => { this.failure = e; this.failed(e); }).finally(() => { this.pending -= size; });
    }
    replaceInput(previous, stream, channel) {
        previous?.disconnect();
        const tracks = stream.getAudioTracks();
        if (!this.mix || this.halted || !tracks.length) return null;
        const source = this.context.createMediaStreamSource(new MediaStream(tracks));
        source.connect(this.inputs[channel]);
        return source;
    }
    setLocal(stream) { this.localSource = this.replaceInput(this.localSource, stream, 0); }
    setRemote(stream) { this.remoteSource = this.replaceInput(this.remoteSource, stream, 1); }
    canMarkAgentSpeech() { return !this.halted && this.startedAt !== undefined; }
    monitorAgentSpeech(gate, speaking) {
        const context = this.context;
        const meter = new AudioWorkletNode(context, "meeting-agent-speech", {
            channelCount:1, channelCountMode:"explicit"
        });
        const spans = [];
        let resolve;
        const rendered = new Promise(done => { resolve = done; });
        let timeout;
        const finish = () => {
            clearTimeout(timeout);
            meter.port.close();
            meter.disconnect();
            resolve(spans);
        };
        meter.port.onmessage = ({data}) => {
            if (data === "audible") speaking(true);
            else if (data === "finished") finish();
            else { spans.push(data); speaking(false); }
        };
        // The meter sees the isolated gated samples and writes silence to its own output.
        gate.connect(meter).connect(context.destination);
        return {finish:() => {
            meter.port.postMessage("finish");
            // A suspended or closing AudioContext may no longer service its worklet.
            timeout = setTimeout(finish, 800);
            return rendered;
        }};
    }
    saveAgentSpeech(name, rendered, interrupted, save) {
        this.writes = this.writes.then(async () => {
            const spans = await rendered;
            for (const [index, [start, end]] of spans.entries()) {
                const start_s = Math.max(0, start - this.startedAt);
                const end_s = end - this.startedAt;
                if (end_s <= start_s) continue;
                const entry = {id:++this.agentSpeechCount, name, start_s, end_s,
                    interrupted:interrupted && index === spans.length - 1};
                try { await save(entry); }
                catch { await save(entry); }
            }
        }).catch(error => { this.failure ||= error; this.failed(error); });
    }
    async start(local, remote, video, begin, groupPicture = null, remoteName = "", presentation = null) {
        const ctx = this.context;
        this.mix = ctx.createDynamicsCompressor();
        this.inputs = [ctx.createGain(), ctx.createGain()];
        for (const input of this.inputs) input.connect(this.mix);
        this.destination = ctx.createMediaStreamDestination();
        this.mix.connect(this.destination);
        this.setLocal(local);
        this.setRemote(remote);
        await ctx.audioWorklet.addModule("pcm.js");
        if (groupPicture) await ctx.audioWorklet.addModule("recording.js");
        if (this.halted) return;
        let type = "";
        if (video) {
            type = ["video/webm;codecs=vp8,opus", "video/mp4", "video/webm"].find(t => MediaRecorder.isTypeSupported(t));
            if (!type) throw Error("This device cannot record video calls.");
            const canvas = document.createElement("canvas");
            canvas.width = 1280; canvas.height = 720;
            const paint = canvas.getContext("2d", {alpha:false});
            function draw(element, x, y, w, h) {
                if (element.dataset.cameraOff === "true" || !element.videoWidth || element.readyState < 2) return;
                if (!element.srcObject?.getVideoTracks().some(track => track.readyState === "live" && track.enabled && !track.muted)) return;
                const ratio = Math.min(w / element.videoWidth, h / element.videoHeight);
                const width = element.videoWidth * ratio, height = element.videoHeight * ratio;
                paint.drawImage(element, x + (w - width)/2, y + (h - height)/2, width, height);
                return true;
            }
            const frame = () => {
                const screen = presentation?.();
                if (screen?.videoWidth && screen.readyState >= 2 &&
                    screen.srcObject?.getVideoTracks().some(track => track.readyState === "live" && !track.muted)) {
                    paintContainedVideo(paint, screen, 1280, 720);
                    return;
                }
                paint.fillStyle = "#15201d"; paint.fillRect(0, 0, 1280, 720);
                const remoteVideo = document.getElementById("remote");
                const drawn = (!remoteName || remoteVideo.dataset.frameReady === "true") && draw(remoteVideo, 0, 0, 1280, 720);
                if (remoteName && !drawn) {
                    paint.fillStyle = "#eef2f5";
                    paint.font = "600 32px sans-serif";
                    paint.textAlign = "center";
                    paint.textBaseline = "middle";
                    paint.fillText(remoteName, 640, 360, 1200);
                }
                draw(document.getElementById("self"), 944, 522, 320, 180);
            };
            if (!groupPicture) frame();
            this.canvasStream = (groupPicture || canvas).captureStream(30);
            const stream = new MediaStream([...this.canvasStream.getVideoTracks(), ...this.destination.stream.getAudioTracks()]);
            this.media = new MediaRecorder(stream, {mimeType:type, videoBitsPerSecond:2500000, audioBitsPerSecond:96000});
            this.media.ondataavailable = e => this.queue("video", e.data);
            this.media.onerror = e => { this.failure = e.error || Error("Video recorder stopped."); this.failed(this.failure); };
            if (!groupPicture) this.frame = setInterval(frame, 1000 / 30);
        }
        const archive = await begin(type.split(";")[0]);
        // Even when already halted, close the archive to release its lock.
        this.begun = true;
        if (this.halted) return;
        const participants = archive.participant_tracks === true;
        this.pcmFrameBytes = participants ? 6 : 2;
        this.pcmFrames = 0;
        this.pcm = new AudioWorkletNode(ctx, "meeting-pcm", {
            numberOfInputs: participants ? 3 : 1, channelCount: 1, channelCountMode: "explicit",
            processorOptions: {participants}
        });
        this.pcm.port.onmessage = e => {
            if (e.data === "flushed") this.flushed?.();
            else {
                const frames = Math.min(e.data.byteLength / this.pcmFrameBytes,
                    (this.pcmLimit ?? Infinity) - this.pcmFrames);
                if (frames > 0) {
                    this.pcmFrames += frames;
                    const bytes = frames * this.pcmFrameBytes;
                    this.queue("pcm", bytes === e.data.byteLength ? e.data : e.data.slice(0, bytes));
                }
            }
        };
        this.mix.connect(this.pcm, 0, 0);
        if (participants) this.inputs.forEach((input, i) => input.connect(this.pcm, 0, i + 1));
        this.pcm.connect(ctx.destination); // Worklet output is silent.
        this.media?.start(1000);
        this.startedAt = ctx.currentTime;
    }
    halt() {
        if (this.halted) return;
        this.halted = true;
        if (this.pcm) this.pcmLimit = Math.round((this.context.currentTime - this.startedAt) * 16000);
        clearInterval(this.frame);
        if (this.media && this.media.state !== "inactive") {
            this.stopped = new Promise(resolve => { this.media.onstop = resolve; });
            this.media.stop();
        }
        this.localSource?.disconnect();
        this.remoteSource?.disconnect();
        this.canvasStream?.getTracks().forEach(t => t.stop());
        this.destination?.stream.getTracks().forEach(t => t.stop());
        this.inputs?.forEach(input => input.disconnect());
        this.mix?.disconnect();
        if (this.pcm) {
            this.drained = new Promise(resolve => { this.flushed = resolve; });
            this.pcm.port.postMessage("flush");
        }
    }
    async stop() {
        this.halt();
        if (this.drained) {
            await Promise.race([this.drained, new Promise(resolve => setTimeout(resolve, 800))]);
            this.pcm.disconnect();
        }
        await this.stopped;
        await this.writes;
    }
}

if (typeof AudioWorkletProcessor !== "undefined") {
    // Report rendered sample offsets on the same clock as the PCM recorder.
    class AgentSpeechMeter extends AudioWorkletProcessor {
        constructor() {
            super();
            this.port.onmessage = () => {
                this.flush();
                this.port.postMessage("finished");
                this.finished = true;
            };
        }
        flush() {
            if (this.start === undefined) return;
            this.port.postMessage([this.start / sampleRate, this.end / sampleRate]);
            this.start = undefined;
        }
        process(inputs) {
            if (this.finished) return false;
            const samples = inputs[0][0];
            for (let i = 0; i < (samples?.length ?? 0); i++) {
                if (Math.abs(samples[i]) < 1 / 32768) continue;
                if (this.start === undefined) {
                    this.start = currentFrame + i;
                    this.port.postMessage("audible");
                }
                this.end = currentFrame + i + 1;
            }
            if (currentFrame - this.end >= sampleRate * .04) this.flush();
            return true;
        }
    }
    registerProcessor("meeting-agent-speech", AgentSpeechMeter);
}
