// Input zero is the playback mix. The other two inputs preserve the two consenting microphones.
class MeetingPCM extends AudioWorkletProcessor {
    constructor(options) {
        super();
        this.channels = options.processorOptions.participants ? 3 : 1;
        this.buffer = new Int16Array(4096 * this.channels);
        this.sums = new Float64Array(this.channels);
        this.length = this.phase = this.count = 0;
        this.stopped = false;
        this.port.onmessage = () => {
            this.stopped = true;
            this.flush();
            this.port.postMessage("flushed");
        };
    }
    flush() {
        if (this.length) {
            const block = this.buffer.slice(0, this.length).buffer;
            this.port.postMessage(block, [block]);
            this.length = 0;
        }
    }
    process(inputs, outputs) {
        if (this.stopped) return false;
        // The node requests mono on each input. A disconnected microphone contributes silence.
        for (let i = 0; i < outputs[0][0].length; i++) {
            for (let ch = 0; ch < this.channels; ch++) {
                this.sums[ch] += inputs[ch][0]?.[i] ?? 0;
            }
            this.count++;
            this.phase += 16000;
            if (this.phase >= sampleRate) {
                for (let ch = 0; ch < this.channels; ch++) {
                    const v = Math.max(-1, Math.min(1, this.sums[ch] / this.count));
                    this.buffer[this.length++] = Math.round(v * (v < 0 ? 32768 : 32767));
                }
                this.phase -= sampleRate;
                this.count = 0;
                this.sums.fill(0);
                if (this.length === this.buffer.length) this.flush();
            }
        }
        return true;
    }
}
registerProcessor("meeting-pcm", MeetingPCM);
