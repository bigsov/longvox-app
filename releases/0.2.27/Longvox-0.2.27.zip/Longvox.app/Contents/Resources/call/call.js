"use strict";
(() => {
    const $ = id => document.getElementById(id);
    const token = location.hash.slice(1);
    const queryLang = new URLSearchParams(location.search).get("lang");
    const apple = window.webkit?.messageHandlers?.longvoxCall;
    const I18N = {
        en: {
            pageTitle:"Longvox Meet",
            recordBadge:"● Recording on host",
            lobbyTitle:"Meet with someone",
            introDesktop:"Start a private call on the same Wi-Fi or private VPN. The host saves the meeting in Longvox.",
            introApple:"Join a Longvox host on the same Wi-Fi or private VPN. The host saves the meeting.",
            yourName:"Your name",
            contacts:"Contacts",
            openContacts:"Open contacts",
            showNearby:"Show this PC nearby",
            nearby:"Nearby",
            inviteByLink:"Invite by link",
            privateContactLink:"Private contact link",
            contactLinkHint:"The link lasts 15 minutes. Compare the number with your guest before you approve.",
            copyLink:"Copy link",
            showQR:"Show QR code",
            revokeLink:"Revoke link",
            contactQRLabel:"Contact link QR code",
            startACall:"Start a call",
            privateNetwork:"Private network",
            audioCall:"Audio call",
            videoCall:"Video call",
            groupVideoCall:"Group video call",
            joinACall:"Join a call",
            invitation:"Invitation",
            reviewInvitation:"Review invitation",
            deviceCheckLegend:"Camera and microphone",
            checkCameraMic:"Check camera and microphone",
            stopDeviceCheck:"Stop check",
            previewShowCamera:"Preview camera",
            privateInvitation:"Private invitation",
            copyInvitation:"Copy invitation",
            cameraOffState:"Camera is off",
            startingCamera:"Starting camera…",
            cameraUnavailableShort:"Camera unavailable",
            cameraDisconnectedShort:"Camera disconnected",
            videoPreview:"Video preview",
            micLevel:"Microphone level",
            micChecking:"Checking…",
            micReady:"Ready",
            micUnavailableShort:"Microphone unavailable",
            micDisconnectedShort:"Microphone disconnected",
            microphone:"Microphone",
            camera:"Camera",
            speakerOutput:"Speaker",
            systemDefault:"System default",
            startWithCamera:"Start with my camera on",
            joinCall:"Join call",
            answerAndJoin:"Answer & join",
            decline:"Decline",
            cancel:"Cancel",
            callDuration:"Call duration",
            connecting:"Connecting…",
            connected:"Connected",
            goodConnection:"Good connection",
            fairConnection:"Fair connection",
            poorConnection:"Poor connection",
            reconnecting:"Reconnecting…",
            msUnit:"ms",
            lossLabel:"loss",
            youMuted:"You are muted",
            muted:"Muted",
            peerMicDisconnectedShort:"{name}’s microphone disconnected",
            peerMicDisconnected:"{name}’s microphone disconnected.",
            peerMicMuted:"{name} muted their microphone.",
            peerCameraOff:"{name}’s camera is off",
            mute:"Mute",
            unmute:"Unmute",
            reconnectMic:"Reconnect microphone",
            cameraOff:"Camera off",
            cameraOn:"Camera on",
            switchCamera:"Switch camera",
            participants:"Participants",
            enableSound:"Enable speaker audio",
            enableAudio:"Enable audio",
            endCall:"End call",
            leave:"Leave",
            endMeeting:"End meeting",
            close:"Close",
            closeParticipants:"Close participants",
            participantsHostNote:"Members announced by the host only. Other participants appear in the host’s video picture.",
            announcedByHost:"Announced by host",
            hostRole:"Host",
            you:"You",
            participant:"Participant",
            participantNum:"Participant {n}",
            otherParticipant:"Other participant",
            micDisconnectedTag:"Mic disconnected",
            groupConsent:"Up to four people can see and hear each other. Windows records the group in Meetings after you admit a guest.",
            startGroupCall:"Start group call",
            groupVideoLabel:"Group video",
            meetingEnded:"Meeting ended",
            finishedText:"Return to Meetings in Longvox. You can close this window.",
            callWindowClosed:"Call window closed",
            reopenFromContacts:"Open Meetings → Contacts in Longvox to continue.",
            requestFailed:"Longvox could not finish the request.",
            speakerSwitchFailed:"Could not use that speaker. Choose System default or another output.",
            yourMicDisconnected:"Your microphone disconnected. You can still hear the call.",
            micUnavailableRetry:"Microphone unavailable. Check the input and permission, then try again.",
            micUnavailableTryAgain:"Microphone unavailable. Try again.",
            yourCameraDisconnected:"Your camera disconnected. Audio continues.",
            otherCameraUnavailable:"The other camera was unavailable. Your previous camera is active.",
            cameraSwitched:"Camera switched.",
            cameraUnavailableAudio:"Camera unavailable. Audio continues. Choose Camera on to retry.",
            cameraUnavailableContinue:"Camera unavailable. You can continue with audio.",
            cameraListFailed:"Could not list cameras.",
            cameraCheckRetry:"Camera unavailable. Check the camera and its permission, then try again.",
            webrtcNeeded:"This device needs a WebRTC-capable system browser or WebView.",
            waitingFor:"Waiting for {name}",
            waitingForAppDesc:"Open Longvox on the other device within one minute to receive this call.",
            callingName:"Calling {name}",
            callingContactDesc:"Waiting for your contact to answer in Longvox.",
            inviteSomeone:"Invite someone",
            inviteDesc:"Share this one-use invitation privately. It expires in ten minutes. You choose whether to answer.",
            pasteInvite:"Paste a Longvox call invitation.",
            unknownCallType:"Unknown call type.",
            unsupportedGroupInvite:"Unsupported group invitation.",
            joinThreeTitle:"Join three-person audio call?",
            joinThreeDesc:"Both other participants will hear you. The host saves all three voices in one recording. Agree to request admission.",
            joinGroupTitle:"Join group video call?",
            joinGroupDesc:"Up to four people can see and hear you. The Windows host records everyone's voices and enabled cameras in Longvox. Agree to request admission.",
            joinAudioTitle:"Join audio call?",
            joinVideoTitle:"Join video call?",
            joinAudioDesc:"The host saves both voices in their Longvox library. Each microphone can be saved separately for transcription. Agree to send a call request.",
            joinVideoDesc:"The host saves both voices and any cameras you turn on in their Longvox library. Each microphone can be saved separately for transcription. Agree to send a call request.",
            callTypeChanged:"The call type changed. Ask for a fresh invitation.",
            waitingHostAnswer:"Waiting for the host to answer.",
            longvoxCall:"Longvox call",
            theParticipant:"the participant",
            callEnded:"Call ended.",
            youLeftMeeting:"You left the meeting.",
            hostEndedMeeting:"The host ended the meeting.",
            hostRemovedYou:"The host removed you from the meeting.",
            hostRecordingFault:"The host could not continue the recording.",
            peerStoppedRecording:"The other device stopped the recording.",
            connectionInterrupted:"Connection interrupted. Reconnecting…",
            connectionLost:"Connection lost. The recorded part was kept.",
            groupConnectionLost:"Connection lost. Ask the host for a new invitation.",
            keepTalkingReconnecting:"You can keep talking. Trying to reconnect…",
            reconnectingErr:"Reconnecting… {msg}",
            recordingStopped:"Recording stopped: {msg}",
            connectingTo:"Connecting to {name}",
            recordedOnWindows:"This call is recorded on Windows.",
            nameIsCalling:"{name} is calling",
            answerAudioDesc:"Answer to record this audio call with their agreement. Each microphone is saved for transcription.",
            answerVideoDesc:"Answer to record this video call with their agreement. Each microphone is saved for transcription.",
            inviteExpired:"Invitation expired. Start a new call to invite someone.",
            noAnswer:"No answer. The invitation has closed.",
            callDeclined:"Call declined.",
            callCancelled:"Call cancelled.",
            peerRecordingFault:"The other device could not continue the recording.",
            lostContact:"Lost contact with the other device.",
            tryingToReach:"Trying to reach the other device…",
            savingRecording:"Saving the recording…",
            recordingInterrupted:"The recording was interrupted. {msg}",
            savedInMeetings:" Saved in Meetings.",
            confirmCode:"Confirm that the other screen shows {code}.",
            visibleNearby:"Visible nearby. Choose this PC on the other device to connect.",
            numbersMatchAllow:"Numbers match · Allow",
            ignore:"Ignore",
            noSavedContacts:"No saved contacts yet.",
            contactCalling:" is calling",
            contactActive:" · Longvox active",
            contactWaiting:" · Waiting for Longvox",
            answerRequest:"Answer {kind} request",
            dismiss:"Dismiss",
            remove:"Remove",
            removeConfirm:"Remove {name} from your call contacts?",
            contactLinkCopied:"Contact link copied.",
            copySelectedContactLink:"Copy the selected contact link.",
            inviteCopied:"Invitation copied.",
            copySelectedInvite:"Copy the selected invitation.",
            connectingShort:"Connecting",
            yourContact:"your contact",
            groupCameraUnavailable:"Camera unavailable. Your audio is still connected.",
            groupCameraAudioOn:"Camera unavailable. Audio stays on.",
            guestNum:"Guest {n}",
            seatCallingSaved:"Calling saved contact",
            seatAwaitingInvite:"Awaiting invitation",
            seatInviteCopied:"Invitation copied for {name}.",
            seatWantsToJoin:"Wants to join",
            seatConnecting:"Connecting",
            seatCouldNotConnect:"Could not connect",
            admit:"Admit",
            seatDeclined:"Declined",
            seatLeft:"Left",
            seatExpired:"Invitation expired",
            seatNoAnswer:"No answer",
            seatDisconnected:"Disconnected",
            seatInMeeting:"In meeting",
            seatReconnecting:"Reconnecting",
            seatConnectionLost:"Connection lost",
            seatMeetingEnded:"Meeting ended",
            groupRecordingInterrupted:"Recording interrupted. {msg}",
            groupSaved:"Group recording saved in Meetings.",
            groupClosed:"Group call closed.",
            rosterSpeaking:"Speaking",
            rosterMicOn:"Microphone on",
            rosterMicMuted:"Muted",
            rosterMicUnknown:"Microphone status unknown",
            rosterCameraOn:"Camera on",
            rosterCameraOff:"Camera off"
        },
        ru: {
            pageTitle:"Longvox Meet",
            recordBadge:"● Запись на хосте",
            lobbyTitle:"Позвонить",
            introDesktop:"Начните приватный звонок в одной сети Wi-Fi или VPN. Хост сохранит встречу в Longvox.",
            introApple:"Подключитесь к хосту Longvox в одной сети Wi-Fi или VPN. Хост сохранит встречу.",
            yourName:"Ваше имя",
            contacts:"Контакты",
            openContacts:"Открыть контакты",
            showNearby:"Показывать этот ПК рядом",
            nearby:"Рядом",
            inviteByLink:"Пригласить по ссылке",
            privateContactLink:"Приватная ссылка контакта",
            contactLinkHint:"Ссылка действует 15 минут. Сверьте код с собеседником перед подтверждением.",
            copyLink:"Копировать ссылку",
            showQR:"Показать QR-код",
            revokeLink:"Отозвать ссылку",
            contactQRLabel:"QR-код ссылки контакта",
            startACall:"Начать звонок",
            privateNetwork:"Приватная сеть",
            audioCall:"Аудиозвонок",
            videoCall:"Видеозвонок",
            groupVideoCall:"Групповой видеозвонок",
            joinACall:"Присоединиться к звонку",
            invitation:"Приглашение",
            reviewInvitation:"Открыть приглашение",
            deviceCheckLegend:"Камера и микрофон",
            checkCameraMic:"Проверить камеру и микрофон",
            stopDeviceCheck:"Остановить проверку",
            previewShowCamera:"Показать камеру",
            privateInvitation:"Приватное приглашение",
            copyInvitation:"Копировать приглашение",
            cameraOffState:"Камера выключена",
            startingCamera:"Включение камеры…",
            cameraUnavailableShort:"Камера недоступна",
            cameraDisconnectedShort:"Камера отключена",
            videoPreview:"Предпросмотр видео",
            micLevel:"Уровень микрофона",
            micChecking:"Проверка…",
            micReady:"Готов",
            micUnavailableShort:"Микрофон недоступен",
            micDisconnectedShort:"Микрофон отключён",
            microphone:"Микрофон",
            camera:"Камера",
            speakerOutput:"Динамик",
            systemDefault:"По умолчанию",
            startWithCamera:"Включить камеру при входе",
            joinCall:"Присоединиться",
            answerAndJoin:"Ответить",
            decline:"Отклонить",
            cancel:"Отмена",
            callDuration:"Длительность звонка",
            connecting:"Подключение…",
            connected:"Подключено",
            goodConnection:"Хорошая связь",
            fairConnection:"Средняя связь",
            poorConnection:"Слабая связь",
            reconnecting:"Переподключение…",
            msUnit:"мс",
            lossLabel:"потерь",
            youMuted:"Микрофон выключен",
            muted:"Без звука",
            peerMicDisconnectedShort:"{name}: микрофон отключён",
            peerMicDisconnected:"У собеседника {name} отключился микрофон.",
            peerMicMuted:"У собеседника {name} выключен микрофон.",
            peerCameraOff:"У собеседника {name} выключена камера",
            mute:"Выкл. звук",
            unmute:"Вкл. звук",
            reconnectMic:"Подключить микрофон",
            cameraOff:"Выкл. камеру",
            cameraOn:"Вкл. камеру",
            switchCamera:"Сменить камеру",
            participants:"Участники",
            enableSound:"Включить звук",
            enableAudio:"Включить звук",
            endCall:"Завершить",
            leave:"Выйти",
            endMeeting:"Завершить встречу",
            close:"Закрыть",
            closeParticipants:"Закрыть список участников",
            participantsHostNote:"Показаны только участники, объявленные хостом. Остальные участники видны на общем видео хоста.",
            announcedByHost:"Объявлен хостом",
            hostRole:"Организатор",
            you:"Вы",
            participant:"Участник",
            participantNum:"Участник {n}",
            otherParticipant:"Собеседник",
            micDisconnectedTag:"Микрофон откл.",
            groupConsent:"До четырёх участников могут видеть и слышать друг друга. Windows записывает встречу в «Встречи» после допуска гостя.",
            startGroupCall:"Начать групповой звонок",
            groupVideoLabel:"Групповое видео",
            meetingEnded:"Встреча завершена",
            finishedText:"Вернитесь в раздел «Встречи» в Longvox. Это окно можно закрыть.",
            callWindowClosed:"Окно звонка закрыто",
            reopenFromContacts:"Откройте «Встречи → Контакты» в Longvox, чтобы продолжить.",
            requestFailed:"Longvox не смог выполнить запрос.",
            speakerSwitchFailed:"Не удалось выбрать этот динамик. Выберите «По умолчанию» или другое устройство.",
            yourMicDisconnected:"Ваш микрофон отключился. Вы по-прежнему слышите собеседника.",
            micUnavailableRetry:"Микрофон недоступен. Проверьте подключение и разрешения, затем повторите попытку.",
            micUnavailableTryAgain:"Микрофон недоступен. Повторите попытку.",
            yourCameraDisconnected:"Ваша камера отключилась. Звук продолжает работать.",
            otherCameraUnavailable:"Другая камера недоступна. Активна предыдущая камера.",
            cameraSwitched:"Камера переключена.",
            cameraUnavailableAudio:"Камера недоступна. Звук работает. Нажмите «Вкл. камеру», чтобы повторить.",
            cameraUnavailableContinue:"Камера недоступна. Вы можете продолжить с аудио.",
            cameraListFailed:"Не удалось получить список камер.",
            cameraCheckRetry:"Камера недоступна. Проверьте устройство и разрешения, затем повторите попытку.",
            webrtcNeeded:"Для звонков нужен системный браузер или WebView с поддержкой WebRTC.",
            waitingFor:"Ожидание {name}",
            waitingForAppDesc:"Откройте Longvox на другом устройстве в течение минуты, чтобы принять звонок.",
            callingName:"Вызов {name}",
            callingContactDesc:"Ожидание ответа контакта в Longvox.",
            inviteSomeone:"Пригласить собеседника",
            inviteDesc:"Передайте это одноразовое приглашение лично. Оно действует 10 минут. Вы сами решите, отвечать ли.",
            pasteInvite:"Вставьте приглашение на звонок Longvox.",
            unknownCallType:"Неизвестный тип звонка.",
            unsupportedGroupInvite:"Неподдерживаемое групповое приглашение.",
            joinThreeTitle:"Присоединиться к аудиозвонку на троих?",
            joinThreeDesc:"Оба собеседника будут слышать вас. Хост сохранит все три голоса в одну запись. Подтвердите вход.",
            joinGroupTitle:"Присоединиться к групповому видеозвонку?",
            joinGroupDesc:"До четырёх человек смогут видеть и слышать вас. Хост Windows запишет голоса и включённые камеры в Longvox. Подтвердите вход.",
            joinAudioTitle:"Присоединиться к аудиозвонку?",
            joinVideoTitle:"Присоединиться к видеозвонку?",
            joinAudioDesc:"Хост сохранит оба голоса в своей библиотеке Longvox. Каждый микрофон может записываться отдельно для расшифровки.",
            joinVideoDesc:"Хост сохранит оба голоса и включённые камеры в своей библиотеке Longvox. Каждый микрофон может записываться отдельно для расшифровки.",
            callTypeChanged:"Тип звонка изменился. Запросите новое приглашение.",
            waitingHostAnswer:"Ожидание ответа организатора.",
            longvoxCall:"Звонок Longvox",
            theParticipant:"участник",
            callEnded:"Звонок завершён.",
            youLeftMeeting:"Вы вышли из встречи.",
            hostEndedMeeting:"Организатор завершил встречу.",
            hostRemovedYou:"Организатор удалил вас со встречи.",
            hostRecordingFault:"Организатор не смог продолжить запись.",
            peerStoppedRecording:"Другое устройство остановило запись.",
            connectionInterrupted:"Связь прервана. Переподключение…",
            connectionLost:"Связь потеряна. Записанная часть сохранена.",
            groupConnectionLost:"Связь потеряна. Попросите организатора прислать новое приглашение.",
            keepTalkingReconnecting:"Можно продолжать разговор. Попытка переподключения…",
            reconnectingErr:"Переподключение… {msg}",
            recordingStopped:"Запись остановлена: {msg}",
            connectingTo:"Подключение к {name}",
            recordedOnWindows:"Этот звонок записывается на Windows.",
            nameIsCalling:"Звонит {name}",
            answerAudioDesc:"Ответьте, чтобы записать этот аудиозвонок с согласия собеседника. Каждый микрофон сохраняется для расшифровки.",
            answerVideoDesc:"Ответьте, чтобы записать этот видеозвонок с согласия собеседника. Каждый микрофон сохраняется для расшифровки.",
            inviteExpired:"Срок приглашения истёк. Создайте новый звонок.",
            noAnswer:"Нет ответа. Приглашение закрыто.",
            callDeclined:"Звонок отклонён.",
            callCancelled:"Звонок отменён.",
            peerRecordingFault:"Другое устройство не смогло продолжить запись.",
            lostContact:"Потеряна связь с другим устройством.",
            tryingToReach:"Попытка связаться с другим устройством…",
            savingRecording:"Сохранение записи…",
            recordingInterrupted:"Запись прервана. {msg}",
            savedInMeetings:" Сохранено в «Встречи».",
            confirmCode:"Убедитесь, что на другом экране показан код {code}.",
            visibleNearby:"Виден рядом. Выберите этот ПК на другом устройстве для подключения.",
            numbersMatchAllow:"Коды совпадают · Разрешить",
            ignore:"Игнорировать",
            noSavedContacts:"Сохранённых контактов пока нет.",
            contactCalling:" звонит",
            contactActive:" · Longvox активен",
            contactWaiting:" · Ожидание Longvox",
            answerRequest:"Ответить ({kind})",
            dismiss:"Скрыть",
            remove:"Удалить",
            removeConfirm:"Удалить {name} из контактов для звонков?",
            contactLinkCopied:"Ссылка контакта скопирована.",
            copySelectedContactLink:"Скопируйте выделенную ссылку контакта.",
            inviteCopied:"Приглашение скопировано.",
            copySelectedInvite:"Скопируйте выделенное приглашение.",
            connectingShort:"Подключение",
            yourContact:"ваш контакт",
            groupCameraUnavailable:"Камера недоступна. Звук продолжает работать.",
            groupCameraAudioOn:"Камера недоступна. Звук включён.",
            guestNum:"Гость {n}",
            seatCallingSaved:"Вызов сохранённого контакта",
            seatAwaitingInvite:"Ожидание приглашения",
            seatInviteCopied:"Приглашение скопировано для {name}.",
            seatWantsToJoin:"Хочет присоединиться",
            seatConnecting:"Подключение",
            seatCouldNotConnect:"Не удалось подключиться",
            admit:"Впустить",
            seatDeclined:"Отклонён",
            seatLeft:"Вышел",
            seatExpired:"Приглашение истекло",
            seatNoAnswer:"Нет ответа",
            seatDisconnected:"Отключился",
            seatInMeeting:"На встрече",
            seatReconnecting:"Переподключение",
            seatConnectionLost:"Связь потеряна",
            seatMeetingEnded:"Встреча завершена",
            groupRecordingInterrupted:"Запись прервана. {msg}",
            groupSaved:"Групповая запись сохранена в «Встречи».",
            groupClosed:"Групповой звонок завершён.",
            rosterSpeaking:"Говорит",
            rosterMicOn:"Микрофон включён",
            rosterMicMuted:"Микрофон выключен",
            rosterMicUnknown:"Состояние микрофона неизвестно",
            rosterCameraOn:"Камера включена",
            rosterCameraOff:"Камера выключена"
        }
    };
    function resolveLang(hint) {
        const raw = hint || queryLang || document.documentElement.dataset.lang ||
            navigator.languages?.[0] || navigator.language || "en";
        return String(raw).toLowerCase().startsWith("ru") ? "ru" : "en";
    }
    let currentLang = resolveLang();
    function t(key, vars = null) {
        const dict = I18N[currentLang] || I18N.en;
        let out = Object.hasOwn(dict, key) ? dict[key] : (I18N.en[key] ?? key);
        if (vars) {
            for (const [k, v] of Object.entries(vars)) out = out.replaceAll("{" + k + "}", String(v ?? ""));
        }
        return out;
    }
    const setText = (id, key, vars) => { const el = $(id); if (el) el.textContent = t(key, vars); };
    const setAttr = (id, attr, key) => { const el = $(id); if (el) el.setAttribute(attr, t(key)); };
    function applyStaticTranslations() {
        document.documentElement.lang = currentLang;
        document.title = t("pageTitle");
        setText("record", "recordBadge");
        setText("lobbyTitle", "lobbyTitle");
        setText("intro", apple ? "introApple" : "introDesktop");
        setText("nameLabel", "yourName");
        setText("contactsLegend", "contacts");
        setText("openContacts", "openContacts");
        setText("nearbyVisibleLabel", "showNearby");
        setText("nearbyHeading", "nearby");
        setText("inviteContact", "inviteByLink");
        setText("contactLinkLabel", "privateContactLink");
        setText("contactLinkHint", "contactLinkHint");
        setText("copyContactLink", "copyLink");
        setText("pairPhone", "showQR");
        setText("revokeContactLink", "revokeLink");
        setAttr("contactQR", "aria-label", "contactQRLabel");
        setText("createLegend", "startACall");
        setText("routesLabel", "privateNetwork");
        setText("voice", "audioCall");
        setText("video", "videoCall");
        setText("groupVideo", "groupVideoCall");
        setText("joinLegend", "joinACall");
        setText("inviteCodeLabel", "invitation");
        setText("join", "reviewInvitation");
        setText("deviceCheckLegend", "deviceCheckLegend");
        setText("checkDevicesBtn", "checkCameraMic");
        setText("stopDeviceCheck", "stopDeviceCheck");
        setText("previewShowCameraLabel", "previewShowCamera");
        setText("shareLabel", "privateInvitation");
        setText("copy", "copyInvitation");
        setText("previewMicLabel", "micLevel");
        setText("previewMicPickLabel", "microphone");
        setText("previewCamPickLabel", "camera");
        setText("startCameraLabel", "startWithCamera");
        setText("decline", "decline");
        setText("cancel", "cancel");
        setAttr("callTimer", "aria-label", "callDuration");
        setText("selfMutedBadge", "youMuted");
        setText("selfMuteTag", "muted");
        setText("participantsHeading", "participants");
        setText("participantsClose", "close");
        setAttr("participantsClose", "aria-label", "closeParticipants");
        setText("participantsHostNote", "participantsHostNote");
        setText("participantsToggleLabel", "participants");
        setText("guestPeopleTitle", "participants");
        setText("groupPeopleTitle", "participants");
        setText("enableSound", "enableSound");
        setText("outputLabel", "speakerOutput");
        setText("hangup", "endCall");
        setText("switchCamera", "switchCamera");
        setText("groupTitle", "groupVideoCall");
        setAttr("groupTimer", "aria-label", "callDuration");
        setText("groupSelfMutedBadge", "youMuted");
        setText("groupConsent", "groupConsent");
        setText("groupStart", "startGroupCall");
        setText("groupBack", "cancel");
        setAttr("groupPicture", "aria-label", "groupVideoLabel");
        setText("groupSound", "enableAudio");
        setText("groupEnd", "endMeeting");
        setText("finishedTitle", "meetingEnded");
        setText("finishedText", "finishedText");
        setAttr("memberTimer", "aria-label", "callDuration");
    }
    if (apple) {
        $("create").hidden = true;
    } else history.replaceState(null, "", "/");
    applyStaticTranslations();
    const sleep = ms => new Promise(r => setTimeout(r, ms));
    const videoQuality = {width:{ideal:1280},height:{ideal:720},frameRate:{ideal:30,max:30}};
    const audioQuality = {echoCancellation:true,noiseSuppression:true,autoGainControl:true};
    const AudioCtx = window.AudioContext || window.webkitAudioContext;
    const prefMemory = Object.assign({mic:"", cam:"", output:""}, window.longvoxDevicePrefs || {});
    const prefKey = kind => "longvox.call." + kind;
    const devicePrefs = {
        get(kind) {
            try {
                const stored = window.localStorage?.getItem(prefKey(kind));
                if (typeof stored === "string") return stored;
            } catch { /* Private or non-persistent WebViews may block localStorage. */ }
            return prefMemory[kind] || "";
        },
        set(kind, value) {
            const clean = typeof value === "string" ? value : "";
            prefMemory[kind] = clean;
            try {
                if (clean) window.localStorage?.setItem(prefKey(kind), clean);
                else window.localStorage?.removeItem(prefKey(kind));
            } catch { /* Keep in-memory choice for this call window. */ }
            try { window.longvoxOnDevicePref?.(kind, clean); } catch {}
        }
    };
    const micConstraints = id => id ? {...audioQuality, deviceId:{exact:id}} : {...audioQuality};
    const camConstraints = id => id ? {...videoQuality, deviceId:{exact:id}} : {...videoQuality, facingMode:"user"};
    const isDeviceConstraintError = e => ["NotFoundError", "OverconstrainedError"].includes(e?.name);
    async function enumerateMedia() {
        if (!navigator.mediaDevices?.enumerateDevices) return {mics:[], cams:[], outputs:[]};
        try {
            const all = await navigator.mediaDevices.enumerateDevices();
            return {
                mics: all.filter(d => d.kind === "audioinput" && d.deviceId),
                cams: all.filter(d => d.kind === "videoinput" && d.deviceId),
                outputs: all.filter(d => d.kind === "audiooutput" && d.deviceId)
            };
        } catch { return {mics:[], cams:[], outputs:[]}; }
    }
    function fillDeviceSelect(select, devices, preferred, fallbackPrefix) {
        if (!select) return;
        const unique = [];
        const seen = new Set();
        for (const d of devices) {
            if (!d.deviceId || d.deviceId === "default" || seen.has(d.deviceId)) continue;
            seen.add(d.deviceId);
            unique.push(d);
        }
        select.replaceChildren(
            new Option(t("systemDefault"), ""),
            ...unique.map((d, i) => new Option(d.label || (fallbackPrefix + " " + (i + 1)), d.deviceId))
        );
        const target = preferred && unique.some(d => d.deviceId === preferred) ? preferred : "";
        select.value = target;
    }
    function makePreview(els, {prefs = devicePrefs, micReq = micConstraints, camReq = camConstraints} = {}) {
        let session = 0, audioGen = 0, videoGen = 0, listGen = 0, active = false, wantVideo = false;
        let audioStream = null, videoStream = null, meterCtx = null, meterFrame = 0;
        const stopStream = stream => {
            for (const tr of stream?.getTracks() || []) { tr.onended = null; tr.stop(); }
        };
        const stopMeter = () => {
            if (meterFrame) { cancelAnimationFrame(meterFrame); meterFrame = 0; }
            if (meterCtx && meterCtx.state !== "closed") void meterCtx.close().catch(() => {});
            meterCtx = null;
            if (els.meter) { els.meter.value = 0; els.meter.setAttribute("aria-valuenow", "0"); }
        };
        const stopVideo = () => {
            videoGen++;
            stopStream(videoStream);
            videoStream = null;
            if (els.video) { els.video.srcObject = null; els.video.hidden = true; }
        };
        const stopAudio = () => {
            audioGen++;
            stopMeter();
            stopStream(audioStream);
            audioStream = null;
        };
        const showOff = text => {
            if (els.video) els.video.hidden = true;
            if (els.off) els.off.hidden = false;
            if (els.offText) els.offText.textContent = text;
            if (els.modeTag) els.modeTag.hidden = true;
        };
        async function refreshLists() {
            const mySession = session, myList = ++listGen;
            const {mics, cams} = await enumerateMedia();
            if (mySession !== session || myList !== listGen || !active) return;
            const activeMic = audioStream?.getAudioTracks()[0]?.getSettings?.().deviceId || "";
            const activeCam = videoStream?.getVideoTracks()[0]?.getSettings?.().deviceId || "";
            fillDeviceSelect(els.micSelect, mics, prefs.get("mic") || activeMic, t("microphone"));
            fillDeviceSelect(els.camSelect, cams, prefs.get("cam") || activeCam, t("camera"));
        }
        async function openAudio() {
            stopAudio();
            const mySession = session, myAudio = audioGen;
            if (!active) return;
            if (!navigator.mediaDevices?.getUserMedia) {
                if (els.meterState) els.meterState.textContent = t("micUnavailableShort");
                return;
            }
            const pref = prefs.get("mic");
            let stream = null;
            try { stream = await navigator.mediaDevices.getUserMedia({audio:micReq(pref), video:false}); }
            catch (e) {
                if (mySession !== session || myAudio !== audioGen || !active) return;
                if (pref && isDeviceConstraintError(e)) {
                    try { stream = await navigator.mediaDevices.getUserMedia({audio:micReq(""), video:false}); }
                    catch { stream = null; }
                } else stream = null;
            }
            if (mySession !== session || myAudio !== audioGen || !active) { stopStream(stream); return; }
            if (!stream || !stream.getAudioTracks().length) {
                stopStream(stream);
                if (els.meterState) els.meterState.textContent = t("micUnavailableShort");
                return;
            }
            stopMeter();
            stopStream(audioStream);
            audioStream = stream;
            if (els.meterState) els.meterState.textContent = t("micReady");
            const track = stream.getAudioTracks()[0];
            track.onended = () => {
                if (mySession === session && myAudio === audioGen && active && audioStream === stream) {
                    stopAudio();
                    if (els.meterState) els.meterState.textContent = t("micDisconnectedShort");
                }
            };
            if (AudioCtx && els.meter) {
                try {
                    meterCtx = new AudioCtx();
                    if (meterCtx.state === "suspended") void meterCtx.resume().catch(() => {});
                    const source = meterCtx.createMediaStreamSource(stream);
                    const analyser = meterCtx.createAnalyser();
                    analyser.fftSize = 256;
                    source.connect(analyser);
                    const samples = new Uint8Array(analyser.fftSize);
                    let smoothed = 0;
                    const tick = () => {
                        if (mySession !== session || myAudio !== audioGen || !active || !meterCtx) return;
                        analyser.getByteTimeDomainData(samples);
                        let sum = 0;
                        for (let i = 0; i < samples.length; i++) {
                            const centered = (samples[i] - 128) / 128;
                            sum += centered * centered;
                        }
                        const rms = Math.sqrt(sum / samples.length);
                        const level = Math.min(100, Math.round(rms * 260));
                        smoothed = level > smoothed ? level : Math.max(0, smoothed * 0.82);
                        const shown = Math.round(smoothed);
                        els.meter.value = shown;
                        els.meter.setAttribute("aria-valuenow", String(shown));
                        meterFrame = requestAnimationFrame(tick);
                    };
                    meterFrame = requestAnimationFrame(tick);
                } catch { /* Meter is optional if audio context cannot open yet. */ }
            }
            await refreshLists();
        }
        async function openVideo() {
            stopVideo();
            const mySession = session, myVideo = videoGen;
            if (!active) return;
            if (!wantVideo) { showOff(t("cameraOffState")); return; }
            if (els.startCamera && !els.startCamera.checked) { showOff(t("cameraOffState")); return; }
            if (!navigator.mediaDevices?.getUserMedia) { showOff(t("cameraUnavailableShort")); return; }
            showOff(t("startingCamera"));
            const pref = prefs.get("cam");
            let stream = null;
            try { stream = await navigator.mediaDevices.getUserMedia({audio:false, video:camReq(pref)}); }
            catch (e) {
                if (mySession !== session || myVideo !== videoGen || !active || !wantVideo || (els.startCamera && !els.startCamera.checked)) return;
                if (pref && isDeviceConstraintError(e)) {
                    try { stream = await navigator.mediaDevices.getUserMedia({audio:false, video:camReq("")}); }
                    catch { stream = null; }
                } else stream = null;
            }
            if (mySession !== session || myVideo !== videoGen || !active || !wantVideo || (els.startCamera && !els.startCamera.checked)) {
                stopStream(stream); return;
            }
            if (!stream || !stream.getVideoTracks().length) { stopStream(stream); showOff(t("cameraUnavailableShort")); return; }
            stopStream(videoStream);
            videoStream = stream;
            const track = stream.getVideoTracks()[0];
            track.onended = () => {
                if (mySession === session && myVideo === videoGen && active && videoStream === stream) {
                    stopVideo(); showOff(t("cameraDisconnectedShort"));
                }
            };
            if (els.video) {
                els.video.srcObject = stream;
                els.video.hidden = false;
                els.video.play().catch(() => {});
            }
            if (els.off) els.off.hidden = true;
            if (els.modeTag) {
                els.modeTag.textContent = t("videoPreview");
                els.modeTag.hidden = false;
            }
            await refreshLists();
        }
        const resumeMeter = () => { if (meterCtx?.state === "suspended") void meterCtx.resume().catch(() => {}); };
        els.card?.addEventListener("pointerdown", resumeMeter);
        els.card?.addEventListener("keydown", resumeMeter);
        if (els.micSelect) els.micSelect.onchange = () => {
            prefs.set("mic", els.micSelect.value);
            if (active) void openAudio();
        };
        if (els.camSelect) els.camSelect.onchange = () => {
            prefs.set("cam", els.camSelect.value);
            if (active && wantVideo && (!els.startCamera || els.startCamera.checked)) void openVideo();
        };
        if (els.startCamera) els.startCamera.onchange = () => {
            if (!active || !wantVideo) return;
            if (els.startCamera.checked) void openVideo();
            else { stopVideo(); showOff(t("cameraOffState")); }
        };
        return {
            get active() { return active; },
            get wantVideo() { return wantVideo; },
            start(videoMode) {
                session++; active = true; wantVideo = Boolean(videoMode);
                stopAudio(); stopVideo();
                if (els.card) els.card.hidden = false;
                if (els.toggleBtn) { els.toggleBtn.setAttribute("aria-expanded", "true"); els.toggleBtn.hidden = true; }
                if (els.stage) els.stage.dataset.mode = wantVideo ? "video" : "audio";
                if (els.camField) els.camField.hidden = !wantVideo;
                if (els.meterState) els.meterState.textContent = t("micChecking");
                if (!wantVideo || (els.startCamera && !els.startCamera.checked)) showOff(t("cameraOffState"));
                else showOff(t("startingCamera"));
                void refreshLists();
                void openAudio();
                if (wantVideo && (!els.startCamera || els.startCamera.checked)) void openVideo();
            },
            refreshLabels() {
                if (!active) return;
                if (els.modeTag) {
                    els.modeTag.textContent = t("videoPreview");
                    els.modeTag.hidden = !videoStream;
                }
                if (els.meterState) els.meterState.textContent = audioStream ? t("micReady") : t("micUnavailableShort");
                if (!videoStream) {
                    showOff(t("cameraOffState"));
                }
                void refreshLists();
            },
            refreshLists() { if (active) return refreshLists(); },
            stop() {
                session++; listGen++; active = false; wantVideo = false;
                stopAudio(); stopVideo();
                if (els.card) els.card.hidden = true;
                if (els.toggleBtn) { els.toggleBtn.setAttribute("aria-expanded", "false"); els.toggleBtn.hidden = false; }
                if (els.modeTag) els.modeTag.hidden = true;
                if (els.meterState) els.meterState.textContent = "";
            }
        };
    }
    const lobbyPreview = makePreview({
        card:$("preCallPreview"), stage:$("previewStage"), video:$("previewVideo"), off:$("previewOff"),
        offText:$("previewOffText"), modeTag:$("previewModeTag"), meter:$("previewMicMeter"),
        meterState:$("previewMicState"), micSelect:$("previewMic"), camSelect:$("previewCam"),
        camField:$("previewCamField"), startCamera:$("previewShowCamera"), toggleBtn:$("checkDevicesBtn")
    });
    $("checkDevicesBtn").onclick = () => {
        if (lobbyPreview.active) lobbyPreview.stop();
        else if (!$("lobby").hidden) { $("previewShowCamera").checked = true; lobbyPreview.start(true); }
    };
    $("stopDeviceCheck").onclick = () => lobbyPreview.stop();
    function formatDuration(totalSeconds) {
        const secs = Math.max(0, Math.floor(totalSeconds));
        const h = Math.floor(secs / 3600), m = Math.floor((secs % 3600) / 60), s = secs % 60;
        const pad = n => String(n).padStart(2, "0");
        return h > 0 ? `${h}:${pad(m)}:${pad(s)}` : `${pad(m)}:${pad(s)}`;
    }
    function makeTimer(el) {
        let startedAt = 0, interval = 0;
        const render = () => {
            if (!startedAt || !el) return;
            el.textContent = formatDuration((Date.now() - startedAt) / 1000);
        };
        return {
            start() {
                if (startedAt || !el) return;
                startedAt = Date.now();
                el.hidden = false;
                render();
                interval = setInterval(render, 1000);
            },
            stop() {
                clearInterval(interval); interval = 0; startedAt = 0;
                if (el) { el.hidden = true; el.textContent = "00:00"; }
            },
            get running() { return startedAt > 0; }
        };
    }
    function makeQualityMonitor(badgeEl, textEl, detailEl, getLabels) {
        let interval = 0, token = 0, prev = null, getPeer = null, isReconnecting = null;
        const setUI = (state, detail = "") => {
            if (!badgeEl || !textEl) return;
            const labels = getLabels();
            badgeEl.hidden = false;
            badgeEl.dataset.quality = state;
            textEl.textContent = labels[state] || state;
            if (detailEl) {
                detailEl.textContent = detail;
                detailEl.hidden = !detail;
            }
        };
        async function sample(run) {
            if (run !== token || !getPeer) return;
            const peer = getPeer();
            if (isReconnecting?.()) { setUI("reconnecting"); return; }
            if (!peer || peer.connectionState !== "connected") { setUI("connecting"); return; }
            let stats;
            try { stats = await peer.getStats(); }
            catch { return; }
            if (run !== token) return;
            if (isReconnecting?.()) { setUI("reconnecting"); return; }
            let pair = null, rttSec = null, curRecv = 0, curLost = 0, hasInbound = false, remoteFraction = null;
            for (const report of stats.values()) {
                if (report.type === "transport" && report.selectedCandidatePairId) {
                    pair = stats.get(report.selectedCandidatePairId) || pair;
                }
            }
            if (!pair) {
                for (const report of stats.values()) {
                    if (report.type === "candidate-pair" && report.state === "succeeded" && (report.nominated || !pair)) {
                        pair = report;
                        if (report.nominated) break;
                    }
                }
            }
            if (pair && Number.isFinite(pair.currentRoundTripTime)) rttSec = pair.currentRoundTripTime;
            for (const report of stats.values()) {
                if (report.type === "inbound-rtp" && (report.kind === "audio" || report.kind === "video" || !report.kind)) {
                    hasInbound = true;
                    if (Number.isFinite(report.packetsReceived)) curRecv += report.packetsReceived;
                    if (Number.isFinite(report.packetsLost)) curLost += Math.max(0, report.packetsLost);
                } else if (report.type === "remote-inbound-rtp") {
                    if (rttSec === null && Number.isFinite(report.roundTripTime)) rttSec = report.roundTripTime;
                    if (Number.isFinite(report.fractionLost)) {
                        remoteFraction = remoteFraction === null ? report.fractionLost : Math.max(remoteFraction, report.fractionLost);
                    }
                }
            }
            let lossPct = null;
            if (hasInbound) {
                const dRecv = prev ? Math.max(0, curRecv - prev.recv) : curRecv;
                const dLost = prev ? Math.max(0, curLost - prev.lost) : curLost;
                prev = {recv:curRecv, lost:curLost};
                const total = dRecv + dLost;
                if (total > 0) lossPct = (dLost / total) * 100;
            } else if (remoteFraction !== null) {
                lossPct = Math.max(0, Math.min(100, remoteFraction * 100));
            }
            const rttMs = rttSec !== null ? Math.round(rttSec * 1000) : null;
            let state = "good";
            if ((rttMs !== null && rttMs >= 350) || (lossPct !== null && lossPct >= 6)) state = "poor";
            else if ((rttMs !== null && rttMs >= 150) || (lossPct !== null && lossPct >= 2)) state = "fair";
            const labels = getLabels();
            const parts = [];
            if (rttMs !== null) parts.push(`${rttMs} ${labels.msUnit}`);
            if (lossPct !== null) parts.push(`${Math.round(lossPct)}% ${labels.lossLabel}`);
            setUI(state, parts.join(" · "));
        }
        return {
            start(peerFn, reconFn) {
                this.stop();
                token++;
                const run = token;
                getPeer = peerFn; isReconnecting = reconFn;
                prev = null;
                void sample(run);
                interval = setInterval(() => { void sample(run); }, 2000);
            },
            refreshNow() {
                if (!getPeer) return;
                void sample(token);
            },
            stop() {
                token++; clearInterval(interval); interval = 0; prev = null; getPeer = isReconnecting = null;
                if (badgeEl) { badgeEl.hidden = true; badgeEl.dataset.quality = "connecting"; }
                if (detailEl) { detailEl.hidden = true; detailEl.textContent = ""; }
            }
        };
    }
    const liveTrack = (stream, kind) => stream?.getTracks().find(t => t.kind === kind && t.readyState === "live") || null;
    function pruneEndedTracks(stream, kind) {
        if (!stream) return;
        for (const t of stream.getTracks()) {
            if (t.kind === kind && t.readyState === "ended") { t.onended = null; stream.removeTrack(t); }
        }
    }
    const callTimer = makeTimer($("callTimer"));
    const callQuality = makeQualityMonitor($("qualityBadge"), $("qualityText"), $("qualityDetail"), () => ({
        connecting:t("connecting"), good:t("goodConnection"), fair:t("fairConnection"), poor:t("poorConnection"),
        reconnecting:t("reconnecting"), msUnit:t("msUnit"), lossLabel:t("lossLabel")
    }));
    let reconnectingNow = false;
    let groupRosterInterval = 0, lastParticipantsKey = "";
    const isGroupGuest = () => role === "guest" && groupConsent === 4;
    const myDisplayName = () => $("name")?.value.trim() || t("you");
    function syncWorkspaceDrawer() {
        const open = !$("participantsPanel").hidden;
        if ($("callWorkspace")) $("callWorkspace").dataset.drawerOpen = String(open);
    }
    function closeAllDrawers(except = "") {
        if (except !== "participants" && !$("participantsPanel").hidden) {
            $("participantsPanel").hidden = true;
            $("participantsToggle").setAttribute("aria-expanded", "false");
        }
    }
    function buildParticipants() {
        const me = myDisplayName();
        const myMuted = Boolean(liveTrack(local, "audio")) && micMuted;
        const myCamOff = mode === "video" && !Boolean(liveTrack(local, "video")?.enabled);
        if (!isGroupGuest()) {
            const list = [];
            if (other) {
                list.push({
                    id:"peer", name:other, role:role === "guest" ? "host" : "guest",
                    isSelf:false, micMuted:false, micLost:peerMicLost,
                    cameraOff:mode === "video" && $("remote").dataset.cameraOff === "true", announced:false
                });
            }
            list.push({
                id:"self", name:me, role:role === "host" ? "host" : "guest",
                isSelf:true, micMuted:myMuted, micLost:!liveTrack(local, "audio"), cameraOff:myCamOff, announced:false
            });
            return list;
        }
        const announced = [];
        if (other) {
            announced.push({
                id:"host", name:other, role:"host", isSelf:false,
                micMuted:null, micLost:peerMicLost, cameraOff:null, announced:true
            });
        }
        if (groupWindows?.members) {
            for (const [id, entry] of groupWindows.members.entries()) {
                const name = entry?.share?.name;
                if (typeof name === "string" && name.trim()) {
                    announced.push({
                        id, name:name.trim(), role:"guest", isSelf:false,
                        micMuted:null, micLost:false, cameraOff:null, announced:true
                    });
                }
            }
        }
        return announced;
    }
    function renderParticipants(force = false) {
        const participants = buildParticipants();
        const isGroup = isGroupGuest();
        $("participantsCount").hidden = isGroup;
        $("participantsCount").textContent = String(participants.length);
        $("participantsHostNote").hidden = !isGroup;
        if (isGroup) $("participantsHostNote").textContent = t("participantsHostNote");
        const selfLive = Boolean(liveTrack(local, "video")?.enabled);
        $("remoteTileName").textContent = other || t("participant");
        $("remoteTileName").hidden = isGroup || !other;
        $("selfTileName").textContent = myDisplayName();
        $("selfTileName").hidden = !selfLive || isGroup;

        const key = JSON.stringify({
            currentLang, isGroup,
            p:participants.map(p => [p.id, p.name, p.role, p.isSelf, p.micMuted, p.micLost, p.cameraOff, p.announced])
        });
        if (!force && key === lastParticipantsKey) return;
        lastParticipantsKey = key;

        const listEl = $("participantsList");
        listEl.replaceChildren();
        for (const p of participants) {
            const li = document.createElement("li");
            li.className = "participant-row";
            const main = document.createElement("div");
            main.className = "participant-main";
            const nameEl = document.createElement("span");
            nameEl.className = "participant-name";
            nameEl.textContent = p.name;
            const meta = document.createElement("div");
            meta.className = "participant-meta";
            const addTag = (label, cls = "") => {
                const tag = document.createElement("span");
                tag.className = "participant-tag" + (cls ? " " + cls : "");
                tag.textContent = label;
                meta.append(tag);
            };
            if (p.role === "host") addTag(t("hostRole"), "tag-host");
            else if (isGroup && p.announced) addTag(t("announcedByHost"));
            if (!isGroup && p.isSelf) addTag(t("you"));
            if (p.micLost) addTag(t("micDisconnectedTag"), "tag-muted");
            else if (!isGroup && p.isSelf && micMuted) addTag(t("muted"), "tag-muted");
            if (p.cameraOff === true) addTag(t("cameraOffState"));
            main.append(nameEl, meta);
            li.append(main);
            listEl.append(li);
        }
    }
    function toggleParticipantsPanel(forceOpen) {
        const open = forceOpen !== undefined ? Boolean(forceOpen) : $("participantsPanel").hidden;
        if (open) closeAllDrawers("participants");
        $("participantsPanel").hidden = !open;
        $("participantsToggle").setAttribute("aria-expanded", String(open));
        if (open) renderParticipants(true);
        syncWorkspaceDrawer();
    }
    function resetParticipants() {
        clearInterval(groupRosterInterval); groupRosterInterval = 0;
        lastParticipantsKey = "";
        $("remoteTileName").hidden = $("selfTileName").hidden = true;
        $("participantsCount").hidden = false;
        $("participantsPanel").hidden = true;
        $("participantsToggle").hidden = false;
        $("participantsToggle").setAttribute("aria-expanded", "false");
        syncWorkspaceDrawer();
    }
    $("participantsToggle").onclick = () => toggleParticipantsPanel();
    $("participantsClose").onclick = () => toggleParticipantsPanel(false);
    navigator.mediaDevices?.addEventListener?.("devicechange", () => {
        void lobbyPreview.refreshLists();
        if (local && !ending) void outputChoices();
    });
    window.addEventListener("pagehide", () => { lobbyPreview.stop(); });
    let role, mode, pc, local, remote, context, capture, cursor, polling, ending, epoch = 0, generation = 0;
    let outbound, peerCanRestartIce = false, usingRelay = false;
    let micMuted = false, micWasLost = false, peerMicLost = false, peerMicMuted = false, groupConsent = undefined, nativeLaunch = false;
    let callKitAudio = null, lastRoster = null;
    let group = null, namedHost = "", lastDelivery = "waiting";
    let linkMarks = Promise.resolve(), admission, startingCapture, other, reconnect, grace, control, wake, sessionActive = false;
    let lastStatus = null, lastWait = null;
    const status = text => { lastStatus = null; $("status").textContent = text; };
    const statusKey = (key, vars = null) => { lastStatus = {key, vars}; $("status").textContent = t(key, vars); };
    const show = id => {
        if (id !== "lobby") lobbyPreview.stop();
        for (const name of ["lobby", "waiting", "meeting", "groupMeeting", "finished", "memberCall"]) $(name).hidden = name !== id;
    };
    async function post(path, data, signal) {
        if (apple && path === "/call") return await apple.postMessage(JSON.parse(data));
        const r = await fetch(path, {method:"POST", headers:{"X-Longvox-Window":token,
            "Content-Type":typeof data === "string" ? "application/json" : "application/octet-stream"}, body:data, signal});
        const result = await r.json();
        if (!r.ok) throw Error(result.error || t("requestFailed"));
        return result;
    }
    const api = (op, fields = {}, signal) => post("/call", JSON.stringify({op, ...fields}), signal);
    const visibility = () => ({visibility:document.visibilityState});
    const trace = (event, fields = {}) => { if (apple) void api("audio_trace", {event, ...fields}).catch(() => {}); };
    if (apple) trace("js_ready", {...visibility(), secure:isSecureContext});
    if (!apple) api("interfaces").then(async ({addresses,contacts,openContacts,launch}) => {
        $("contacts").hidden = !contacts;
        $("route").replaceChildren(...addresses.map(ip => new Option(ip, ip)));
        $("routes").hidden = addresses.length < 2;
        $("groupVideo").hidden = !contacts;
        if (launch) {
            nativeLaunch = true;
            $("name").value = launch.name;
            $("route").value = launch.address;
            if (launch.mode === "join") { $("code").value = launch.invite; review(); return; }
            if (launch.contacts.length) await api("contacts_open", {address:launch.address});
            if (launch.mode === "group") return prepareGroup(launch.contacts, launch.answers, true, launch.contactNames);
            return host(launch.mode, launch.contacts.length ? {id:launch.contacts[0], name:launch.contactNames?.[0] || t("yourContact"), requestRef:launch.answers?.[launch.contacts[0]], waitingForApp:launch.waitingForApp} : null);
        }
        if (openContacts) return refreshContacts(true);
    }).catch(e => status(e.message));
    function signal(kind, fields = {}) {
        const message = {kind, ...fields};
        const queue = outbound, run = epoch;
        queue.tail = queue.tail.catch(() => {}).then(async () => {
            if (run !== epoch) return;
            const terminal = ["leave", "decline", "fault"].includes(kind);
            const deadline = Date.now() + (terminal ? 1500 : 20000);
            async function deliver(data) {
                for (;;) {
                    try { await api("send", data); break; }
                    catch (e) {
                        if (Date.now() >= deadline || run !== epoch) throw e;
                        await sleep(500);
                        if (run !== epoch) throw e;
                    }
                }
                queue.seq++;
                queue.unconfirmed = null;
            }
            // A lost acknowledgement may conceal a successful send. The room accepts
            // an exact replay at its original position before it accepts the next signal.
            if (queue.unconfirmed) await deliver(queue.unconfirmed);
            if (run !== epoch) return;
            queue.unconfirmed = {seq:queue.seq, message};
            await deliver(queue.unconfirmed);
        });
        return queue.tail;
    }
    function waitView(title, description, decision = false, keys = null) {
        lastWait = keys;
        show("waiting");
        $("waitingTitle").textContent = keys ? t(keys.titleKey, keys.titleVars) : title;
        $("waitingText").textContent = keys ? t(keys.descKey, keys.descVars) : description;
        $("decision").hidden = !decision; $("cancel").hidden = decision;
        $("accept").textContent = role === "guest" ? t("joinCall") : t("answerAndJoin");
        $("cameraPreference").hidden = !decision || mode !== "video";
    }
    const callActionButtons = new Set(["accept", "decline", "cancel", "mute", "camera", "switchCamera", "hangup"]);
    function setCallActionsDisabled(disabled) {
        for (const id of callActionButtons) $(id).disabled = disabled;
    }
    function fresh() {
        lobbyPreview.stop(); callTimer.stop(); callQuality.stop();
        epoch++; generation = cursor = 0; linkMarks = Promise.resolve(); ending = false;
        outbound = {seq:0, unconfirmed:null, tail:Promise.resolve()};
        peerCanRestartIce = usingRelay = false;
        admission = capture = startingCapture = undefined; other = ""; remote = new MediaStream();
        $("share").hidden = true; $("record").hidden = true;
        groupConsent = undefined;
        $("hangup").textContent = t("endCall");
        delete $("meeting").dataset.roster;
        lastRoster = null;
        $("guestPeople").hidden = true; $("guestRoster").replaceChildren();
        micMuted = micWasLost = peerMicLost = peerMicMuted = reconnectingNow = false; namedHost = ""; lastDelivery = "waiting";
        setCallActionsDisabled(false); $("mute").classList.remove("is-muted");
        $("selfMutedBadge").hidden = $("peerMutedBadge").hidden = true;
        $("selfMuteTag").hidden = $("remoteMuteTag").hidden = true;
        closeAllDrawers();
        resetParticipants();
        $("micNote").hidden = $("peerMicNote").hidden = true;
        $("enableSound").hidden = $("outputChoice").hidden = true;
        $("startCamera").checked = true; $("cameraNote").hidden = true;
        delete $("remote").dataset.cameraOff;
        $("camera").textContent = t("cameraOff"); $("camera").setAttribute("aria-pressed","false");
        $("switchCamera").hidden = true;
        status("");
    }
    async function playRemoteAudio() {
        const audio = $("remoteAudio"), run = epoch;
        if (ending || callKitAudio === false || !remote?.getAudioTracks().length) return;
        try {
            await audio.play();
            if (ending || epoch !== run) return;
            trace("remote_play", {state:"started"});
            $("enableSound").hidden = !context || context.state === "running";
        } catch (error) {
            if (ending || epoch !== run) return;
            trace("remote_play", {state:"failed", name:error.name});
            if (callKitAudio !== false) $("enableSound").hidden = false;
        }
    }
    if (apple) $("remoteAudio").addEventListener("playing", () => trace("remote_play", {state:"playing"}));
    window.longvoxCallKitAudio = active => {
        callKitAudio = active;
        const track = local?.getAudioTracks()[0];
        if (track) track.enabled = active && !micMuted;
        $("remoteAudio").autoplay = active;
        $("remoteAudio").muted = !active;
        if (active) void playRemoteAudio();
        else $("remoteAudio").pause();
    };
    $("enableSound").onclick = async () => {
        const run = epoch;
        if (ending) return;
        if (context?.state === "suspended") await context.resume();
        if (!ending && epoch === run) await playRemoteAudio();
    };
    async function outputChoices() {
        const audio = $("remoteAudio"), run = epoch;
        if (ending || !audio.setSinkId) return;
        try {
            const outputs = (await navigator.mediaDevices.enumerateDevices()).filter(d => d.kind === "audiooutput" && d.deviceId);
            if (ending || epoch !== run) return;
            $("output").replaceChildren(new Option(t("systemDefault"),""), ...outputs.filter(d => d.deviceId !== "default")
                .map((d, i) => new Option(d.label || t("speakerOutput") + " " + (i + 1), d.deviceId)));
            $("output").value = audio.sinkId || "";
            $("outputChoice").hidden = $("output").options.length < 2;
        } catch { if (!ending && epoch === run) $("outputChoice").hidden = true; }
    }
    $("output").onchange = async () => {
        const run = epoch;
        if (ending) return;
        try { await $("remoteAudio").setSinkId($("output").value); if (!ending && epoch === run) await playRemoteAudio(); }
        catch { if (!ending && epoch === run) status(t("speakerSwitchFailed")); }
    };
    function updateMuteBadges() {
        const ready = Boolean(liveTrack(local, "audio"));
        const showSelfMuted = ready && micMuted;
        $("selfMutedBadge").hidden = !showSelfMuted;
        $("selfMuteTag").hidden = !showSelfMuted || $("self").hidden;
        $("mute").classList.toggle("is-muted", showSelfMuted);
        const peerName = other || t("otherParticipant");
        if (peerMicLost) {
            const label = t("peerMicDisconnectedShort", {name:peerName});
            $("peerMutedBadge").textContent = label;
            $("peerMutedBadge").hidden = false;
            $("remoteMuteTag").textContent = label;
            $("remoteMuteTag").hidden = false;
        } else {
            $("peerMutedBadge").hidden = true;
            $("remoteMuteTag").hidden = true;
        }
        renderParticipants();
    }
    function reportMicrophone() {
        if (control?.readyState === "open") {
            try {
                if (!local?.getAudioTracks().length) {
                    micWasLost = true;
                    control.send("mic-lost");
                } else if (micMuted) {
                    // Older PCs ignore mic-muted, so clear an earlier mic-lost first.
                    if (micWasLost) control.send("mic-ready");
                    control.send("mic-muted");
                    micWasLost = false;
                } else {
                    control.send("mic-ready");
                    micWasLost = false;
                }
            }
            catch { /* The next data channel will report the current microphone. */ }
        }
    }
    function microphoneControls(note = "") {
        pruneEndedTracks(local, "audio");
        const track = liveTrack(local, "audio");
        const ready = Boolean(track);
        if (track) micMuted = !track.enabled;
        $("mute").textContent = ready ? (micMuted ? t("unmute") : t("mute")) : t("reconnectMic");
        if (ready) $("mute").setAttribute("aria-pressed", String(micMuted));
        else $("mute").removeAttribute("aria-pressed");
        $("micNote").textContent = note; $("micNote").hidden = !note;
        updateMuteBadges();
    }
    function watchMicrophone(source, track) {
        track.enabled = !micMuted && callKitAudio !== false;
        if (apple) for (const state of ["mute", "unmute", "ended"])
            track.addEventListener(state, () => trace("mic_track", {state}));
        track.onended = () => {
            if (ending || source !== local || source.getAudioTracks()[0] !== track) return;
            track.onended = null; source.removeTrack(track);
            micWasLost = true;
            capture?.setLocal(source);
            microphoneControls(t("yourMicDisconnected"));
            markConnection(false, "host_microphone");
            reportMicrophone();
        };
        microphoneControls();
    }
    async function microphoneButton() {
        const source = local, run = epoch;
        if (!source || ending) return;
        pruneEndedTracks(source, "audio");
        const current = source.getAudioTracks()[0];
        if (current) {
            micMuted = !micMuted; current.enabled = !micMuted && callKitAudio !== false; microphoneControls(); reportMicrophone();
            return;
        }
        let replacement;
        try { replacement = await openMicrophone(); }
        catch {
            if (run === epoch && !ending) microphoneControls(t("micUnavailableRetry"));
            return;
        }
        if (run !== epoch || source !== local || ending || source.getAudioTracks().length) {
            replacement.getTracks().forEach(t => t.stop()); return;
        }
        const track = replacement.getAudioTracks()[0];
        if (!track || track.readyState === "ended") {
            replacement.getTracks().forEach(t => t.stop());
            microphoneControls(t("micUnavailableTryAgain")); return;
        }
        source.addTrack(track); watchMicrophone(source, track);
        capture?.setLocal(source);
        markConnection(true, "host_microphone");
        reportMicrophone();
        const peer = pc, audio = peer?.getTransceivers().find(t => t.receiver.track.kind === "audio");
        if (audio) {
            try { await audio.sender.replaceTrack(track); }
            catch { if (!ending && peer === pc) reconnectCall("microphone_track"); }
        }
    }
    async function cameras() {
        const devices = await navigator.mediaDevices.enumerateDevices();
        return devices.filter(device => device.kind === "videoinput" && device.deviceId);
    }
    function reportCamera() {
        if (mode === "video" && control?.readyState === "open") {
            try { control.send(local?.getVideoTracks().length ? "camera-on" : "camera-off"); }
            catch { /* The replacement data channel reports the current state when it opens. */ }
        }
    }
    function renderCameraControls(note = "") {
        const enabled = Boolean(local?.getVideoTracks().length);
        $("self").hidden = !enabled || isGroupGuest();
        $("camera").textContent = enabled ? t("cameraOff") : t("cameraOn");
        $("camera").setAttribute("aria-pressed", String(!enabled));
        $("switchCamera").disabled = !enabled;
        $("cameraNote").textContent = note;
        $("cameraNote").hidden = !note;
        updateMuteBadges();
    }
    function cameraControls(note = "") {
        renderCameraControls(note);
        reportCamera();
    }
    async function setCamera(track, note = "") {
        const source = local, peer = pc;
        if (!source || ending) { track?.stop(); return; }
        if (track && track.readyState !== "live") { track.stop(); track = null; }
        const previous = source.getVideoTracks()[0];
        if (previous) {
            previous.onended = null;
            previous.stop();
            source.removeTrack(previous);
        }
        if (track) {
            source.addTrack(track);
            track.onended = () => {
                if (source === local && !ending && source.getVideoTracks()[0] === track)
                    void setCamera(null, t("yourCameraDisconnected"));
            };
        }
        $("self").srcObject = source;
        cameraControls(note);
        const video = peer?.getTransceivers().find(t => t.receiver.track.kind === "video");
        if (video) {
            try { await video.sender.replaceTrack(track); }
            catch { if (!ending && peer === pc) reconnectCall("camera_track"); }
        }
    }
    async function openCamera(deviceId, allowFallback = false) {
        const source = local, run = epoch;
        if (ending || !source) return;
        const selector = deviceId ? {deviceId:{exact:deviceId}} : {facingMode:"user"};
        let result;
        try {
            result = await navigator.mediaDevices.getUserMedia({audio:false, video:{...videoQuality, ...selector}});
        } catch (e) {
            if (ending || epoch !== run || !source || source !== local) return;
            if (allowFallback && deviceId && isDeviceConstraintError(e)) {
                result = await navigator.mediaDevices.getUserMedia({audio:false, video:{...videoQuality, facingMode:"user"}});
            } else throw e;
        }
        if (ending || epoch !== run || !source || source !== local) { result.getTracks().forEach(t => t.stop()); return; }
        await setCamera(result.getVideoTracks()[0]);
        cameras().then(devices => {
            if (!ending && epoch === run && source === local) $("switchCamera").hidden = devices.length < 2;
        }).catch(() => {});
    }
    async function media(run) {
        if (ending || epoch !== run) return false;
        if (!navigator.mediaDevices?.getUserMedia || !window.RTCPeerConnection)
            throw Error(t("webrtcNeeded"));
        const prefMic = devicePrefs.get("mic");
        let stream;
        try {
            stream = await openMicrophone(prefMic);
        } catch (e) {
            if (ending || epoch !== run) return false;
            if (prefMic && isDeviceConstraintError(e)) {
                stream = await openMicrophone();
            } else throw e;
        }
        if (ending || epoch !== run) {
            stream.getTracks().forEach(track => track.stop());
            return false;
        }
        local = stream;
        context = new AudioContext();
        // Some browsers require a gesture to resume audio even after allowing the microphone.
        if (context.state !== "running") {
            $("enableSound").hidden = false;
            void context.resume().catch(() => {});
        }
        $("self").srcObject = local;
        watchMicrophone(stream, stream.getAudioTracks()[0]);
        if (ending || epoch !== run) return false;
        if (mode === "video" && $("startCamera").checked &&
            (callKitAudio === null || (callKitAudio && !document.hidden))) {
            try { await openCamera(devicePrefs.get("cam") || undefined, true); }
            catch { if (!ending && epoch === run) cameraControls(t("cameraUnavailableContinue")); }
        } else if (mode === "video") cameraControls();
        return !ending && epoch === run;
    }
    async function openMicrophone(deviceId) {
        trace("gum_begin", visibility());
        try {
            const stream = await navigator.mediaDevices.getUserMedia({audio:micConstraints(deviceId), video:false});
            const track = stream.getAudioTracks()[0];
            trace("gum_ok", {live:track?.readyState === "live", muted:!!track?.muted, enabled:!!track?.enabled});
            return stream;
        } catch (error) {
            trace("gum_error", {name:error.name});
            throw error;
        }
    }
    async function switchCamera() {
        const source = local, run = epoch;
        const previous = source?.getVideoTracks()[0];
        const active = () => !ending && epoch === run && source === local;
        if (!previous?.enabled || !active()) return;
        const previousId = previous.getSettings().deviceId;
        $("camera").disabled = true;
        try {
            const devices = await cameras();
            const next = devices[(devices.findIndex(device => device.deviceId === previousId) + 1) % devices.length];
            if (!active() || !next || next.deviceId === previousId) return;
            // Phones may grant exclusive access to one camera. The microphone runs independently.
            await setCamera(null);
            if (!active()) return;
            try { await openCamera(next.deviceId); }
            catch (error) {
                if (!active() || !previousId) throw error;
                await openCamera(previousId);
                if (active()) status(t("otherCameraUnavailable"));
                return;
            }
            if (active()) status(t("cameraSwitched"));
        } catch (error) {
            if (active()) cameraControls(previous.readyState === "ended" ? t("cameraUnavailableAudio") : t("cameraListFailed"));
        } finally {
            if (active()) $("camera").disabled = false;
        }
    }
    async function host(chosenMode, contact = null) {
        fresh(); role = "host"; mode = chosenMode; namedHost = contact?.name || "";
        $("create").disabled = $("join").disabled = true;
        let result;
        try { result = await api("host", {name:$("name").value, mode, address:$("route").value, contact:contact?.id, answerRef:contact?.requestRef}); }
        finally { $("create").disabled = $("join").disabled = false; }
        sessionActive = true;
        if (contact?.waitingForApp) waitView("", "", false, {titleKey:"waitingFor", titleVars:{name:contact.name}, descKey:"waitingForAppDesc"});
        else if (contact) waitView("", "", false, {titleKey:"callingName", titleVars:{name:contact.name}, descKey:"callingContactDesc"});
        else waitView("", "", false, {titleKey:"inviteSomeone", descKey:"inviteDesc"});
        $("share").hidden = !!contact; $("invite").value = result.invite || "";
        void poll(epoch);
    }
    function review() {
        const code = $("code").value.trim();
        if (!code.startsWith("longvox-call:1:") || code.length > 4096) throw Error(t("pasteInvite"));
        let fields;
        try { fields = JSON.parse(atob(code.split(":")[2].replace(/-/g,"+").replace(/_/g,"/"))); }
        catch { throw Error(t("pasteInvite")); }
        if (!["audio","video"].includes(fields?.mode)) throw Error(t("unknownCallType"));
        if ((fields.groupSize !== undefined && (fields.groupSize !== 3 || fields.mode !== "audio" || fields.group !== undefined)) ||
            (fields.group !== undefined && (fields.group !== 4 || fields.mode !== "video"))) throw Error(t("unsupportedGroupInvite"));
        fresh(); role = "guest"; mode = fields.mode; groupConsent = fields.groupSize ?? fields.group;
        if (groupConsent === 3) {
            waitView("", "", true, {titleKey:"joinThreeTitle", descKey:"joinThreeDesc"});
            return;
        }
        if (groupConsent === 4) {
            waitView("", "", true, {titleKey:"joinGroupTitle", descKey:"joinGroupDesc"});
            return;
        }
        waitView("", "", true, {
            titleKey:mode === "video" ? "joinVideoTitle" : "joinAudioTitle",
            descKey:mode === "video" ? "joinVideoDesc" : "joinAudioDesc"
        });
    }
    async function accept() {
        const run = epoch;
        if (ending || !role) return;
        $("accept").disabled = true;
        lobbyPreview.stop();
        try {
            if (!await media(run)) return;
            if (role === "guest") {
                admission = api("join", {invite:$("code").value.trim(),name:$("name").value, groupConsent});
                const result = await admission;
                trace("signal", {state:"joined"});
                sessionActive = true;
                if (ending || epoch !== run) return;
                other = result.name;
                if (result.mode !== mode) throw Error(t("callTypeChanged"));
                waitView("", "", false, {titleKey:"callingName", titleVars:{name:other}, descKey:"waitingHostAnswer"});
                void poll(epoch);
            } else {
                await signal("accept");
                if (ending || epoch !== run || !await makePeer()) return;
                inCall(); await negotiate(false);
            }
        } catch (error) {
            if (!ending && epoch === run) throw error;
        } finally { if (!ending && epoch === run) $("accept").disabled = false; }
    }
    function inCall() {
        show("meeting"); $("peer").textContent = other || t("longvoxCall");
        $("meeting").dataset.group = String(Boolean(groupConsent));
        $("hangup").textContent = groupConsent ? t("leave") : t("endCall");
        $("audioBadge").textContent = t("audioCall"); $("audioBadge").hidden = mode !== "audio";
        $("camera").hidden = mode === "audio"; $("self").hidden = !liveTrack(local, "video") || isGroupGuest();
        updateMuteBadges();
        renderParticipants(true);
        clearInterval(groupRosterInterval);
        if (isGroupGuest()) {
            groupRosterInterval = setInterval(() => {
                if (!ending && isGroupGuest()) renderParticipants();
            }, 1500);
        }
        callQuality.start(() => pc, () => reconnectingNow || Boolean(grace) ||
            ["disconnected", "failed"].includes(pc?.connectionState) ||
            ["disconnected", "failed"].includes(pc?.iceConnectionState));
        statusKey("connecting");
        if (navigator.wakeLock && document.visibilityState === "visible") {
            const run = epoch;
            navigator.wakeLock.request("screen").then(w => {
                if (ending || epoch !== run) return w.release();
                wake = w;
            }).catch(() => {});
        }
    }
    let windowShare, groupWindows;
    function releasePeer() {
        groupWindows?.close(); groupWindows = null;
        windowShare?.close(); windowShare = null;
        if (!pc) return;
        pc.ontrack = pc.ondatachannel = pc.onconnectionstatechange = pc.oniceconnectionstatechange = null;
        if (control) { control.onopen = control.onmessage = null; control.close(); control = null; }
        pc.close(); pc = null;
        remote = new MediaStream(); $("remote").srcObject = remote; $("remoteAudio").srcObject = null;
    }
    function renderGuestRoster() {
        if (!lastRoster) return;
        const rows = [];
        for (const person of lastRoster) {
            const row = document.createElement("li"); row.className = "contact-row";
            const label = document.createElement("strong"); label.textContent = person.name + (person.host ? " · " + t("hostRole") : "");
            const text = document.createElement("span"); text.className = "seat-state";
            text.textContent = participantMedia(person, key => t(key));
            row.dataset.speaking = String(person.speaking);
            row.append(label, text);
            rows.push(row);
        }
        $("guestRoster").replaceChildren(...rows);
        $("guestPeople").hidden = false;
        $("meeting").dataset.roster = "true";
        $("participantsToggle").hidden = true;
        closeAllDrawers();
        syncWorkspaceDrawer();
    }
    function receiveRoster(data) {
        if (typeof data !== "string" || data.length > 8192 || data[0] !== "{") return false;
        let report;
        try { report = JSON.parse(data); } catch { return false; }
        if (report?.kind !== "roster" || !Array.isArray(report.people) || !report.people.length || report.people.length > 9) return false;
        for (const person of report.people) {
            if (!person || typeof person.name !== "string" || !person.name || [...person.name].length > 60
                || !["live", "muted", "lost", "unknown"].includes(person.mic) || typeof person.camera !== "boolean"
                || typeof person.host !== "boolean" || typeof person.speaking !== "boolean") return false;
        }
        lastRoster = report.people;
        renderGuestRoster();
        return true;
    }
    async function sampleAudio(peer) {
        const delta = (value, previous) => Number.isFinite(value) && Number.isFinite(previous) && value >= previous
            ? value - previous : undefined;
        let previous = {};
        for (let i = 0; i <= 10 && !ending && pc === peer; ++i) {
            const stats = {};
            try {
                for (const row of (await peer.getStats()).values()) {
                    if ((row.kind ?? row.mediaType) !== "audio") continue;
                    if (row.type === "media-source") { stats.level = row.audioLevel; stats.txEnergy = row.totalAudioEnergy; }
                    if (row.type === "outbound-rtp") stats.txPackets = row.packetsSent;
                    if (row.type === "inbound-rtp") { stats.rxEnergy = row.totalAudioEnergy; stats.rxPackets = row.packetsReceived; }
                }
            } catch { /* Missing counters remain unavailable. */ }
            if (ending || pc !== peer) break;
            if (i > 0) {
                trace("tx_audio", {level:stats.level, energy:delta(stats.txEnergy, previous.txEnergy), packets:delta(stats.txPackets, previous.txPackets)});
                trace("rx_audio", {energy:delta(stats.rxEnergy, previous.rxEnergy), packets:delta(stats.rxPackets, previous.rxPackets)});
            }
            previous = stats;
            if (i < 10) await sleep(1000);
        }
    }
    async function makePeer() {
        const run = epoch;
        const {servers} = await api("ice");
        if (ending || epoch !== run) return false;
        pc = new RTCPeerConnection({iceServers:servers, bundlePolicy:"max-bundle"});
        for (const kind of (mode === "video" ? ["audio", "video"] : ["audio"])) {
            const track = local.getTracks().find(t => t.kind === kind);
            if (track) pc.addTrack(track, local);
            else if (role === "host") pc.addTransceiver(kind, {direction:"sendrecv", streams:[local]});
        }
        if (role === "guest" && groupConsent === 4) {
            groupWindows = new GroupWindowGuest(pc, $("privateWindowShare"), api);
        }
        if (mode === "video") windowShare = new CallWindowShare(pc, $("privateWindowShare"), other || t("theParticipant"), api);
        $("remote").srcObject = remote;
        const attachControl = channel => {
            if (channel.label !== "longvox-call") { channel.close(); return; }
            control = channel;
            channel.onopen = () => { reportCamera(); reportMicrophone(); };
            if (channel.readyState === "open") channel.onopen();
            channel.onmessage = ({data}) => {
                if (ending || channel !== control) return;
                if (data === "removed-v1") void end(groupConsent ? t("hostRemovedYou") : t("callEnded"), false, true);
                if (data === "leave") void end(groupConsent ? t("hostEndedMeeting") : t("callEnded"), false, true);
                if (data === "fault") void end(groupConsent ? t("hostRecordingFault") : t("peerStoppedRecording"), false, false);
                if (groupConsent) { receiveRoster(data); return; }
                if (data === "mic-ready" || data === "mic-muted" || data === "mic-lost") {
                    const lost = data === "mic-lost";
                    peerMicMuted = data === "mic-muted";
                    if (peerMicLost !== lost) markConnection(!lost, "guest_microphone");
                    peerMicLost = lost;
                    const peerName = other || t("otherParticipant");
                    $("peerMicNote").textContent = lost ? t("peerMicDisconnected", {name:peerName}) : t("peerMicMuted", {name:peerName});
                    $("peerMicNote").hidden = data === "mic-ready";
                    updateMuteBadges();
                }
                if (mode === "video" && (data === "camera-on" || data === "camera-off")) {
                    const off = data === "camera-off";
                    $("remote").dataset.cameraOff = String(off);
                    $("audioBadge").textContent = t("peerCameraOff", {name:other || t("otherParticipant")});
                    $("audioBadge").hidden = !off;
                    renderParticipants();
                }
            };
        };
        if (role === "host") attachControl(pc.createDataChannel("longvox-call"));
        else pc.ondatachannel = e => attachControl(e.channel);
        pc.ontrack = e => {
            trace("remote_track", {kind:e.track.kind, muted:e.track.muted});
            if (!remote.getTrackById(e.track.id)) remote.addTrack(e.track);
            if (capture && e.track.kind === "audio") capture.setRemote(remote);
            if (e.track.kind === "audio") {
                $("remoteAudio").srcObject = new MediaStream([e.track]);
                void playRemoteAudio();
                void outputChoices();
            }
            $("remote").play().catch(() => {});
            e.track.onunmute = () => { $("remote").play().catch(() => {}); void playRemoteAudio(); void maybeRecord(); };
            void maybeRecord();
        };
        const peer = pc;
        let sampled = false, iceState;
        function connectionChanged() {
            if (ending || peer !== pc) return;
            if (iceState !== peer.iceConnectionState) {
                iceState = peer.iceConnectionState;
                trace("ice", {state:iceState});
            }
            if (connected(peer)) {
                if (apple && !sampled) { sampled = true; void sampleAudio(peer); }
                const ice = peer.getSenders().find(s => s.transport)?.transport.iceTransport;
                const pair = ice?.getSelectedCandidatePair?.();
                usingRelay = pair?.local?.type === "relay" || pair?.remote?.type === "relay";
                mediaRestored();
            } else {
                for (const state of ["failed", "disconnected"]) {
                    if (peer.iceConnectionState === state) { reconnectCall("ice_" + state); break; }
                    if (peer.connectionState === state) { reconnectCall("peer_" + state); break; }
                }
            }
        }
        pc.onconnectionstatechange = pc.oniceconnectionstatechange = connectionChanged;
        return true;
    }
    function connected(peer) {
        return ["connected", "completed"].includes(peer.iceConnectionState) && peer.connectionState === "connected";
    }
    function mediaRestored() {
        if (grace) markConnection(true);
        clearTimeout(reconnect); clearTimeout(grace); reconnect = grace = null;
        reconnectingNow = false;
        callTimer.start();
        callQuality.refreshNow();
        statusKey("connected"); void maybeRecord();
    }
    async function confirmRestart(peer, version) {
        // A successful in-place ICE restart can keep the connection state "connected"
        // throughout. Confirm incoming media before clearing the recovery timer.
        async function received() {
            let packets = 0;
            (await peer.getStats()).forEach(r => { if (r.type === "inbound-rtp") packets += r.packetsReceived || 0; });
            return packets;
        }
        try {
            const before = await received();
            await sleep(650);
            if (!ending && peer === pc && generation === version && connected(peer)) {
                const after = await received();
                if (!ending && peer === pc && generation === version && connected(peer) && after > before) mediaRestored();
            }
        } catch { /* The next recovery attempt can still replace the peer. */ }
    }
    function markConnection(receiving, source = "connection", reason) {
        if (role === "host" && capture?.begun)
            linkMarks = linkMarks.then(() => api("connection", {receiving, source, reason})).catch(() => {});
    }
    function reconnectCall(reason = "connection", replacePeer = false) {
        if (ending || !pc || grace) return;
        const run = epoch;
        reconnectingNow = true;
        callQuality.refreshNow();
        let tryIceRestart = peerCanRestartIce && !usingRelay && !replacePeer && !reason.endsWith("_track");
        markConnection(false, "connection", reason);
        statusKey("connectionInterrupted");
        const outage = grace = setTimeout(() => {
            void end(groupConsent ? t("groupConnectionLost") : t("connectionLost"), false, false);
        }, 45000);
        async function attempt() {
            if (ending || run !== epoch || grace !== outage) return;
            let retryAfter = 10000;
            try {
                if (role === "host") {
                    generation++;
                    const keepPeer = tryIceRestart && pc?.signalingState === "stable";
                    tryIceRestart = false;
                    if (!keepPeer) {
                        releasePeer();
                        await makePeer();
                    } else retryAfter = 3000;
                    if (run === epoch && !ending && grace === outage) await negotiate(true, keepPeer);
                } else await signal("restart", {generation, replacePeer:reason.endsWith("_track")});
            } catch (e) { if (!ending && run === epoch && grace === outage) status(t("reconnectingErr", {msg:e.message})); }
            if (!ending && run === epoch && grace === outage) reconnect = setTimeout(attempt, retryAfter);
        }
        // A brief Wi-Fi interruption can clear on the current candidate pair.
        reconnect = setTimeout(attempt, reason.endsWith("_disconnected") ? 3000 : 0);
    }
    async function gathered(peer) {
        if (peer.iceGatheringState === "complete") return;
        await new Promise(resolve => {
            const done = () => { clearTimeout(timer); peer.removeEventListener("icegatheringstatechange", changed); resolve(); };
            const changed = () => { if (peer.iceGatheringState === "complete") done(); };
            const timer = setTimeout(done, 4500);
            peer.addEventListener("icegatheringstatechange", changed); changed();
        });
    }
    async function negotiate(renewal, keepPeer = false) {
        const peer = pc;
        if (!peer || peer.signalingState !== "stable") return;
        await peer.setLocalDescription(await peer.createOffer(keepPeer ? {iceRestart:true} : {})); await gathered(peer);
        if (peer === pc && !ending) await signal("offer",{sdp:peer.localDescription.sdp, renewal, keepPeer, generation});
    }
    async function maybeRecord() {
        if (role !== "host" || ending || startingCapture || !pc || pc.connectionState !== "connected"
            || !remote.getAudioTracks().length) return;
        const run = epoch;
        capture = new MeetingCapture(context, post, e => { if (!ending && epoch === run) void end(e.message, true, false); });
        startingCapture = capture.start(local, remote, mode === "video", mime => api("begin", {mime, participant_tracks: true}));
        try {
            await startingCapture;
            if (ending || epoch !== run) return;
            if (!local.getAudioTracks().length) markConnection(false, "host_microphone");
            if (peerMicLost) markConnection(false, "guest_microphone");
            $("record").hidden = false; await signal("recording");
        } catch (e) { if (!ending && epoch === run) void end(t("recordingStopped", {msg:e.message}), true, false); }
    }
    async function receive(e) {
        if (["accept", "offer", "answer"].includes(e.kind)) trace("signal", {state:e.kind});
        switch (e.kind) {
            case "request":
                other = e.name; $("share").hidden = true;
                if (namedHost) {
                    waitView("", "", false, {titleKey:"connectingTo", titleVars:{name:other}, descKey:"recordedOnWindows"});
                    try { await accept(); } catch (error) { await end(error.message, true, false); }
                    break;
                }
                waitView("", "", true, {titleKey:"nameIsCalling", titleVars:{name:other}, descKey:mode === "video" ? "answerVideoDesc" : "answerAudioDesc"}); break;
            case "accept": if (await makePeer()) inCall(); break;
            case "offer": {
                if (e.renewal) {
                    if (e.generation < generation) break;
                    reconnectingNow = true;
                    callQuality.refreshNow();
                    generation = e.generation;
                    if (!e.keepPeer || !pc) {
                        releasePeer();
                        if (!await makePeer()) return;
                    }
                    status(t("reconnecting"));
                }
                const peer = pc;
                await peer.setRemoteDescription({type:"offer",sdp:e.sdp});
                for (const transceiver of peer.getTransceivers()) {
                    const kind = transceiver.receiver.track.kind;
                    if (kind === "audio" || (kind === "video" && mode === "video")) transceiver.direction = "sendrecv";
                }
                await peer.setLocalDescription(await peer.createAnswer()); await gathered(peer);
                if (!ending && peer === pc) {
                    if (e.keepPeer) void confirmRestart(peer, generation);
                    await signal("answer",{sdp:peer.localDescription.sdp, generation, canRestartIce:true});
                }
                break;
            }
            case "restart":
                if (role === "host" && e.generation === generation) reconnectCall("remote_restart", e.replacePeer === true);
                break;
            case "answer": {
                const peer = pc, version = generation;
                if (peer?.signalingState !== "have-local-offer" || (e.generation !== undefined && e.generation !== version)) break;
                await peer.setRemoteDescription({type:"answer",sdp:e.sdp});
                if (ending || peer !== pc || generation !== version) break;
                peerCanRestartIce = e.canRestartIce === true;
                if (grace && version > 0) void confirmRestart(peer, version);
                break;
            }
            case "recording": $("record").hidden = false; break;
            case "expired": {
                let message = t("inviteExpired");
                if (namedHost) {
                    if (lastDelivery === "received") message = namedHost + " did not answer. Try again.";
                    else message = "Could not reach " + namedHost + ". Open Longvox there, then call again.";
                }
                await end(message, false, false); break;
            }
            case "no_answer": await end(t("noAnswer"), false, false); break;
            case "decline": await end(t("callDeclined"), false, false); break;
            case "leave": await end(e.removed === true && groupConsent ? t("hostRemovedYou") : groupConsent ? t("hostEndedMeeting") : t("callEnded"), false, true); break;
            case "fault": await end(groupConsent ? t("hostRecordingFault") : t("peerRecordingFault"), false, false); break;
        }
    }
    async function poll(run) {
        polling = run;
        let failedSince = 0;
        while (polling === run && epoch === run && !ending) {
            try {
                const {events, delivery, push} = await api("poll",{after:cursor});
                if (epoch !== run || ending) break;
                if (namedHost && delivery) lastDelivery = delivery;
                if (delivery && namedHost && !other && !pc && !events.length) {
                    let detail = "Waiting for " + namedHost + " to open Longvox.";
                    if (delivery === "received") detail = "Ringing…";
                    else if (delivery === "sent" || push === "submitted") detail = "Waiting for an answer…";
                    else if (push === "pending") detail = "Calling " + namedHost + "…";
                    else if (push === "not_registered" || push === "unregistered")
                        detail = "Could not ring " + namedHost + ". Open Longvox there within one minute.";
                    else if (push === "failed" || push === "unavailable" || push === "unconfigured")
                        detail = "Windows could not send a call alert. Open Longvox on " + namedHost + " within one minute.";
                    $("waitingText").textContent = detail;
                }
                for (const e of events) { await receive(e); cursor++; if (ending || epoch !== run) break; }
                if (failedSince && !ending && !grace && pc?.connectionState === "connected") statusKey("connected");
                failedSince = 0;
            } catch (e) {
                if (ending || epoch !== run) break;
                if (!failedSince) failedSince = Date.now();
                if (!grace) {
                    if (pc && connected(pc)) statusKey("keepTalkingReconnecting");
                    else if (Date.now() - failedSince > 30000) { await end(t("lostContact"), false, false); break; }
                    else status(t("tryingToReach"));
                }
            }
            await sleep(500);
        }
    }
    async function end(text, notify, complete) {
        if (ending) return;
        ending = true; epoch++; polling = 0; clearTimeout(reconnect); clearTimeout(grace); reconnect = grace = null;
        lobbyPreview.stop(); callTimer.stop(); callQuality.stop();
        closeAllDrawers();
        resetParticipants();
        reconnectingNow = false;
        setCallActionsDisabled(true);
        let saved = false;
        for (const t of local?.getTracks() || []) { t.onended = null; t.stop(); }
        if (admission) await admission.catch(() => {});
        const kind = role === "host" && !pc ? "decline" : (pc && !complete ? "fault" : "leave");
        if (notify && control?.readyState === "open") {
            try { control.send(kind); } catch { /* Signalling also carries the end event. */ }
        }
        if (namedGuest && notify && !sessionActive) await api("contact_decline").catch(() => {});
        namedGuest = false;
        const announced = notify && sessionActive && (other || role === "guest")
            ? signal(kind).catch(() => {}) : Promise.resolve();
        try {
            if (startingCapture) await startingCapture.catch(() => {});
            if (capture) {
                status(t("savingRecording")); await capture.stop(); await linkMarks;
                if (capture.begun) { await api("finish",{complete:complete && !capture.failure}); saved = true; }
            }
        } catch (e) { text = t("recordingInterrupted", {msg:e.message}); }
        finally {
            await announced;
            releasePeer();
            if (context && context.state !== "closed") await context.close().catch(() => {});
            if (wake) await wake.release().catch(() => {});
            $("remoteAudio").srcObject = $("remote").srcObject = $("self").srcObject = null;
            local = pc = context = capture = startingCapture = control = wake = null;
            // Give a guest polling the host time to receive the final event.
            if (sessionActive && role === "host" && other && (notify || !complete)) await sleep(1200);
            if (sessionActive) await api("reset").catch(() => {});
            else if (callKitAudio !== null) trace("call_end");
            sessionActive = false; admission = undefined; $("record").hidden = true;
            $("invite").value = ""; $("code").value = ""; show(nativeLaunch ? "finished" : "lobby");
            if (text === t("callEnded") && !saved) statusKey("callEnded");
            else if (text === t("youLeftMeeting") && !saved) statusKey("youLeftMeeting");
            else if (text === t("hostEndedMeeting") && !saved) statusKey("hostEndedMeeting");
            else if (text === t("hostRemovedYou") && !saved) statusKey("hostRemovedYou");
            else if (text === t("callDeclined") && !saved) statusKey("callDeclined");
            else if (text === t("callCancelled") && !saved) statusKey("callCancelled");
            else status(text + (saved ? t("savedInMeetings") : ""));
        }
    }
    function bind(id, action) {
        const isCallAction = callActionButtons.has(id);
        $(id).onclick = async () => {
            const button = $(id);
            if (isCallAction && ending) return;
            const run = epoch;
            button.disabled = true;
            try { await action(); }
            catch (e) {
                if (!isCallAction || (!ending && epoch === run)) {
                    await end(e.message, true, false);
                    status(e.message);
                }
            } finally {
                if (!isCallAction || (!ending && epoch === run)) {
                    button.disabled = id === "switchCamera" && !local?.getVideoTracks().length;
                }
            }
        };
    }
    // A targeted offer uses the same admission and recording controls as an invitation.
    let contactState = "", nearbyState = "", refreshingContacts = false, namedGuest = false;
    async function refreshContacts(open = false) {
        if (refreshingContacts || (!open && ($("contactBook").hidden || $("lobby").hidden))) return;
        refreshingContacts = true;
        try {
            const book = await api(open ? "contacts_open" : "contacts_list", {address:$("route").value});
            $("openContacts").hidden = true; $("contactBook").hidden = false;
            if (!book.linkActive) { $("contactLink").value = ""; $("contactInvite").hidden = true; }
            $("nearbyVisible").checked = !!book.visible;
            const nearby = book.nearby || [];
            if (JSON.stringify(nearby) !== nearbyState) {
                nearbyState = JSON.stringify(nearby);
                $("nearbyBook").hidden = !nearby.length;
                $("nearbyList").replaceChildren();
                for (const device of nearby) {
                    const row = document.createElement("div"); row.className = "contact-row";
                    const title = document.createElement("strong"); title.textContent = device.name;
                    row.append(title);
                    const help = document.createElement("p");
                    help.textContent = device.asked ? t("confirmCode", {code:device.code}) :
                        t("visibleNearby");
                    row.append(help);
                    if (device.asked) {
                        const approve = document.createElement("button");
                        approve.textContent = t("numbersMatchAllow");
                        approve.onclick = async () => {
                            approve.disabled = true;
                            try { await api("contacts_approve", {id:device.id, ref:device.ref}); await refreshContacts(); }
                            catch (error) { status(error.message); approve.disabled = false; }
                        };
                        const ignore = document.createElement("button");
                        ignore.className = "quiet"; ignore.textContent = t("ignore");
                        ignore.onclick = async () => {
                            try { await api("contacts_ignore", {id:device.id, ref:device.ref}); await refreshContacts(); }
                            catch (error) { status(error.message); }
                        };
                        row.append(approve,ignore);
                    }
                    $("nearbyList").append(row);
                }
            }
            const state = JSON.stringify({currentLang, contacts:book.contacts});
            if (state === contactState) return;
            contactState = state;
            const list = $("contactList"); list.replaceChildren();
            if (!book.contacts.length) list.textContent = t("noSavedContacts");
            for (const person of book.contacts) {
                const row = document.createElement("div"); row.className = "contact-row";
                const title = document.createElement("strong");
                title.textContent = person.name + (person.request ? t("contactCalling") : person.online ? t("contactActive") : t("contactWaiting"));
                const buttons = document.createElement("div"); buttons.className = "buttons";
                const button = (label, action, enabled = true) => {
                    const b = document.createElement("button"); b.textContent = label; b.disabled = !enabled; buttons.append(b);
                    b.onclick = async () => { b.disabled = true; try { await action(); }
                        catch(e) { status(e.message); } finally { b.disabled = false; } };
                };
                if (person.request) {
                    button(t("answerRequest", {kind:person.request}), () => host(person.request, person));
                    button(t("dismiss"), async () => { await api("contacts_dismiss", {id:person.id, ...(person.requestRef ? {requestRef:person.requestRef} : {})}); await refreshContacts(); });
                } else {
                    button(t("audioCall"), () => host("audio", {...person, waitingForApp:!person.online}));
                    button(t("videoCall"), () => host("video", {...person, waitingForApp:!person.online}));
                }
                button(t("remove"), async () => {
                    if (confirm(t("removeConfirm", {name:person.name}))) {
                        await api("contacts_forget", {id:person.id}); await refreshContacts();
                    }
                });
                row.append(title,buttons); list.append(row);
            }
        } finally { refreshingContacts = false; }
    }
    $("openContacts").onclick = () => refreshContacts(true).catch(e => status(e.message));
    $("route").onchange = () => { if (!$("contactBook").hidden) refreshContacts(true).catch(e => status(e.message)); };
    $("nearbyVisible").onchange = async () => {
        try { await api("contacts_visibility", {visible:$("nearbyVisible").checked}); }
        catch (error) { status(error.message); }
        await refreshContacts();
    };
    $("inviteContact").onclick = async () => {
        try {
            const {link,matrix} = await api("contacts_link", {name:$("name").value.trim(), address:$("route").value});
            const qr = $("contactQR"), scale = 6;
            qr.width = qr.height = matrix.length * scale;
            const ctx = qr.getContext("2d"); ctx.fillStyle="#fff"; ctx.fillRect(0,0,qr.width,qr.height);
            ctx.fillStyle="#000"; matrix.forEach((row,y) => [...row].forEach((v,x) => {
                if(v==="1") ctx.fillRect(x*scale,y*scale,scale,scale);
            }));
            $("pairCode").hidden = true;
            $("contactLink").value = link;
            $("contactInvite").hidden = false;
            try { await navigator.clipboard.writeText(link); status(t("contactLinkCopied")); }
            catch { $("contactLink").select(); status(t("copySelectedContactLink")); }
        } catch (error) { status(error.message); }
    };
    $("copyContactLink").onclick = () => navigator.clipboard.writeText($("contactLink").value)
        .then(() => status(t("contactLinkCopied"))).catch(() => $("contactLink").select());
    $("revokeContactLink").onclick = async () => {
        try { await api("contacts_revoke_link"); $("contactLink").value = ""; $("contactInvite").hidden = true; }
        catch (error) { status(error.message); }
    };
    $("pairPhone").onclick = () => { $("pairCode").hidden = !$("pairCode").hidden; };
    setInterval(() => { if (!$("contacts").hidden) refreshContacts().catch(e => status(e.message)); }, 2500);
    window.longvoxReviewContactCall = async (invite,name,answered = false) => {
        if (sessionActive || admission || !$("waiting").hidden) return;
        namedGuest = true;
        $("code").value=invite; $("name").value=name; review();
        if (answered === true && groupConsent !== 3) {
            waitView("", "", false, {titleKey:"connectingShort", descKey:"recordedOnWindows"});
            try { await accept(); } catch (error) { await end(error.message, true, false); }
        }
    };
    const memberStrings = {
        en: {
            ringing:"Calling…", delivered:"Call delivered. Waiting for answer…", offerSent:"Call sent. Waiting for confirmation…",
            alertSent:"Alert sent. Waiting for answer…",
            noWake:"Could not wake this device. Waiting for Longvox to open…",
            unreachable:"Could not reach the device. No answer.", connecting:"Answered. Connecting…", answering:"Answering…",
            connected:"Connected", reconnecting:"Reconnecting…", declined:"Call declined.", expired:"No answer.",
            cancelled:"Call cancelled.", ended:"Call ended.", elsewhere:"The call has already been answered.",
            failed:"The two devices could not reach each other directly on this network.",
            mediaFailed:"Could not start the microphone or camera. Check permissions in Settings.",
            closeFailed:"Could not end the call. Try again.",
            cancel:"Cancel", hangup:"End call", mute:"Mute", unmute:"Unmute",
            cameraOff:"Turn camera off", cameraOn:"Turn camera on", sound:"Enable speaker audio",
            youMuted:"You are muted", muted:"Muted",
            qualityConnecting:"Connecting…", qualityGood:"Good connection", qualityFair:"Fair connection",
            qualityPoor:"Poor connection", qualityReconnecting:"Reconnecting…", msUnit:"ms", lossLabel:"loss"
        },
        ru: {
            ringing:"Вызов…", delivered:"Вызов доставлен. Ожидание ответа…",
            offerSent:"Вызов отправлен. Ожидание подтверждения…", alertSent:"Оповещение отправлено. Ожидание ответа…",
            noWake:"Не удалось разбудить устройство. Ожидание запуска Longvox…",
            unreachable:"Не удалось связаться с устройством. Нет ответа.", connecting:"Ответ получен. Подключение…", answering:"Ответ на вызов…",
            connected:"Подключено", reconnecting:"Восстановление связи…", declined:"Вызов отклонён.", expired:"Нет ответа.",
            cancelled:"Вызов отменён.", ended:"Вызов завершён.", elsewhere:"На вызов уже ответили.",
            failed:"Устройства не смогли связаться напрямую через эту сеть.",
            mediaFailed:"Не удалось включить микрофон или камеру. Проверьте разрешения в настройках.",
            closeFailed:"Не удалось завершить вызов. Повторите попытку.",
            cancel:"Отмена", hangup:"Завершить вызов", mute:"Выключить микрофон", unmute:"Включить микрофон",
            cameraOff:"Выключить камеру", cameraOn:"Включить камеру", sound:"Включить звук",
            youMuted:"Микрофон выключен", muted:"Без звука",
            qualityConnecting:"Подключение…", qualityGood:"Хорошая связь", qualityFair:"Средняя связь",
            qualityPoor:"Слабая связь", qualityReconnecting:"Восстановление связи…", msUnit:"мс", lossLabel:"потерь"
        }
    };
    const memberTerminal = {decline:"declined", expired:"expired", leave:"ended", fault:"failed"};
    const memberConnectTimeout = 18000;

    function privateAddress(address, candidate) {
        if (candidate && /^[a-z0-9-]{1,63}\.local\.?$/i.test(address)) return true;
        if (address.includes(":")) {
            try {
                const canonical = new URL("https://[" + address + "]/").hostname.slice(1, -1);
                return canonical === "::1" || (!candidate && canonical === "::") ||
                    /^(?:f[cd][0-9a-f]{2}|fe[89ab][0-9a-f]):/i.test(canonical);
            } catch { return false; }
        }
        const parts = address.split(".");
        if (parts.length !== 4 || !parts.every(part => /^(0|[1-9][0-9]{0,2})$/.test(part) && Number(part) <= 255)) return false;
        const [a, b] = parts.map(Number);
        return a === 10 || a === 127 || (a === 192 && b === 168) ||
            (a === 172 && b >= 16 && b <= 31) || (a === 100 && b >= 64 && b <= 127) ||
            (!candidate && address === "0.0.0.0");
    }
    function memberSDP(sdp) {
        return sdp.trimEnd().split(/\r?\n/).flatMap(line => {
            if (/^a=remote-candidates:/i.test(line)) return [];
            if (/^a=candidate:/i.test(line)) {
                const fields = line.trim().split(/\s+/);
                const extras = fields.slice(8).filter((_, index) => index % 2 === 0);
                return fields.length >= 8 && fields.length % 2 === 0 && /^udp$/i.test(fields[2]) &&
                    /^typ$/i.test(fields[6]) && /^host$/i.test(fields[7]) &&
                    privateAddress(fields[4], true) && /^[0-9]{1,5}$/.test(fields[5]) &&
                    Number(fields[5]) > 0 && Number(fields[5]) <= 65535 &&
                    !extras.some(key => /^(raddr|rport|typ)$/i.test(key)) ? [line] : [];
            }
            if (/^(o=|c=|a=rtcp:)/i.test(line)) {
                return [line.replace(/(\bIN IP([46])\s+)(\S+)$/i, (whole, prefix, family, address) =>
                    privateAddress(address, false) ? whole : prefix + (family === "4" ? "0.0.0.0" : "::"))];
            }
            return [line];
        }).join("\r\n") + "\r\n";
    }
    async function memberRPC(op, fields, attempts = 1) {
        for (let i = 1; ; i++) {
            let reply;
            try { reply = await api(op, fields); }
            catch (error) { if (i === attempts) throw error; else continue; }
            if (reply.memberError) throw Object.assign(Error(reply.memberError), {code:reply.memberError});
            return reply;
        }
    }
    async function gatheredMemberSDP(peer, description) {
        await peer.setLocalDescription(description);
        if (peer.iceGatheringState !== "complete") {
            await new Promise((resolve, reject) => {
                const finish = () => {
                    clearTimeout(timer);
                    peer.removeEventListener("icegatheringstatechange", check);
                };
                const check = () => { if (peer.iceGatheringState === "complete") { finish(); resolve(); } };
                const timer = setTimeout(() => { finish(); reject(Error("ICE gathering timed out")); }, 6000);
                peer.addEventListener("icegatheringstatechange", check);
                check();
            });
        }
        return memberSDP(peer.localDescription.sdp);
    }

    let memberCall;
    class MemberCall {
        constructor({invite, role, name, mode, language, push}) {
            this.caller = role === "caller";
            this.video = mode === "video";
            this.text = memberStrings[language] || memberStrings.en;
            this.seq = this.cursor = 0;
            this.generation = this.answeredGeneration = -1;
            this.sending = Promise.resolve();
            $("memberPeer").textContent = name;
            if ($("memberRemoteName")) $("memberRemoteName").textContent = name;
            if ($("memberSelfName")) $("memberSelfName").textContent = language === "ru" ? "Вы" : "You";
            $("memberCall").lang = language === "ru" ? "ru" : "en";
            $("memberCancel").textContent = this.text.cancel;
            $("memberCancel").hidden = !this.caller;
            $("memberCancel").onclick = () => { void this.close(); };
            $("memberHangup").textContent = this.text.hangup;
            $("memberHangup").onclick = () => { void this.finish("ended", "leave"); };
            $("memberSound").textContent = this.text.sound;
            $("memberSound").onclick = () => { void this.play(); };
            $("memberMute").onclick = () => this.toggle("audio");
            $("memberCamera").onclick = () => this.toggle("video");
            $("memberSelfMutedBadge").textContent = this.text.youMuted;
            $("memberSelfMuteTag").textContent = this.text.muted;
            this.timer = makeTimer($("memberTimer"));
            this.quality = makeQualityMonitor($("memberQualityBadge"), $("memberQualityText"), $("memberQualityDetail"), () => ({
                connecting:this.text.qualityConnecting, good:this.text.qualityGood, fair:this.text.qualityFair,
                poor:this.text.qualityPoor, reconnecting:this.text.qualityReconnecting,
                msUnit:this.text.msUnit, lossLabel:this.text.lossLabel
            }));
            this.timer.stop(); this.quality.stop();
            $("memberSelfMutedBadge").hidden = $("memberSelfMuteTag").hidden = true;
            $("memberMute").classList.remove("is-muted");
            $("record").hidden = true;
            status("");
            show("memberCall");
            this.publish(this.caller ? this.ringState(push) : "answering");
            this.join = memberRPC("join", {invite, role});
            void this.run();
        }
        publish(state) {
            if (this.state === state) return;
            this.state = state;
            const text = this.text[state];
            $("memberStatus").textContent = text;
            void api("member_status", {text}).catch(() => {});
        }
        ringState(push, delivery) {
            if (delivery === "received") return "delivered";
            if (delivery === "sent") return "offerSent";
            if (push === "submitted") return "alertSent";
            if (["not_registered", "unconfigured", "unavailable", "unregistered", "failed"].includes(push)) return "noWake";
            return "ringing";
        }
        async run() {
            try {
                await this.join;
            } catch (error) {
                if (this.ended) return;
                if (error.code === "answered_elsewhere") return this.finish("elsewhere");
                if (error.code === "ended") return this.finish("ended");
                return this.finish("failed", "close");
            }
            let failedAt;
            while (!this.ended) {
                let result;
                try {
                    result = await memberRPC("poll", {after:this.cursor});
                    failedAt = undefined;
                } catch (error) {
                    if (this.ended) return;
                    if (error.code === "ended") return this.finish("ended");
                    failedAt ??= Date.now();
                    if (Date.now() - failedAt >= memberConnectTimeout) return this.finish("failed", "fault");
                    await sleep(450);
                    continue;
                }
                if (this.ended) return;
                if (this.caller && result.state === "ringing") this.publish(this.ringState(result.push, result.delivery));
                for (const event of result.events) {
                    if (this.ended) return;
                    if (Object.hasOwn(memberTerminal, event.kind)) {
                        this.cursor++;
                        if (event.kind === "expired" && this.ringState(result.push, result.delivery) === "noWake") {
                            return this.finish("unreachable");
                        }
                        return this.finish(event.kind === "leave" && result.delivery !== "answered"
                            ? "cancelled" : memberTerminal[event.kind]);
                    }
                    // Drain terminal queues without starting media for older events.
                    if (result.state !== "ended") this.receive(event);
                    this.cursor++;
                }
                if (result.state === "ended") return this.finish("ended");
                await sleep(result.events.length === 4 ? 0 : 450);
            }
        }
        receive(event) {
            // Polling stays responsive to terminal events while media permissions and ICE are pending.
            this.receiving = (this.receiving || Promise.resolve()).then(async () => {
                if (this.ended) return;
                if (event.kind === "accept") await this.accept();
                else if (event.kind === "offer" && !this.caller) await this.answer(event);
                else if (event.kind === "answer" && this.caller && (event.generation ?? this.generation) === this.generation) {
                    await this.peer.setRemoteDescription({type:"answer", sdp:memberSDP(event.sdp)});
                    this.peerCanRestart = event.canRestartIce !== false;
                    this.answeredGeneration = this.generation;
                    this.connectionChanged();
                } else if (this.caller && event.kind === "restart" && (event.generation ?? this.generation) === this.generation) {
                    await this.restart(event.replacePeer === true);
                }
            }).catch(() => this.finish("failed", "fault"));
        }
        armDeadline() {
            if (!this.deadline) this.deadline = setTimeout(() => { void this.finish("failed", "fault"); }, memberConnectTimeout);
        }
        async accept() {
            this.answered = true;
            this.publish("connecting");
            $("memberCancel").hidden = true;
            $("memberHangup").hidden = false;
            this.armDeadline();
            const ice = await memberRPC("ice", {}, 2);
            if (!Array.isArray(ice.servers) || ice.servers.length !== 0) throw Error("Invalid direct ICE configuration");
            if (this.ended) return;
            let stream;
            try { stream = await navigator.mediaDevices.getUserMedia({audio:audioQuality, video:this.video && videoQuality}); }
            catch { return this.finish("mediaFailed", "fault"); }
            if (this.ended) { stream.getTracks().forEach(track => track.stop()); return; }
            this.stream = stream;
            this.makeMemberPeer();
            if (this.video) {
                $("memberVideo").hidden = false;
                document.querySelector(".member-self").srcObject = stream;
                this.toggle("video", false);
            }
            this.toggle("audio", false);
            this.quality.start(() => this.peer, () => this.state === "reconnecting" ||
                ["disconnected", "failed"].includes(this.peer?.connectionState) ||
                ["disconnected", "failed"].includes(this.peer?.iceConnectionState));
            if (this.caller) await this.offer(false);
        }
        makeMemberPeer() {
            this.peer?.close();
            const peer = this.peer = new RTCPeerConnection({iceServers:[], bundlePolicy:"max-bundle"});
            peer.oniceconnectionstatechange = peer.onconnectionstatechange = () => {
                if (peer === this.peer) this.connectionChanged();
            };
            peer.ontrack = ({track}) => {
                if (this.ended || peer !== this.peer) return;
                const element = track.kind === "audio" ? $("memberAudio") : document.querySelector(".member-remote");
                element.srcObject = new MediaStream([track]);
                if (track.kind === "audio") {
                    track.onunmute = () => { void this.play(); };
                    void this.play();
                } else element.play().catch(() => {});
            };
            for (const track of this.stream.getTracks()) peer.addTrack(track, this.stream);
        }
        toggle(kind, flip = true) {
            const track = this.stream?.getTracks().find(track => track.kind === kind);
            if (!track) return;
            if (flip) track.enabled = !track.enabled;
            const button = $(kind === "audio" ? "memberMute" : "memberCamera");
            button.hidden = false;
            button.textContent = this.text[kind === "audio"
                ? (track.enabled ? "mute" : "unmute") : (track.enabled ? "cameraOff" : "cameraOn")];
            button.setAttribute("aria-pressed", String(!track.enabled));
            if (kind === "audio") {
                const muted = !track.enabled;
                button.classList.toggle("is-muted", muted);
                $("memberSelfMutedBadge").hidden = !muted;
                $("memberSelfMuteTag").hidden = !muted || $("memberVideo").hidden;
            } else {
                const selfVideo = document.querySelector(".member-self");
                if (selfVideo) selfVideo.hidden = !track.enabled;
            }
        }
        async play() {
            if (this.ended) return;
            try { await $("memberAudio").play(); $("memberSound").hidden = true; }
            catch { if (!this.ended) $("memberSound").hidden = false; }
        }
        async offer(restart, replace = false) {
            const generation = ++this.generation;
            if (replace) this.makeMemberPeer();
            const sdp = await gatheredMemberSDP(this.peer, await this.peer.createOffer({iceRestart:restart && !replace}));
            if (!this.ended) await this.send({kind:"offer", generation, sdp, renewal:restart, keepPeer:restart && !replace});
        }
        async answer({generation = this.generation + 1, sdp, renewal, keepPeer}) {
            if (!this.peer || generation !== this.generation + 1) throw Error("Unexpected direct offer");
            this.generation = generation;
            if (generation > 0) {
                this.publish("reconnecting");
                this.armDeadline();
                if (keepPeer === false || (renewal === true && keepPeer !== true)) this.makeMemberPeer();
            }
            await this.peer.setRemoteDescription({type:"offer", sdp:memberSDP(sdp)});
            const answer = await gatheredMemberSDP(this.peer, await this.peer.createAnswer());
            if (this.ended) return;
            await this.send({kind:"answer", generation, sdp:answer, canRestartIce:true});
            this.answeredGeneration = generation;
            this.connectionChanged();
        }
        connectionChanged() {
            if (this.ended || this.answeredGeneration !== this.generation || this.generation < 0) return;
            const {iceConnectionState, connectionState} = this.peer;
            if (["connected", "completed"].includes(iceConnectionState) && connectionState === "connected") {
                clearTimeout(this.deadline); this.deadline = undefined;
                clearTimeout(this.restartTimer); this.restartTimer = undefined;
                this.publish("connected");
                this.timer.start();
                this.quality.refreshNow();
            } else if (["disconnected", "failed"].some(state => [iceConnectionState, connectionState].includes(state))) {
                this.publish("reconnecting");
                this.quality.refreshNow();
                this.armDeadline();
                if (this.restartGeneration !== this.generation && !this.restartTimer) {
                    this.restartTimer = setTimeout(() => {
                        this.restartTimer = undefined;
                        void this.restart().catch(() => this.finish("failed", "fault"));
                    }, 1400);
                }
            }
        }
        async restart(replace = false) {
            if (this.ended || !this.peer || this.answeredGeneration !== this.generation ||
                this.generation < 0 || this.restartGeneration === this.generation) return;
            this.restartGeneration = this.generation;
            this.publish("reconnecting");
            this.armDeadline();
            if (this.caller) await this.offer(true, replace || this.peerCanRestart === false);
            else {
                try { await this.send({kind:"restart", generation:this.generation, replacePeer:replace}); }
                catch (error) {
                    // A caller restart can win before the hub receives this hint.
                    if (error.code !== "out_of_order") throw error;
                }
            }
        }
        send(message) {
            const pending = this.sending.then(async () => {
                if (this.ended && !["leave", "fault"].includes(message.kind)) return;
                await memberRPC("send", {seq:this.seq, message}, 2);
                this.seq++;
            });
            this.sending = pending.catch(() => {});
            return pending;
        }
        close() {
            return this.finish(undefined, "close");
        }
        finish(state, reason = "remote") {
            if (this.finishing) return this.finishing;
            this.ended = true;
            clearTimeout(this.deadline);
            clearTimeout(this.restartTimer);
            this.timer.stop();
            this.quality.stop();
            this.peer?.close();
            this.stream?.getTracks().forEach(track => track.stop());
            $("memberAudio").srcObject = document.querySelector(".member-remote").srcObject =
                document.querySelector(".member-self").srcObject = null;
            for (const id of ["memberCancel", "memberMute", "memberCamera", "memberSound", "memberHangup", "memberVideo", "memberSelfMutedBadge", "memberSelfMuteTag"]) $(id).hidden = true;
            return this.finishing = (async () => {
                await this.sending;
                try {
                    const result = await memberRPC("member_end", {reason, seq:this.seq, text:state ? this.text[state] : ""});
                    this.publish(state ?? (result.state === "cancelled" ? "cancelled" : "ended"));
                    return true;
                } catch {
                    this.finishing = undefined;
                    this.publish("closeFailed");
                    $("memberHangup").hidden = false;
                    $("memberHangup").onclick = () => { void this.finish(state, reason); };
                    return false;
                }
            })();
        }
    }
    window.longvoxSetLanguage = lang => {
        currentLang = resolveLang(lang);
        applyStaticTranslations();
        lobbyPreview.refreshLabels?.();
        if (lastStatus) $("status").textContent = t(lastStatus.key, lastStatus.vars);
        if (!$("waiting").hidden) {
            if (lastWait) {
                $("waitingTitle").textContent = t(lastWait.titleKey, lastWait.titleVars);
                $("waitingText").textContent = t(lastWait.descKey, lastWait.descVars);
            }
            $("accept").textContent = role === "guest" ? t("joinCall") : t("answerAndJoin");
        }
        if (local && !ending) {
            $("hangup").textContent = groupConsent ? t("leave") : t("endCall");
            microphoneControls($("micNote").textContent);
            renderCameraControls($("cameraNote").textContent);
            if (peerMicLost) $("peerMicNote").textContent = t("peerMicDisconnected", {name:other || t("otherParticipant")});
            else if (peerMicMuted) $("peerMicNote").textContent = t("peerMicMuted", {name:other || t("otherParticipant")});
            if (mode === "audio") $("audioBadge").textContent = t("audioCall");
            else if ($("remote").dataset.cameraOff === "true") $("audioBadge").textContent = t("peerCameraOff", {name:other || t("otherParticipant")});
            callQuality.refreshNow();
            renderParticipants(true);
            if (lastRoster && !$("guestPeople").hidden) renderGuestRoster();
            void outputChoices();
        }
        if (group && !group.ending) group.syncControls?.();
        return currentLang;
    };
    window.longvoxStartMemberCall = options => {
        if (!apple || memberCall || sessionActive || admission ||
            !["caller", "callee"].includes(options.role) || !["audio", "video"].includes(options.mode)) return false;
        if (options.language) window.longvoxSetLanguage(options.language);
        lobbyPreview.stop();
        memberCall = new MemberCall(options);
        return true;
    };
    function prepareGroup(contacts = [], answers = {}, alreadyStarted = false, contactNames = []) {
        lobbyPreview.stop();
        show("groupMeeting"); status("");
        group = new GroupMeeting(api, post, status, (text) => {
            group = null; sessionActive = false; $("record").hidden = true;
            show(nativeLaunch ? "finished" : "lobby"); status(text);
        }, {t, makeTimer});
        const name = [...$("name").value.trim()].slice(0, 60).join("") || t("hostRole");
        group.prepare(name, $("route").value, contacts, () => { sessionActive = true; }, answers, alreadyStarted, contactNames);
    }
    $("groupVideo").onclick = () => prepareGroup();
    bind("voice", () => host("audio")); bind("video", () => host("video")); bind("join", review); bind("accept", accept);
    bind("decline", () => end(t("callDeclined"), true, false)); bind("cancel", () => end(t("callCancelled"), true, false));
    bind("hangup", () => end(groupConsent ? t("youLeftMeeting") : t("callEnded"), true, true));
    bind("copy", async () => { try { await navigator.clipboard.writeText($("invite").value); status(t("inviteCopied")); }
        catch { $("invite").focus(); $("invite").select(); status(t("copySelectedInvite")); } });
    bind("mute", microphoneButton);
    bind("camera", async () => {
        const source = local, run = epoch;
        if (!source || ending) return;
        if (source.getVideoTracks().length) await setCamera(null);
        else {
            try { await openCamera(); }
            catch { if (run === epoch && source === local && !ending) cameraControls(t("cameraCheckRetry")); }
        }
    });
    bind("switchCamera", switchCamera);
    document.addEventListener("keydown", event => {
        const target = event.target;
        if (!(target instanceof Element) || event.defaultPrevented || event.repeat || event.isComposing || event.altKey || event.ctrlKey || event.metaKey
            || target.isContentEditable || target.closest("input, textarea, select, [role='textbox'], .shared-window-image")) return;
        const key = event.key.toLowerCase();
        // Keep Space's normal activation on focused controls.
        if (key === " " && target.closest("button, summary, a[href]")) return;
        const hosting = !$("groupControls").hidden && !$("groupMeeting").hidden;
        if (!hosting && $("meeting").hidden) return;
        const id = key === " " || key === "m" ? (hosting ? "groupMute" : "mute")
            : key === "v" ? (hosting ? "groupCamera" : "camera") : "";
        const button = id && $(id);
        if (!button || button.hidden || button.disabled) return;
        event.preventDefault();
        button.click();
    });
    async function checkWindow() {
        try { await api("ping"); }
        catch {
            if (!sessionActive && !apple) {
                show("finished");
                $("finishedTitle").textContent = t("callWindowClosed");
                status(t("reopenFromContacts"));
            }
        }
    }
    setInterval(checkWindow, 10000);
    document.addEventListener("visibilitychange", () => {
        trace("visibility", visibility());
        if (!document.hidden) void checkWindow();
    });
    window.longvoxFinishForClose = async () => {
        if (memberCall) return await memberCall.close();
        if (group) { await group.end(); return; }
        if (!ending && (sessionActive || admission || namedGuest)) await end(groupConsent ? t("youLeftMeeting") : t("callEnded"), true, true);
    };
    window.longvoxRequestClose = () => {
        if (memberCall) { void memberCall.close(); return true; }
        if (group) { void group.end(); return true; }
        if (!sessionActive && !admission) return false;
        if (!ending) void end(groupConsent ? t("youLeftMeeting") : t("callEnded"), true, true);
        return true;
    };
    window.addEventListener("beforeunload", e => { if (sessionActive) { e.preventDefault(); e.returnValue = ""; } });
})();
